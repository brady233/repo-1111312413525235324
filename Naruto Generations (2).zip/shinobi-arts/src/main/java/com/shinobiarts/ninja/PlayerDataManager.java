package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.FrogWalletItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.UUID;

/**
 * The single entry point for changing player progression and resources. Every system (stat menu,
 * leveling, Ryo, wallet, commands) goes through here so values are validated on the server,
 * stat effects are re-applied, and the client copy is synced. Never trust values sent by a client.
 */
public final class PlayerDataManager {
    private static final UUID MEDICAL_HEALTH_ID = UUID.fromString("6f1d9a3e-5b2c-4c1e-9a7d-1e2f3a4b5c6d");
    private static final UUID SPEED_ID = UUID.fromString("0b7c2e4d-8a1f-4d3b-b6c9-7e8f9a0b1c2d");
    private static final UUID CLAN_HEALTH_ID = UUID.fromString("3c9e7a51-2d4f-4b8e-a6c1-5f0d2e7b9a41");
    private static final UUID CLAN_SPEED_ID = UUID.fromString("8e2b4d6f-1a3c-4e5d-9b7f-0c2e4a6b8d13");
    private static final UUID CLAN_ARMOR_ID = UUID.fromString("5a7c9e1b-3d5f-4a2c-8e6b-1d3f5a7c9e25");
    private static final UUID CLAN_KNOCKBACK_ID = UUID.fromString("1f3b5d7a-9c2e-4f6a-b8d0-2e4c6a8f0b37");

    private PlayerDataManager() {}

    @Nullable
    public static NinjaData get(ServerPlayer player) {
        return NinjaData.get(player);
    }

    public static void sync(ServerPlayer player) {
        ModNetwork.sync(player);
    }

    // ================================================================ stat effects

    /** Re-applies Medical (max health) and Speed (movement) from the player's stats. */
    public static void applyStatEffects(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;

        AttributeInstance health = player.getAttribute(Attributes.MAX_HEALTH);
        if (health != null) {
            health.removeModifier(MEDICAL_HEALTH_ID);
            double bonus = d.stat(Stat.MEDICAL) * Config.d(Config.HEALTH_PER_MEDICAL);
            if (bonus > 0) {
                health.addPermanentModifier(new AttributeModifier(MEDICAL_HEALTH_ID, "Shinobi Arts medical",
                        bonus, AttributeModifier.Operation.ADDITION));
            }
            if (player.getHealth() > player.getMaxHealth()) player.setHealth(player.getMaxHealth());
        }

        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
            int points = Math.min(d.stat(Stat.SPEED), Config.i(Config.SPEED_CAP));
            double bonus = points * Config.d(Config.SPEED_PER_POINT);
            if (bonus > 0) {
                speed.addPermanentModifier(new AttributeModifier(SPEED_ID, "Shinobi Arts speed",
                        bonus, AttributeModifier.Operation.MULTIPLY_BASE));
            }
        }

        // clan bonuses: extra health, speed, armor and knockback resistance
        ClanBuffs buffs = d.getClan().buffs();
        setModifier(player, Attributes.MAX_HEALTH, CLAN_HEALTH_ID, "Clan health", buffs.health(), AttributeModifier.Operation.ADDITION);
        setModifier(player, Attributes.MOVEMENT_SPEED, CLAN_SPEED_ID, "Clan speed", buffs.speed(), AttributeModifier.Operation.MULTIPLY_BASE);
        setModifier(player, Attributes.ARMOR, CLAN_ARMOR_ID, "Clan armor", buffs.armor(), AttributeModifier.Operation.ADDITION);
        setModifier(player, Attributes.KNOCKBACK_RESISTANCE, CLAN_KNOCKBACK_ID, "Clan knockback resistance", buffs.knockback(),
                AttributeModifier.Operation.ADDITION);
        if (player.getHealth() > player.getMaxHealth()) player.setHealth(player.getMaxHealth());

        d.setChakra(d.getChakra());
        d.setSenjutsu(d.getSenjutsu());
    }

    /**
     * Drains chakra from a player (Gentle Fist, Samehada, insect and absorption clans), reduced by their clan's
     * drain resistance (Uzumaki 50%). Returns how much was actually taken.
     */
    public static float drainChakra(ServerPlayer victim, float amount) {
        NinjaData d = NinjaData.get(victim);
        if (d == null || amount <= 0) return 0f;
        float taken = Math.min(d.getChakra(), amount * (1f - d.getClan().buffs().drainResist()));
        if (taken > 0) {
            d.consumeChakra(taken);
            sync(victim);
        }
        return taken;
    }

    private static void setModifier(ServerPlayer player, net.minecraft.world.entity.ai.attributes.Attribute attribute, UUID id,
                                    String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = player.getAttribute(attribute);
        if (inst == null) return;
        inst.removeModifier(id);
        if (amount != 0) inst.addPermanentModifier(new AttributeModifier(id, "Naruto Generations " + name, amount, op));
    }

    // ================================================================ leveling

    /**
     * Adds XP, handling any number of level-ups (stat points + Ryo each). At the rank's level cap,
     * XP is banked (up to one level's worth) so it counts as soon as the player is promoted.
     */
    public static void addXp(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return;
        boolean wasCapped = d.isMaxLevel();
        d.setXp(d.getXp() + amount);
        processLevelUps(player, d);
        if (d.isMaxLevel() && !wasCapped) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.rank_cap", d.getRank().displayName(),
                    d.getRank().capText()).withStyle(ChatFormatting.YELLOW));
        }
        sync(player);
    }

    /**
     * XP the player earned by playing (mob kills, PvP, quests): multiplied by an active XP boost token.
     * Admin commands and EXP bottles use {@link #addXp} directly and aren't boosted.
     */
    public static void addEarnedXp(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return;
        addXp(player, Math.round(amount * (double) d.getBoostMultiplier() * (1.0 + d.getClan().buffs().xp()) * rankXpMultiplier(d)));
    }

    /**
     * The XP multiplier for the player's rank and role: Genin 1.0, Chunin 1.3, Jonin 1.6, ANBU 2.3, Advisor 2.0,
     * Kage 2.5 (configurable). Only the highest one that applies counts; they never stack with each other.
     */
    public static double rankXpMultiplier(NinjaData d) {
        double m = switch (d.getRank()) {
            case GENIN -> Config.d(Config.XP_GENIN);
            case CHUNIN -> Config.d(Config.XP_CHUNIN);
            case JONIN -> Config.d(Config.XP_JONIN);
            case ANBU -> Config.d(Config.XP_ANBU);
            case SANNIN -> Config.d(Config.XP_SANNIN);
        };
        if (d.isAdvisor()) m = Math.max(m, Config.d(Config.XP_ADVISOR));
        if (d.isKage()) m = Math.max(m, Config.d(Config.XP_KAGE));
        return m;
    }

    private static void processLevelUps(ServerPlayer player, NinjaData d) {
        long xp = d.getXp();
        int levelsGained = 0;
        long ryoGained = 0;
        int jutsuPoints = 0;
        while (!d.isMaxLevel() && xp >= d.xpToNext()) {
            xp -= d.xpToNext();
            d.setLevel(d.getLevel() + 1);
            d.setEarnedPoints(d.getEarnedPoints() + Config.i(Config.STAT_POINTS_PER_LEVEL));
            ryoGained += Config.i(Config.RYO_PER_LEVEL_UP);
            levelsGained++;
            // a chance of Jutsu Points on every level
            if (player.getRandom().nextDouble() < Config.d(Config.JUTSU_POINT_CHANCE)) {
                int min = Config.i(Config.JUTSU_POINTS_MIN), max = Math.max(min, Config.i(Config.JUTSU_POINTS_MAX));
                jutsuPoints += min + player.getRandom().nextInt(max - min + 1);
            }
        }
        d.setXp(d.isMaxLevel() ? Math.min(xp, d.xpToNext()) : xp);
        if (ryoGained > 0 && d.isKage()) ryoGained = Math.round(ryoGained * Config.d(Config.KAGE_RYO_BONUS));
        if (ryoGained > 0) d.setRyo(d.getRyo() + ryoGained);

        if (levelsGained > 0) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.level_up", d.getLevel(),
                    levelsGained * Config.i(Config.STAT_POINTS_PER_LEVEL), formatRyo(ryoGained)).withStyle(ChatFormatting.GOLD));
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_LEVELUP,
                    SoundSource.PLAYERS, 1.0f, 1.0f);
            player.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1, player.getZ(),
                    40, 0.5, 0.8, 0.5, 0.3);
            SharinganManager.checkEvolution(player);
        }
        if (jutsuPoints > 0) {
            int before = d.getJutsuPoints(), cost = Config.i(Config.JUTSU_UPGRADE_COST);
            d.setJutsuPoints(before + jutsuPoints);
            player.sendSystemMessage(Component.translatable("message.shinobiarts.jutsu_points", jutsuPoints, d.getJutsuPoints())
                    .withStyle(ChatFormatting.AQUA));
            if (before < cost && d.getJutsuPoints() >= cost) {
                player.sendSystemMessage(Component.translatable("message.shinobiarts.jutsu_points_ready", cost).withStyle(ChatFormatting.AQUA));
            }
        }
    }

    /** Spends Jutsu Points to upgrade one of the player's damaging jutsu (the Jutsu page of the stats menu). */
    public static void upgradeJutsu(ServerPlayer player, com.shinobiarts.jutsu.Jutsu jutsu) {
        NinjaData d = NinjaData.get(player);
        if (d == null || !d.knows(jutsu.id()) || !com.shinobiarts.jutsu.Jutsus.upgradeable(jutsu)) return;
        int level = d.jutsuUpgrade(jutsu.id()), max = Config.i(Config.JUTSU_MAX_UPGRADES), cost = Config.i(Config.JUTSU_UPGRADE_COST);
        if (level >= max) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.jutsu_max", jutsu.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }
        if (d.getJutsuPoints() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.jutsu_points_short", cost, d.getJutsuPoints())
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        d.setJutsuPoints(d.getJutsuPoints() - cost);
        d.setJutsuUpgrade(jutsu.id(), level + 1);
        int percent = Math.round((d.jutsuDamageMultiplier(jutsu.id()) - 1f) * 100);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.jutsu_upgraded", jutsu.displayName(), level + 1, percent)
                .withStyle(ChatFormatting.GREEN));
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENCHANTMENT_TABLE_USE,
                SoundSource.PLAYERS, 1.0f, 1.2f);
        sync(player);
    }

    /** Promotes (or demotes) a player. Banked XP is applied right away after a promotion. */
    public static void setRank(ServerPlayer player, Rank rank) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        boolean promotion = rank.ordinal() > d.getRank().ordinal();
        d.setRank(rank);
        if (promotion) {
            player.sendSystemMessage(Component.translatable(rank.hasCap() ? "message.shinobiarts.promoted" : "message.shinobiarts.promoted_nocap",
                    rank.displayName(), rank.capText())
                    .withStyle(ChatFormatting.GOLD));
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                    SoundSource.PLAYERS, 1.0f, 1.0f);
        }
        processLevelUps(player, d);
        sync(player);
    }

    /** Admin: set level directly (up to the rank's cap). Earned points are recalculated to match. */
    public static void setLevel(ServerPlayer player, int level) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        int clamped = Math.max(1, Math.min(level, d.getRank().levelCap()));
        d.setLevel(clamped);
        d.setXp(0);
        int earned = (clamped - 1) * Config.i(Config.STAT_POINTS_PER_LEVEL);
        d.setEarnedPoints(Math.max(earned, d.allocatedPoints()));
        sync(player);
        SharinganManager.checkEvolution(player);
    }

    // ================================================================ stats

    /** Spends stat points. Returns false (and tells the player why) if the request is invalid. */
    public static boolean allocate(ServerPlayer player, Stat stat, int amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return false;
        int room = stat.cap() - d.stat(stat);
        int spend = Math.min(amount, Math.min(room, d.availablePoints()));
        if (spend <= 0) {
            player.displayClientMessage(Component.translatable(room <= 0 ? "message.shinobiarts.stat_capped"
                    : "message.shinobiarts.no_points").withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setStat(stat, d.stat(stat) + spend);
        applyStatEffects(player);
        sync(player);
        return true;
    }

    /** Refunds every allocated point for Ryo. Validated entirely on the server. */
    public static boolean resetStats(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return false;
        if (d.allocatedPoints() == 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.nothing_to_reset").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        long cost = d.resetCost();
        if (d.getRyo() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_ryo",
                    formatRyo(cost), formatRyo(d.getRyo())).withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setRyo(d.getRyo() - cost);
        d.clearStats();
        d.setSageMode(false);
        applyStatEffects(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.stats_reset", formatRyo(cost)).withStyle(ChatFormatting.YELLOW));
        sync(player);
        return true;
    }

    // ================================================================ ryo

    public static void addRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return;
        d.setRyo(d.getRyo() + amount);
        sync(player);
    }

    /** Takes Ryo if the player has enough. Returns whether it was taken. */
    public static boolean trySpendRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount < 0 || d.getRyo() < amount) return false;
        d.setRyo(d.getRyo() - amount);
        sync(player);
        return true;
    }

    public static void setRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        d.setRyo(amount);
        sync(player);
    }

    /** The wallet is only usable while one is in the player's inventory. */
    public static boolean hasWallet(ServerPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof FrogWalletItem) return true;
        }
        return false;
    }

    /**
     * Moves coins from the inventory into the player's Ryo. {@code only} limits it to one coin type
     * (null = all coins). Runs on the server thread, so removing the items and adding the Ryo is atomic.
     */
    public static void deposit(ServerPlayer player, @Nullable CoinItem.Coin only) {
        NinjaData d = NinjaData.get(player);
        if (d == null || !hasWallet(player)) return;
        Inventory inv = player.getInventory();
        long total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() instanceof CoinItem coin && (only == null || coin.coin() == only)) {
                total += (long) coin.coin().value() * stack.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (total == 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_coins").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        d.setRyo(d.getRyo() + total);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 0.6f, 1.6f);
        player.displayClientMessage(Component.translatable("message.shinobiarts.deposited", formatRyo(total)).withStyle(ChatFormatting.GOLD), true);
        player.containerMenu.broadcastChanges();
        sync(player);
    }

    /** Turns Ryo into coin items. Coins that don't fit are dropped at the player's feet. */
    public static void withdraw(ServerPlayer player, CoinItem.Coin coin, int count) {
        NinjaData d = NinjaData.get(player);
        if (d == null || !hasWallet(player) || count <= 0) return;
        int n = (int) Math.min(Math.min(count, 64), d.getRyo() / coin.value());
        if (n <= 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_ryo",
                    formatRyo(coin.value()), formatRyo(d.getRyo())).withStyle(ChatFormatting.RED), true);
            return;
        }
        d.setRyo(d.getRyo() - (long) n * coin.value());
        ItemStack stack = new ItemStack(ModItems.coin(coin), n);
        player.getInventory().add(stack); // shrinks the stack by however much fit
        if (!stack.isEmpty()) player.drop(stack, false);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 0.6f, 1.2f);
        player.containerMenu.broadcastChanges();
        sync(player);
    }

    public static String formatRyo(long amount) {
        return NumberFormat.getIntegerInstance(Locale.US).format(amount);
    }

    /** Short Ryo for the HUD: 950, 1.2k, 15k, 250k, 1.5M, 25M, 1.2B (rounded down, so it never shows more than you have). */
    public static String formatRyoShort(long amount) {
        if (amount < 1000) return String.valueOf(amount);
        String[] units = {"k", "M", "B", "T"};
        double v = amount;
        int u = -1;
        while (v >= 1000 && u < units.length - 1) {
            v /= 1000;
            u++;
        }
        if (v < 10) {
            double one = Math.floor(v * 10) / 10;
            return (one == Math.floor(one) ? String.valueOf((long) one) : String.format(Locale.ROOT, "%.1f", one)) + units[u];
        }
        return (long) Math.floor(v) + units[u];
    }
}
