package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Chakra Control: how precisely a ninja can shape and hold their chakra (0-100). Not random and not bought with stat
 * points: everyone starts at a level set by their clan's nature (huge-reserve clans like the Uzumaki and Senju start
 * low, precise clans like the Hyuga start high), and it's raised only by practice:
 * <ul>
 *   <li>charging chakra (every second),</li>
 *   <li>walking on walls, ceilings and water (every second),</li>
 *   <li>casting jutsu (each cast, more for higher ranks).</li>
 * </ul>
 * The tiers change how jutsu behave:
 * <ul>
 *   <li><b>Low</b> (under 30): jutsu cost 25% more chakra. The Rasengan can't be held alone: a shadow clone of yours has
 *       to be beside you to help shape it.</li>
 *   <li><b>Medium</b> (30-59): jutsu cost 10% more. A Rasengan without a clone's help costs 50% more and lasts half as long.</li>
 *   <li><b>High</b> (60-89): normal costs; the Rasengan needs no help.</li>
 *   <li><b>Mastered</b> (90+): jutsu cost 20% less, and a Rasengan lasts 50% longer.</li>
 * </ul>
 */
public final class ChakraMastery {
    private ChakraMastery() {}

    public enum Tier { LOW, MEDIUM, HIGH, MASTERED }

    public static final int MAX = 100;

    public static Tier tier(int level) {
        return level >= 90 ? Tier.MASTERED : level >= 60 ? Tier.HIGH : level >= 30 ? Tier.MEDIUM : Tier.LOW;
    }

    public static Tier tier(NinjaData d) {
        return tier(d.getChakraControlLevel());
    }

    /** The level a new ninja starts at, from their clan (the same for everyone in it, nothing random). */
    public static int startingLevel(Clan clan) {
        if (clan == null) return 15;
        return switch (clan.id()) {
            case "uzumaki", "senju", "hoshigaki", "namikaze" -> 8;   // enormous reserves, hard to rein in
            case "hyuga", "yamanaka", "nara", "kurama" -> 30;        // fine, precise chakra
            case "aburame", "shirogane", "chinoike" -> 24;
            default -> 15;
        };
    }

    /** Practice needed to go from {@code level} to the next one. */
    public static int xpFor(int level) {
        return 20 + level * 4;
    }

    /** Multiplier on every jutsu's chakra cost. */
    public static float costMultiplier(NinjaData d) {
        return switch (tier(d)) {
            case LOW -> 1.25f;
            case MEDIUM -> 1.10f;
            case HIGH -> 1.0f;
            case MASTERED -> 0.80f;
        };
    }

    /** Gives the player their starting level the first time (on first spawn into a world). */
    public static void ensureStarted(ServerPlayer p, NinjaData d) {
        if (d.isChakraControlStarted() || !d.isInitialized()) return;
        d.setChakraControlLevel(startingLevel(d.getClan()));
        d.setChakraControlXp(0);
        d.setChakraControlStarted(true);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.cc_start", d.getChakraControlLevel(),
                Component.translatable("cc_tier.shinobiarts." + tier(d).name().toLowerCase(java.util.Locale.ROOT))).withStyle(ChatFormatting.AQUA));
    }

    /** Practice: {@code amount} toward the next level. Levels up (and says so) when there's enough. */
    public static void practice(ServerPlayer p, NinjaData d, int amount) {
        if (amount <= 0 || !d.isChakraControlStarted() || d.getChakraControlLevel() >= MAX) return;
        int xp = d.getChakraControlXp() + amount;
        int level = d.getChakraControlLevel();
        Tier before = tier(level);
        boolean up = false;
        while (level < MAX && xp >= xpFor(level)) {
            xp -= xpFor(level);
            level++;
            up = true;
        }
        d.setChakraControlLevel(level);
        d.setChakraControlXp(level >= MAX ? 0 : xp);
        if (up) {
            Tier after = tier(level);
            p.displayClientMessage(Component.translatable("message.shinobiarts.cc_up", level).withStyle(ChatFormatting.AQUA), true);
            if (after != before) {
                p.sendSystemMessage(Component.translatable("message.shinobiarts.cc_tier_up",
                        Component.translatable("cc_tier.shinobiarts." + after.name().toLowerCase(java.util.Locale.ROOT))).withStyle(ChatFormatting.GOLD));
                p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8f, 1.4f);
            }
        }
    }

    /** One of your own shadow clones within 6 blocks (to help shape a Rasengan). */
    public static boolean cloneNearby(ServerPlayer p) {
        return !p.level().getEntitiesOfClass(com.shinobiarts.entity.ShadowClone.class, p.getBoundingBox().inflate(6),
                c -> p.getUUID().equals(c.getOwnerUUID()) && c.isAlive()).isEmpty();
    }
}
