package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chakra points (tenketsu). A damaged point costs its owner 5-10% of their max chakra until it heals: by itself after
 * a while (chakraPointHealMinutes), or at once with a medical ninja's Chakra Point Restoration. At most
 * {@link NinjaData#MAX_TENKETSU} can be damaged, costing at most 60%.
 * <p>
 * It's rare from ordinary blows. Moves that aim at the chakra points do it often: Gentle Fist (melee with the Byakugan
 * on), Palm Rotation, Eight Trigrams 64 Palms, the Rasenshuriken (its blades cut the chakra network) and the medical
 * Chakra Scalpel. Byakugan users see everyone's chakra points, damaged ones in red (client: TenketsuVision).
 * <p>
 * Also here: the medical talent roll (rare, once, at clan claim).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ChakraPoints {
    private ChakraPoints() {}

    /** Jutsu made for the chakra points, and how long after casting their hits count (ms). */
    private static final Set<String> AIMED = Set.of("palm_rotation", "rasenshuriken");
    private static final long AIMED_WINDOW = 6000;
    /** At most one point per victim per this many ticks (so a flurry doesn't wreck the whole network in a second). */
    private static final int COOLDOWN = 20;
    private static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();
    /** Chakra Scalpel: until when each player's hands carry the blades (game time). */
    private static final Map<UUID, Long> SCALPEL = new ConcurrentHashMap<>();
    public static final int SCALPEL_TICKS = 300;

    /** Chakra Scalpel: blades of chakra on the hands for {@link #SCALPEL_TICKS} (15 seconds). */
    public static void startScalpel(ServerPlayer p) {
        SCALPEL.put(p.getUUID(), p.level().getGameTime() + SCALPEL_TICKS);
        SharinganManager.updateLook(p);
    }

    public static boolean scalpelActive(Player p) {
        Long until = SCALPEL.get(p.getUUID());
        return until != null && p.level().getGameTime() < until;
    }

    /** Rolls {@code chance} to damage one of the victim's chakra points. Returns whether it did. */
    public static boolean strike(ServerPlayer victim, @Nullable Entity attacker, double chance) {
        return strike(victim, attacker, chance, false);
    }

    /** {@code force}: ignore the per-victim cooldown (a finishing blow made to seal the points). */
    public static boolean strike(ServerPlayer victim, @Nullable Entity attacker, double chance, boolean force) {
        if (chance <= 0 || victim.getAbilities().instabuild || victim.isSpectator()) return false;
        NinjaData d = NinjaData.get(victim);
        if (d == null || !d.isInitialized() || d.getTenketsuPoints() >= NinjaData.MAX_TENKETSU) return false;
        long now = victim.level().getGameTime();
        Long last = LAST.get(victim.getUUID());
        if (!force && last != null && now - last < COOLDOWN) return false;
        if (victim.getRandom().nextDouble() >= chance) return false;
        LAST.put(victim.getUUID(), now);
        float share = 0.05f + victim.getRandom().nextFloat() * 0.05f;
        d.damageTenketsu(share, now + healTicks());
        Fx.at(victim.serverLevel(), Fx.Visual.GENTLE_FIST, victim.getBoundingBox().getCenter(), 0.7f, 8);
        JutsuUtil.sound(victim.serverLevel(), victim.position(), SoundEvents.AMETHYST_BLOCK_BREAK, 1f, 0.6f);
        victim.sendSystemMessage(Component.translatable("message.shinobiarts.tenketsu_hit", d.getTenketsuPoints(),
                Math.round(d.getTenketsuLoss() * 100)).withStyle(ChatFormatting.DARK_AQUA));
        if (attacker instanceof Player ap) {
            ap.displayClientMessage(Component.translatable("message.shinobiarts.tenketsu_struck", victim.getDisplayName()).withStyle(ChatFormatting.AQUA), true);
        }
        ModNetwork.sync(victim);
        SharinganManager.updateLook(victim);
        return true;
    }

    private static long healTicks() {
        return Config.i(Config.TENKETSU_HEAL_MINUTES) * 1200L;
    }

    /** Heals up to {@code points} of the player's damaged points. Returns how many. */
    public static int heal(ServerPlayer p, int points) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return 0;
        int n = d.healTenketsu(points, p.level().getGameTime() + healTicks());
        if (n > 0) {
            ModNetwork.sync(p);
            SharinganManager.updateLook(p);
        }
        return n;
    }

    /** Every second: damaged points heal by themselves in time; and the medical talent is rolled once. */
    public static void tick(ServerPlayer p, NinjaData d) {
        Long scalpel = SCALPEL.get(p.getUUID());
        if (scalpel != null) {
            if (p.level().getGameTime() >= scalpel) {
                SCALPEL.remove(p.getUUID());
                SharinganManager.updateLook(p);
                p.displayClientMessage(Component.translatable("message.shinobiarts.scalpel_off").withStyle(ChatFormatting.GRAY), true);
            } else {                                               // the blades hum green round the hands
                Vec3 hand = p.getEyePosition().add(p.getLookAngle().scale(0.5)).add(0, -0.45, 0);
                p.serverLevel().sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(0.35f, 1f, 0.55f), 0.8f),
                        hand.x, hand.y, hand.z, 6, 0.18, 0.12, 0.18, 0.0);
            }
        }
        if (!d.isMedicalRolled() && (d.isClanClaimed() || d.isClanFinal())) rollMedical(p, d, false);
        if (d.getTenketsuPoints() > 0 && p.level().getGameTime() >= d.getTenketsuHealAt()) {
            if (heal(p, 1) > 0) {
                p.displayClientMessage(Component.translatable("message.shinobiarts.tenketsu_recovered", d.getTenketsuPoints()).withStyle(ChatFormatting.AQUA), true);
            }
        }
    }

    /**
     * Rolls whether the player is a medical ninja (once ever). Anyone who already learned Medical jutsu before this
     * existed keeps them. {@code announce}: tell them in the clan-claim style.
     */
    public static void rollMedical(ServerPlayer p, NinjaData d, boolean announce) {
        if (d.isMedicalRolled()) return;
        boolean already = Jutsus.all().stream().anyMatch(j -> j.nature() == ChakraNature.MEDICAL && d.knows(j.id()));
        boolean talent = already || p.getRandom().nextDouble() < Config.d(Config.MEDICAL_TALENT_CHANCE);
        d.setMedicalTalent(talent);
        if (talent && !already) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.medical_talent").withStyle(ChatFormatting.GREEN));
            com.shinobiarts.item.ReleaseItem.give(p, ChakraNature.MEDICAL);
        }
        ModNetwork.sync(p);
    }

    /** "Medical, Fire" (or just "Fire"); "???" for an element not yet found with chakra paper. */
    public static Component natureLine(NinjaData d) {
        Component element = d.isAffinityRevealed() ? d.getAffinity().displayName() : Component.literal("???").withStyle(ChatFormatting.GRAY);
        if (!d.hasMedicalTalent()) return element;
        return Component.empty().append(ChakraNature.MEDICAL.displayName()).append(Component.literal(", ").withStyle(ChatFormatting.GRAY)).append(element);
    }

    // ---------------------------------------------------------------- hits

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onHurt(LivingHurtEvent event) {
        if (event.isCanceled() || event.getAmount() <= 0) return;
        Entity attacker = event.getSource().getEntity();
        Player owner = attacker instanceof Player pl ? pl : attacker instanceof ShadowClone c ? c.getOwner() : null;
        if (owner == null || owner == event.getEntity()) return;
        boolean melee = event.getSource().getDirectEntity() == attacker;
        NinjaData ad = NinjaData.get(owner);
        String last = JutsuUtil.lastJutsu(owner);
        long since = JutsuUtil.sinceCast(owner);
        boolean scalpel = melee && ad != null && scalpelActive(owner) && owner.getMainHandItem().isEmpty();
        if (scalpel) {                                            // a blade of chakra on the fingertips: cuts from inside
            event.setAmount(event.getAmount() + 4f + ad.stat(Stat.MEDICAL) * 0.15f);
            if (owner.level() instanceof net.minecraft.server.level.ServerLevel sl) {
                Vec3 at = event.getEntity().getBoundingBox().getCenter();
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0, 0, 0, 0);
                sl.sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(0.35f, 1f, 0.55f), 1.2f),
                        at.x, at.y, at.z, 14, 0.3, 0.4, 0.3, 0.0);
                JutsuUtil.sound(sl, at, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.6f);
            }
        }
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        double chance;
        if (scalpel || (last != null && AIMED.contains(last) && since < AIMED_WINDOW)) chance = Config.d(Config.TENKETSU_CHANCE_HIGH);
        else if (melee && ad != null && ad.getActiveDojutsu() == Dojutsu.BYAKUGAN) chance = Config.d(Config.TENKETSU_CHANCE_BYAKUGAN);
        else chance = Config.d(Config.TENKETSU_CHANCE_NORMAL);
        strike(victim, owner, chance);
    }
}
