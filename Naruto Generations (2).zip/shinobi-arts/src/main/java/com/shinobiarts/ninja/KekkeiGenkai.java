package com.shinobiarts.ninja;

import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Kekkei genkai: the five clan releases (Wood, Ice, Magnet, Bone, Sealing), the three eyes (Sharingan, Byakugan,
 * Rinnegan, whose jutsu are Shinra Tensei, Bansho Ten'in and Chibaku Tensei) and the four advanced natures (Lava,
 * Storm, Boil, Scorch), which no clan is born with: they're only awakened.
 * Born into the clan, or awakened by anyone from DNA (mob and player drops) or a kekkei genkai jutsu scroll.
 * Whoever has one has its whole skillset: the release and every one of its jutsu, or the eyes and their techniques
 * (the Byakugan also brings Eight Trigrams Palm Rotation).
 */
public enum KekkeiGenkai {
    WOOD("wood", ChakraNature.WOOD, 0x70A83C),
    ICE("ice", ChakraNature.ICE, 0x96DEF6),
    MAGNET("magnet", ChakraNature.MAGNET, 0x6E7386),
    BONE("bone", ChakraNature.BONE, 0xE8E0C6),
    SEALING("sealing", ChakraNature.SEALING, 0xCC3C5C),
    SHARINGAN("sharingan", null, 0xD01818),
    BYAKUGAN("byakugan", null, 0xC8C0F0),
    RINNEGAN("rinnegan", ChakraNature.RINNEGAN, 0x9C80DC),
    LAVA("lava", ChakraNature.LAVA, 0xE8541C),
    STORM("storm", ChakraNature.STORM, 0x8AD4FF),
    BOIL("boil", ChakraNature.BOIL, 0xD8E4EA),
    SCORCH("scorch", ChakraNature.SCORCH, 0xFFA040);

    private final String id;
    @Nullable
    private final ChakraNature release;
    private final int rgb;

    KekkeiGenkai(String id, @Nullable ChakraNature release, int rgb) {
        this.id = id;
        this.release = release;
        this.rgb = rgb;
    }

    public String id() {
        return id;
    }

    /** The clan release this kekkei genkai is, or null for the eyes. */
    @Nullable
    public ChakraNature release() {
        return release;
    }

    /** Colour of its DNA vial. */
    public int rgb() {
        return rgb;
    }

    public MutableComponent displayName() {
        if (release != null) return release.displayName();
        if (this == RINNEGAN) return shortName();
        return this == SHARINGAN ? Dojutsu.sharinganName(1).copy() : Dojutsu.byakuganName();
    }

    /** "Sharingan" (no tomoe count), for DNA names. */
    public MutableComponent shortName() {
        if (release != null) return release.displayName();
        return Component.translatable("kekkei_genkai.shinobiarts." + id).withStyle(this == SHARINGAN ? ChatFormatting.RED
                : this == RINNEGAN ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.AQUA);
    }

    /** Whether this ninja has it (from their clan or awakened). */
    public boolean has(NinjaData d) {
        return switch (this) {
            case SHARINGAN -> d.getSharinganStage() > 0;
            case BYAKUGAN -> d.hasByakugan();
            case RINNEGAN -> d.hasRinnegan();
            default -> d.hasNature(release);
        };
    }

    @Nullable
    public static KekkeiGenkai byId(String id) {
        for (KekkeiGenkai k : values()) {
            if (k.id.equals(id)) return k;
        }
        return null;
    }

    public static KekkeiGenkai random(RandomSource random) {
        KekkeiGenkai[] all = values();
        return all[random.nextInt(all.length)];
    }

    /** The kekkei genkai a ninja has, for their DNA dropping when they're defeated. */
    public static List<KekkeiGenkai> owned(NinjaData d) {
        List<KekkeiGenkai> out = new ArrayList<>();
        for (KekkeiGenkai k : values()) {
            if (k.has(d)) out.add(k);
        }
        return out;
    }

    /** The kekkei genkai whose jutsu this is (Wood Binding: Wood), or null. */
    @Nullable
    public static KekkeiGenkai of(Jutsu jutsu) {
        for (KekkeiGenkai k : values()) {
            if (k.release != null && k.release == jutsu.nature()) return k;
        }
        return null;
    }

    // ---------------------------------------------------------------- awakening

    /** Awakens a kekkei genkai (DNA, a scroll). Returns false if the player already has it. */
    public static boolean awaken(ServerPlayer p, KekkeiGenkai k) {
        NinjaData d = NinjaData.get(p);
        if (d == null || k.has(d)) return false;
        d.addBloodline(k.id);
        if (k == SHARINGAN) {
            d.setSharinganStage(1);
            SharinganManager.checkEvolution(p);        // straight to the tomoe their level allows
        }
        p.sendSystemMessage(Component.translatable("message.shinobiarts.kekkei_genkai_awakened", k.shortName()).withStyle(ChatFormatting.GOLD));
        p.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 50, 0.4, 0.7, 0.4, 0.35);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.0f, 0.7f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_LEVELUP, 1.0f, 0.6f);
        grantSkillsets(p, d);
        if (k == SHARINGAN || k == BYAKUGAN) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.dojutsu", k.shortName()).withStyle(ChatFormatting.GOLD));
        }
        ModNetwork.sync(p);
        SharinganManager.broadcastEyes(p);
        return true;
    }

    /**
     * Every second (from the ninja ticker): every kekkei genkai the player has comes with its whole skillset. The first
     * time a release becomes usable its release item is handed over; every jutsu of it is learned automatically
     * (rank requirements don't apply). The Byakugan brings Palm Rotation.
     */
    public static void grantSkillsets(ServerPlayer p, NinjaData d) {
        if (!d.isInitialized()) return;
        boolean changed = false;
        for (KekkeiGenkai k : values()) {
            if (!k.has(d)) continue;
            if (k.release != null) {
                if (!d.wasReleaseGiven(k.release)) {
                    d.markReleaseGiven(k.release);
                    boolean clanBlood = d.getClan() == k.release.clan();
                    if (clanBlood) {
                        p.sendSystemMessage(Component.translatable("message.shinobiarts.clan_release_awakened",
                                d.getClan().displayName(), k.release.displayName()).withStyle(ChatFormatting.GOLD));
                    }
                    com.shinobiarts.item.ReleaseItem.give(p, k.release);
                    p.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.6, 0.4, 0.3);
                    JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_LEVELUP, 1.0f, 0.8f);
                    changed = true;
                }
                for (Jutsu j : Jutsus.all()) {
                    if (j.nature() == k.release && !d.knows(j.id())) changed |= teach(p, d, j);
                }
            } else if (k == BYAKUGAN && d.getClan() != Clan.HYUGA && !d.knows(Jutsus.PALM_ROTATION.id())) {
                changed |= teach(p, d, Jutsus.PALM_ROTATION);
            } else if (k == RINNEGAN) {                           // the Rinnegan's three techniques
                for (Jutsu j : Jutsus.all()) {
                    if (Jutsus.isRinnegan(j) && !d.knows(j.id())) changed |= teach(p, d, j);
                }
            }
        }
        if (changed) ModNetwork.sync(p);
    }

    private static boolean teach(ServerPlayer p, NinjaData d, Jutsu j) {
        d.learn(j.id());
        p.sendSystemMessage(Component.translatable("message.shinobiarts.learned", j.displayName()).withStyle(ChatFormatting.GREEN));
        return true;
    }

    /** True if a player's kekkei genkai lets them learn a clan's jutsu (Wood Binding with Wood DNA, Palm Rotation with the Byakugan). */
    /** Clan releases with no entry above (Shadow, Mind, every "<clan> Clan" release...): given the same way. */
    public static void grantClanReleases(ServerPlayer p, NinjaData d) {
        if (!d.isInitialized()) return;
        boolean changed = false;
        for (ChakraNature r : ChakraNature.CLAN_RELEASES) {
            boolean covered = false;
            for (KekkeiGenkai k : values()) {
                if (k.release == r) {
                    covered = true;
                    break;
                }
            }
            if (covered || !d.hasNature(r)) continue;
            if (!d.wasReleaseGiven(r)) {
                d.markReleaseGiven(r);
                p.sendSystemMessage(Component.translatable("message.shinobiarts.clan_release_awakened",
                        d.getClan().displayName(), r.displayName()).withStyle(ChatFormatting.GOLD));
                com.shinobiarts.item.ReleaseItem.give(p, r);
                JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_LEVELUP, 1.0f, 0.8f);
                changed = true;
            }
            for (Jutsu j : Jutsus.all()) {
                if (j.nature() == r && !d.knows(j.id())) changed |= teach(p, d, j);
            }
        }
        if (changed) com.shinobiarts.network.ModNetwork.sync(p);
    }

    public static boolean allows(NinjaData d, Jutsu jutsu) {
        if (jutsu.nature().isKekkeiGenkai() && d.hasNature(jutsu.nature())) return true;
        if (Jutsus.isRinnegan(jutsu)) return d.hasRinnegan();
        return jutsu == Jutsus.PALM_ROTATION && d.hasByakugan();
    }
}
