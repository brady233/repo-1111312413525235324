package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The jutsu in MoreJutsu: the Great Dragon Fire, the Vacuum spheres and the Great Sickle Weasel, Kirin, the Black
 * Panther, False Darkness, the lightning hound, the Earth Spear, the earth dragon and its mud bullets, the Earth
 * Sandwich, the Rock Golem and the Hiding in Mist fog.
 */
final class FxMore {
    private FxMore() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    // ================================================================ shared

    /**
     * Where a travelling jutsu is: from a toward b (or the creature it chases), arriving after the effect's ticks minus
     * {@code linger}; on the ground if {@code ground}. Matches MoreJutsu.travel on the server.
     */
    private static Vec3 head(FxClient.Ctx c, int linger, boolean ground) {
        float travel = Math.max(1, c.fx().ticks - linger);
        float t = Mth.clamp((c.age() + 1) / travel, 0f, 1f);
        Entity target = c.fx().entityB();
        Vec3 goal = target != null ? target.getPosition(c.partial()).add(0, target.getBbHeight() / 2, 0) : c.fx().b;
        Vec3 at = c.fx().a.lerp(goal, t);
        if (ground) at = new Vec3(at.x, FxDraw.groundY(at) + 0.6, at.z);
        return at;
    }

    private static Vec3 heading(FxClient.Ctx c) {
        Entity target = c.fx().entityB();
        Vec3 goal = target != null ? target.getPosition(c.partial()) : c.fx().b;
        Vec3 d = goal.subtract(c.fx().a);
        d = new Vec3(d.x, 0, d.z);
        return d.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : d.normalize();
    }

    private static float fadeOut(FxClient.Ctx c, int last) {
        return 1f - Mth.clamp((c.age() - (c.fx().ticks - last)) / last, 0f, 1f);
    }

    /** A four-legged animal's skeleton (spine, neck, head, legs, tail) at {@code at}, facing {@code f}, mid-stride. */
    private static List<Vec3[]> beast(Vec3 at, Vec3 f, float s, float stride, boolean cat) {
        Vec3 r = f.cross(UP).normalize();
        List<Vec3[]> bones = new ArrayList<>();
        Vec3 hip = at.subtract(f.scale(0.7 * s)).add(0, 0.25 * s, 0);
        Vec3 shoulder = at.add(f.scale(0.6 * s)).add(0, 0.35 * s + 0.08 * s * Mth.sin(stride * 2), 0);
        bones.add(new Vec3[]{hip, shoulder});
        Vec3 headAt = shoulder.add(f.scale(0.45 * s)).add(0, (cat ? 0.25 : 0.35) * s, 0);
        bones.add(new Vec3[]{shoulder, headAt});
        Vec3 snout = headAt.add(f.scale((cat ? 0.32 : 0.45) * s)).subtract(0, 0.08 * s, 0);
        bones.add(new Vec3[]{headAt, snout});
        for (int side = -1; side <= 1; side += 2) {                    // ears
            bones.add(new Vec3[]{headAt.add(r.scale(side * 0.1 * s)), headAt.add(r.scale(side * 0.14 * s)).add(0, 0.22 * s, 0).subtract(f.scale(0.05 * s))});
        }
        float[] phase = {0f, Mth.PI, Mth.PI * 0.5f, Mth.PI * 1.5f};
        Vec3[] roots = {shoulder.add(r.scale(0.18 * s)), shoulder.subtract(r.scale(0.18 * s)), hip.add(r.scale(0.18 * s)), hip.subtract(r.scale(0.18 * s))};
        for (int k = 0; k < 4; k++) {
            float swing = Mth.sin(stride + phase[k]);
            Vec3 paw = roots[k].add(f.scale(swing * 0.45 * s)).subtract(0, 0.9 * s - Math.max(0, Mth.cos(stride + phase[k])) * 0.25 * s, 0);
            Vec3 knee = roots[k].lerp(paw, 0.5).add(f.scale((k < 2 ? -0.12 : 0.12) * s));
            bones.add(new Vec3[]{roots[k], knee});
            bones.add(new Vec3[]{knee, paw});
        }
        Vec3 tail = hip.subtract(f.scale((cat ? 0.9 : 0.6) * s)).add(0, (cat ? 0.25 : 0.4) * s + 0.1 * s * Mth.sin(stride), 0);
        bones.add(new Vec3[]{hip, tail});
        return bones;
    }

    // ================================================================ fire

    /** Great Dragon Fire: a serpentine dragon of roaring flame, horned head first, flying at the target. */
    static void fireDragon(FxClient.Ctx c) {
        float age = c.age();
        Vec3 headAt = head(c, 10, false);
        Vec3 dir = headAt.subtract(c.fx().a);
        double travelled = dir.length();
        dir = travelled < 1e-3 ? heading(c) : dir.normalize();
        Vec3 side = FxDraw.perpendicular(dir);
        Vec3 up = side.cross(dir).normalize();
        float fade = fadeOut(c, 10);
        float s = c.fx().size;
        VertexConsumer add = FxDraw.additive(c.buffers());
        List<Vec3> spine = new ArrayList<>();
        double length = Math.min(12 * s, travelled);
        for (int i = 0; i <= 28; i++) {
            double d = length * i / 28.0;
            float wave = (float) d * 0.8f - age * 0.7f;
            float amp = (float) Math.min(1.0, d / 2.0) * 0.8f * s;
            spine.add(headAt.subtract(dir.scale(d)).add(side.scale(Mth.sin(wave) * amp)).add(up.scale(Mth.cos(wave * 0.7f) * amp * 0.6)));
        }
        if (spine.size() > 1) {
            FxDraw.ribbon(add, c.ps(), c.cam(), spine, 2.6f * s, 0.85f, FxDraw.addColor(0xFF5A10, 0.5f * fade), FxDraw.addColor(0xC02000, 0.05f), FxDraw.FULL);
            FxDraw.ribbon(add, c.ps(), c.cam(), spine, 1.5f * s, 0.85f, FxDraw.addColor(0xFFA030, 0.7f * fade), FxDraw.addColor(0xFF5A10, 0.1f), FxDraw.FULL);
            FxDraw.ribbon(add, c.ps(), c.cam(), spine, 0.6f * s, 0.9f, FxDraw.addColor(0xFFF0A0, 0.8f * fade), FxDraw.addColor(0xFFA030, 0f), FxDraw.FULL);
        }
        RandomSource r = FxDraw.rng(c.fx().seed, 50);
        for (int i = 0; i < spine.size(); i += 2) {                     // licking flames along the body
            Vec3 p = spine.get(i).add(r.nextGaussian() * 0.4 * s, r.nextGaussian() * 0.4 * s + 0.2, r.nextGaussian() * 0.4 * s);
            float w = (1.3f - i / 40f) * s;
            FxDraw.billboard(add, c.ps(), c.camera(), p, w, w * 1.3f, age * 0.1f + i, FxDraw.addColor(0xFF7A20, 0.45f * fade), FxDraw.FULL);
        }
        // the head: a glowing skull of flame with jaws, two horns sweeping back, and white-hot eyes
        VertexConsumer glow = FxDraw.glow(c.buffers());
        Vec3 snout = headAt.add(dir.scale(1.4 * s));
        float jaw = 0.25f + 0.2f * Mth.sin(age * 0.5f);
        FxDraw.cone(add, c.ps(), headAt.subtract(dir.scale(0.3 * s)), snout.add(up.scale(0.15 * s)), 0.75f * s, 10, FxDraw.addColor(0xFF8A30, 0.75f * fade), FxDraw.FULL);
        FxDraw.cone(add, c.ps(), headAt.subtract(up.scale(0.35 * s)), snout.subtract(up.scale(jaw * s)), 0.5f * s, 8, FxDraw.addColor(0xFF6A20, 0.7f * fade), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), headAt, 2.8f * s, 2.8f * s, 0, FxDraw.addColor(0xFF6A10, 0.4f * fade), FxDraw.FULL);
        for (int sd = -1; sd <= 1; sd += 2) {
            Vec3 root = headAt.add(side.scale(sd * 0.4 * s)).add(up.scale(0.4 * s));
            List<Vec3> horn = List.of(root, root.subtract(dir.scale(0.8 * s)).add(up.scale(0.6 * s)).add(side.scale(sd * 0.2 * s)),
                    root.subtract(dir.scale(1.7 * s)).add(up.scale(0.8 * s)).add(side.scale(sd * 0.35 * s)));
            FxDraw.ribbon(add, c.ps(), c.cam(), horn, 0.35f * s, 1f, FxDraw.addColor(0xFFC060, 0.85f * fade), FxDraw.addColor(0xFF6A10, 0.2f), FxDraw.FULL);
            Vec3 eye = headAt.add(dir.scale(0.45 * s)).add(side.scale(sd * 0.32 * s)).add(up.scale(0.28 * s));
            FxDraw.billboard(glow, c.ps(), c.camera(), eye, 0.28f * s, 0.18f * s, 0, FxDraw.color(0xFFFFE0, fade), FxDraw.FULL);
        }
    }

    // ================================================================ wind

    /** A sphere of compressed air: a clear, rippling ball with wind streaming round it and a trail behind. */
    static void windBullet(FxClient.Ctx c) {
        float age = c.age();
        Vec3 at = head(c, 2, false);
        float s = c.fx().size;
        float fade = fadeOut(c, 2);
        VertexConsumer glow = FxDraw.glow(c.buffers());
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.sphere(glow, c.ps(), at, s * 0.5f, 10, 16, FxDraw.color(0xE8F4FF, 0.22f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), at, s * 0.35f, 8, 12, FxDraw.addColor(0xCFE8FF, 0.25f * fade), FxDraw.FULL);
        Vec3 dir = c.fx().b.subtract(c.fx().a).normalize();
        RandomSource r = FxDraw.rng(c.fx().seed, 51);
        for (int k = 0; k < 6; k++) {                                // streams of wind whirling round it
            Vec3 axis = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize();
            Vec3 u = FxDraw.perpendicular(axis), v = axis.cross(u);
            List<Vec3> pts = new ArrayList<>();
            float a0 = age * 0.8f + k;
            for (int i = 0; i <= 8; i++) {
                float a = a0 + i * 0.3f;
                pts.add(at.add(u.scale(Mth.cos(a) * s * 0.6)).add(v.scale(Mth.sin(a) * s * 0.6)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.06f * s + 0.03f, 1f, FxDraw.addColor(0xFFFFFF, 0.6f * fade), FxDraw.addColor(0xCFE8FF, 0f), FxDraw.FULL);
        }
        List<Vec3> trail = new ArrayList<>();
        for (int i = 0; i <= 6; i++) trail.add(at.subtract(dir.scale(i * 0.5 * s)));
        FxDraw.ribbon(add, c.ps(), c.cam(), trail, s * 0.7f, 1f, FxDraw.addColor(0xDDEEFF, 0.25f * fade), FxDraw.addColor(0xDDEEFF, 0f), FxDraw.FULL);
    }

    /** Vacuum Great Sickle Weasel: a wall of white wind blades and streaks rolling forward across the band. */
    static void sickleWeasel(FxClient.Ctx c) {
        float age = c.age();
        int ticks = c.fx().ticks;
        Vec3 o = c.fx().a;
        Vec3 fwd = c.fx().b.subtract(o);
        double reach = fwd.length();
        fwd = fwd.normalize();
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        float width = c.fx().size;
        float t = Mth.clamp(age / (ticks - 6), 0f, 1f);
        double front = 2 + (reach - 2) * t;
        float fade = fadeOut(c, 8);
        VertexConsumer add = FxDraw.additive(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 52);
        for (int k = 0; k < 46; k++) {                                // crescent blades spinning in the front of it
            double across = (r.nextFloat() - 0.5) * width;
            double back = r.nextFloat() * 5;
            double h = 0.2 + r.nextFloat() * 3.5;
            Vec3 cpos = o.add(fwd.scale(Math.max(0, front - back))).add(right.scale(across)).add(0, h - 1, 0);
            float spin = age * (0.5f + r.nextFloat() * 0.4f) + k;
            float rad = 0.7f + r.nextFloat() * 1.1f;
            Vec3 axis = right.scale(Mth.cos(spin * 0.3f)).add(fwd.scale(Mth.sin(spin * 0.3f))).normalize();
            Vec3 u = FxDraw.perpendicular(axis), v = axis.cross(u);
            List<Vec3> arc = new ArrayList<>();
            for (int i = 0; i <= 7; i++) {
                float a = spin + i * 0.3f;
                arc.add(cpos.add(u.scale(Mth.cos(a) * rad)).add(v.scale(Mth.sin(a) * rad)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), arc, 0.18f, 1f, FxDraw.addColor(0xFFFFFF, 0.8f * fade), FxDraw.addColor(0xCFE8FF, 0f), FxDraw.FULL);
        }
        for (int k = 0; k < 24; k++) {                                // long streaks of wind behind the front
            double across = (r.nextFloat() - 0.5) * width;
            double h = r.nextFloat() * 3.5 - 0.8;
            double len = 3 + r.nextFloat() * 5;
            Vec3 tip = o.add(fwd.scale(front)).add(right.scale(across)).add(0, h, 0);
            FxDraw.ribbon(add, c.ps(), c.cam(), List.of(tip, tip.subtract(fwd.scale(len))), 0.12f, 1f, FxDraw.addColor(0xE8F4FF, 0.5f * fade),
                    FxDraw.addColor(0xE8F4FF, 0f), FxDraw.FULL);
        }
    }

    // ================================================================ lightning

    /**
     * Kirin: black thunderclouds churn over the spot, flickering, and then a dragon of lightning plunges out of them
     * onto it: a colossal bolt with a dragon's head and jaws, leaving a pillar of light.
     */
    static void kirin(FxClient.Ctx c) {
        float age = c.age();
        int ticks = c.fx().ticks;
        Vec3 g = c.fx().a;
        Vec3 sky = g.add(0, 95, 0);                                   // GIANT: it comes from high up in the sky
        float cloudIn = Mth.clamp(age / 12f, 0f, 1f) * fadeOut(c, 12);
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), FxYin.PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 53);
        for (int k = 0; k < 90; k++) {                                // the storm
            Vec3 p = sky.add(r.nextGaussian() * 30, r.nextGaussian() * 4, r.nextGaussian() * 30);
            float s = 16 + r.nextFloat() * 16;
            int shade = 28 + r.nextInt(30);
            boolean flash = r.nextFloat() < 0.15f && ((int) age + k) % 7 == 0;
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.01f,
                    new Paint(0, 0, 1, 1, flash ? 200 : shade, flash ? 210 : shade, flash ? 255 : shade + 12, Math.round(220 * cloudIn)), FxDraw.FULL);
        }
        if (age < 30) {                                              // charging: little bolts inside the cloud
            if (((int) age) % 3 == 0) {
                Vec3 a = sky.add(r.nextGaussian() * 20, 0, r.nextGaussian() * 20);
                FxDraw.bolt(c.buffers(), c.ps(), c.cam(), a, a.add(r.nextGaussian() * 15, -3, r.nextGaussian() * 15), (long) age * 31, 3.5f, 0.15f, 0x9CC8FF, 0.8f, 1);
            }
            return;
        }
        float strike = age - 30;
        float down = Mth.clamp(strike / 8f, 0f, 1f);
        float fade = 1f - Mth.clamp((strike - 12) / 18f, 0f, 1f);
        if (fade <= 0) return;
        Vec3 tip = sky.lerp(g, down);
        long seed = c.fx().seed + (long) age;
        // the dragon: a great jagged body coiling down, the main bolt through it, and a head of light at the front
        List<Vec3> body = new ArrayList<>();
        for (int i = 0; i <= 36; i++) {
            float u = i / 36f;
            Vec3 p = sky.lerp(tip, u);
            float coil = (1 - u) * 12f;
            body.add(p.add(Mth.cos(u * 9 + age * 0.3f) * coil, 0, Mth.sin(u * 9 + age * 0.3f) * coil));
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ribbon(add, c.ps(), c.cam(), body, 18f, 0.55f, FxDraw.addColor(0x6AA8FF, 0.45f * fade), FxDraw.addColor(0x9CC8FF, 0.6f * fade), FxDraw.FULL);
        FxDraw.ribbon(add, c.ps(), c.cam(), body, 7f, 0.55f, FxDraw.addColor(0xDDEEFF, 0.8f * fade), FxDraw.addColor(0xFFFFFF, fade), FxDraw.FULL);
        for (int i = 0; i + 1 < body.size(); i += 2) {
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), body.get(i), body.get(i + 1), seed + i, 2.6f, 0.25f, 0x9CC8FF, fade, 2);
        }
        Vec3 dir = tip.subtract(body.get(Math.max(0, body.size() - 3))).normalize();
        Vec3 side = FxDraw.perpendicular(dir);
        FxDraw.billboard(add, c.ps(), c.camera(), tip, 22f, 22f, age, FxDraw.addColor(0xCFE4FF, 0.8f * fade), FxDraw.FULL);
        for (int sd = -1; sd <= 1; sd += 2) {                         // jaws and horns of lightning
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), tip, tip.subtract(dir.scale(10)).add(side.scale(sd * 8)), seed + 90 + sd, 1.8f, 0.25f, 0x9CC8FF, fade, 1);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), tip.subtract(dir.scale(3)), tip.subtract(dir.scale(14)).add(side.scale(sd * 4)).add(0, 8, 0), seed + 95 + sd, 1.2f, 0.18f, 0xFFFFFF, fade, 0);
        }
        if (down >= 1f) {                                            // the pillar of light and the ground flash
            FxDraw.ring(FxDraw.glow(c.buffers()), c.ps(), g.add(0, 0.05, 0), UP, 6 + strike * 2.2f, 7f, 64, FxDraw.color(0xFFFFFF, 0.6f * fade),
                    FxDraw.color(0x9CC8FF, 0f), FxDraw.FULL);
            FxDraw.billboard(add, c.ps(), c.camera(), g.add(0, 3, 0), 40, 40, 0, FxDraw.addColor(0xBFD8FF, 0.6f * fade), FxDraw.FULL);
        }
    }

    /** Black Panther: a great cat of black lightning, bounding along the ground, crackling with dark sparks. */
    static void blackPanther(FxClient.Ctx c) {
        float age = c.age();
        Vec3 at = head(c, 4, true).subtract(0, 0.6, 0).add(0, 1.0, 0);
        Vec3 f = heading(c);
        float fade = fadeOut(c, 4);
        float stride = age * 0.9f;
        int light = FxDraw.lightAt(at);
        VertexConsumer lit = FxDraw.lit(c.buffers());
        Paint black = FxDraw.color(0x0C0A10, 0.92f * fade);
        for (Vec3[] bone : beast(at, f, 1.4f, stride, true)) {          // its body: black, solid
            FxDraw.tube(lit, c.ps(), List.of(bone[0], bone[1]), new float[]{0.2f, 0.14f}, 6, black, 1f, light, true);
        }
        FxDraw.sphere(lit, c.ps(), at.add(0, 0.3, 0), 0.55f, 8, 10, black, light);
        long seed = c.fx().seed + (long) (age * 2);
        RandomSource r = FxDraw.rng(seed, 54);
        for (Vec3[] bone : beast(at, f, 1.45f, stride, true)) {         // dark lightning crawling over it
            if (r.nextFloat() < 0.6f) FxDraw.bolt(c.buffers(), c.ps(), c.cam(), bone[0], bone[1], seed + r.nextInt(999), 0.15f, 0.06f, 0x6A40A8, 0.8f * fade, 0);
        }
        for (int k = 0; k < 3; k++) {
            Vec3 from = at.add(r.nextGaussian() * 0.6, r.nextGaussian() * 0.5 + 0.3, r.nextGaussian() * 0.6);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), from, from.add(r.nextGaussian(), r.nextGaussian() * 0.6, r.nextGaussian()), seed + 400 + k, 0.3f, 0.05f, 0xF0E080, 0.7f * fade, 1);
        }
        Vec3 headAt = at.add(f.scale(1.25)).add(0, 0.85, 0);
        Vec3 rgt = f.cross(UP).normalize();
        for (int sd = -1; sd <= 1; sd += 2) {
            FxDraw.billboard(FxDraw.glow(c.buffers()), c.ps(), c.camera(), headAt.add(rgt.scale(sd * 0.13)).add(f.scale(0.15)), 0.12f, 0.08f, 0,
                    FxDraw.color(0xFFF070, fade), FxDraw.FULL);
        }
    }

    /** False Darkness: a thick, jagged spear of lightning from the caster's mouth, with a pointed head. */
    static void falseDarkness(FxClient.Ctx c) {
        float age = c.age();
        Vec3 a = c.fx().a, b = c.fx().b;
        if (age < 5) {                                               // gathering in the mouth
            VertexConsumer add = FxDraw.additive(c.buffers());
            FxDraw.billboard(add, c.ps(), c.camera(), a, 0.4f + age * 0.15f, 0.4f + age * 0.15f, age, FxDraw.addColor(0xCFE4FF, 0.8f), FxDraw.FULL);
            return;
        }
        float fade = fadeOut(c, 8);
        long seed = c.fx().seed + (long) age;
        FxDraw.bolt(c.buffers(), c.ps(), c.cam(), a, b, seed, 0.6f, 0.45f, 0x7AA8FF, fade, 5);
        FxDraw.bolt(c.buffers(), c.ps(), c.cam(), a, b, seed + 7, 0.9f, 0.18f, 0xBFD8FF, fade, 3);
        Vec3 dir = b.subtract(a).normalize();
        FxDraw.cone(FxDraw.additive(c.buffers()), c.ps(), b.subtract(dir.scale(1.5)), b.add(dir.scale(0.8)), 0.5f, 8, FxDraw.addColor(0xFFFFFF, 0.8f * fade), FxDraw.FULL);
        FxDraw.billboard(FxDraw.additive(c.buffers()), c.ps(), c.camera(), b, 2.5f, 2.5f, age, FxDraw.addColor(0x9CC8FF, 0.6f * fade), FxDraw.FULL);
    }

    /** Lightning Beast Running: a hound made of crackling blue-white lightning racing along the ground. */
    static void lightningHound(FxClient.Ctx c) {
        float age = c.age();
        Vec3 at = head(c, 4, true).subtract(0, 0.6, 0).add(0, 0.9, 0);
        Vec3 f = heading(c);
        float fade = fadeOut(c, 4);
        long seed = c.fx().seed + (long) (age * 3);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (Vec3[] bone : beast(at, f, 1.2f, age * 1.1f, false)) {
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), bone[0], bone[1], seed + (long) (bone[0].x * 97), 0.12f, 0.08f, 0x9CC8FF, fade, 0);
        }
        FxDraw.billboard(add, c.ps(), c.camera(), at.add(0, 0.3, 0), 2.6f, 1.8f, 0, FxDraw.addColor(0x6AA8FF, 0.35f * fade), FxDraw.FULL);
        List<Vec3> trail = new ArrayList<>();                         // the streak it leaves
        for (int i = 0; i <= 5; i++) trail.add(at.subtract(f.scale(1 + i * 0.7)).add(0, 0.1 * Mth.sin(age + i), 0));
        FxDraw.ribbon(add, c.ps(), c.cam(), trail, 0.5f, 1f, FxDraw.addColor(0x9CC8FF, 0.5f * fade), FxDraw.addColor(0x9CC8FF, 0f), FxDraw.FULL);
    }

    // ================================================================ earth

    /** Earth Spear: cracks spread, then a tall, rough spear of stone thrusts up out of the ground and sinks back. */
    static void earthSpear(FxClient.Ctx c) {
        float age = c.age();
        Vec3 g = c.fx().a;
        int light = FxDraw.lightAt(g.add(0, 1, 0));
        VertexConsumer blocks = FxDraw.blocks(c.buffers());
        Paint stone = FxDraw.block("minecraft:block/stone", 0xFFFFFF, 1f);
        Paint cobble = FxDraw.block("minecraft:block/cobblestone", 0xFFFFFF, 1f);
        RandomSource r = FxDraw.rng(c.fx().seed, 55);
        if (age < 10) {                                              // cracks
            VertexConsumer glow = FxDraw.glow(c.buffers());
            for (int k = 0; k < 7; k++) {
                float a = k * Mth.TWO_PI / 7 + r.nextFloat() * 0.4f;
                float len = (0.4f + age / 10f) * (1.2f + r.nextFloat());
                Vec3 to = g.add(Mth.cos(a) * len, 0.03, Mth.sin(a) * len);
                FxDraw.ribbon(glow, c.ps(), c.cam(), List.of(g.add(0, 0.03, 0), to), 0.08f, 1f, FxDraw.color(0x2A2420, 0.9f), FxDraw.color(0x2A2420, 0.2f), light);
            }
            return;
        }
        float t = age - 10;
        float rise = FxDraw.smooth(Math.min(1f, t / 3f)) * (1f - FxDraw.smooth(Mth.clamp((t - 35) / 12f, 0f, 1f)));
        float h = 6.5f * rise;
        if (h < 0.05f) return;
        FxDraw.cone(blocks, c.ps(), g.subtract(0, 0.4, 0), g.add(0, h, 0), 0.9f, 7, stone, light);
        for (int k = 0; k < 5; k++) {                                // rough spurs round its base
            float a = k * 1.3f + r.nextFloat();
            Vec3 base = g.add(Mth.cos(a) * 0.7, -0.2, Mth.sin(a) * 0.7);
            FxDraw.cone(blocks, c.ps(), base, base.add(Mth.cos(a) * 0.4, h * (0.25f + r.nextFloat() * 0.2f), Mth.sin(a) * 0.4), 0.35f, 5, cobble, light);
        }
    }

    /** A dragon's head of earth: it heaves up out of the ground, jaws opening to spit mud, then crumbles. */
    static void earthDragon(FxClient.Ctx c) {
        float age = c.age();
        Vec3 base = c.fx().a;
        Vec3 f = c.fx().b.subtract(base).normalize();
        Vec3 r = f.cross(UP).normalize();
        float up = FxDraw.smooth(Math.min(1f, age / 8f));
        float sink = FxDraw.smooth(Mth.clamp((age - 36) / 10f, 0f, 1f));
        float lift = up * (1 - sink);
        if (lift < 0.02f) return;
        int light = FxDraw.lightAt(base.add(0, 2, 0));
        VertexConsumer blocks = FxDraw.blocks(c.buffers());
        Paint dirt = FxDraw.block("minecraft:block/coarse_dirt", 0xFFFFFF, 1f);
        Paint mud = FxDraw.block("minecraft:block/mud", 0xFFFFFF, 1f);
        Paint stone = FxDraw.block("minecraft:block/stone", 0xFFFFFF, 1f);
        Vec3 neckTop = base.add(0, 2.4 * lift, 0).add(f.scale(0.4 * lift));
        FxDraw.tube(blocks, c.ps(), List.of(base.subtract(0, 0.5, 0), base.add(0, 1.2 * lift, 0), neckTop), new float[]{1.1f, 0.9f, 0.8f}, 8, dirt, 0.5f, light, false);
        float open = 0.15f + 0.25f * Math.max(0, Mth.sin(age * 0.5f));
        Vec3 head = neckTop.add(f.scale(0.5));
        FxDraw.box(blocks, c.ps(), head.add(0, 0.35, 0), r.scale(0.55), new Vec3(0, 0.35, 0), f.scale(0.8), mud, light);              // skull
        FxDraw.box(blocks, c.ps(), head.add(f.scale(0.35)).subtract(0, open + 0.15, 0), r.scale(0.45), new Vec3(0, 0.15, 0), f.scale(0.65), dirt, light); // jaw
        for (int sd = -1; sd <= 1; sd += 2) {
            FxDraw.cone(blocks, c.ps(), head.add(r.scale(sd * 0.35)).add(0, 0.6, 0).subtract(f.scale(0.3)),
                    head.add(r.scale(sd * 0.5)).add(0, 1.3, 0).subtract(f.scale(1.0)), 0.18f, 5, stone, light);                       // horns
            FxDraw.billboard(FxDraw.glow(c.buffers()), c.ps(), c.camera(), head.add(r.scale(sd * 0.4)).add(0, 0.5, 0).add(f.scale(0.35)), 0.15f, 0.1f, 0,
                    FxDraw.color(0xFFB040, 0.9f), FxDraw.FULL);
        }
    }

    /** A ball of mud flying (wobbling as it goes). */
    static void mudBullet(FxClient.Ctx c) {
        float age = c.age();
        Vec3 at = head(c, 1, false);
        int light = FxDraw.lightAt(at);
        float wob = 1f + 0.12f * Mth.sin(age * 1.7f);
        FxDraw.sphere(FxDraw.lit(c.buffers()), c.ps(), at, 0.42f * wob, 8, 10, FxDraw.color(0x5A3E22, 1f), light);
        FxDraw.sphere(FxDraw.lit(c.buffers()), c.ps(), at.add(0.08, 0.1, 0), 0.3f, 6, 8, FxDraw.color(0x7A5832, 1f), light);
    }

    /** Earth Sandwich: two great slabs of earth heave up either side of the target and slam together. */
    static void earthSandwich(FxClient.Ctx c) {
        float age = c.age();
        Vec3 g = c.fx().a;
        Vec3 side = c.fx().b.subtract(g).normalize();
        Vec3 along = side.cross(UP).normalize();
        int light = FxDraw.lightAt(g.add(0, 2, 0));
        float rise = FxDraw.smooth(Math.min(1f, age / 10f));
        float close = FxDraw.smooth(Mth.clamp((age - 12) / 5f, 0f, 1f));
        float sink = FxDraw.smooth(Mth.clamp((age - 32) / 12f, 0f, 1f));
        float h = 7f * rise * (1 - sink);
        if (h < 0.05f) return;
        VertexConsumer blocks = FxDraw.blocks(c.buffers());
        Paint dirt = FxDraw.block("minecraft:block/coarse_dirt", 0xFFFFFF, 1f);
        Paint rock = FxDraw.block("minecraft:block/stone", 0xFFFFFF, 1f);
        for (int s = -1; s <= 1; s += 2) {
            double gap = Mth.lerp(close, 4.0, 0.75);
            Vec3 centre = g.add(side.scale(s * gap)).add(0, h / 2 - 0.5, 0);
            FxDraw.box(blocks, c.ps(), centre, side.scale(0.7), new Vec3(0, h / 2, 0), along.scale(3.2), dirt, light);
            FxDraw.box(blocks, c.ps(), centre.add(side.scale(s * 0.4)), side.scale(0.3), new Vec3(0, h / 2 * 0.9, 0), along.scale(2.8), rock, light);
        }
    }

    /**
     * Rock Golem: a giant of stone heaves up out of the ground, raises one huge fist and brings it down on the target,
     * then crumbles back into the earth.
     */
    static void rockGolem(FxClient.Ctx c) {
        float age = c.age();
        Vec3 feet = c.fx().a, hit = c.fx().b;
        Vec3 f = new Vec3(hit.x - feet.x, 0, hit.z - feet.z).normalize();
        Vec3 r = f.cross(UP).normalize();
        float rise = FxDraw.smooth(Math.min(1f, age / 20f));
        float crumble = FxDraw.smooth(Mth.clamp((age - 56) / 16f, 0f, 1f));
        float sunk = (1 - rise) * 10 + crumble * 11;
        Vec3 base = feet.subtract(0, sunk, 0);
        int light = FxDraw.lightAt(feet.add(0, 4, 0));
        VertexConsumer blocks = FxDraw.blocks(c.buffers());
        Paint stone = FxDraw.block("minecraft:block/stone", 0xFFFFFF, 1f);
        Paint cobble = FxDraw.block("minecraft:block/cobblestone", 0xFFFFFF, 1f);
        Paint mossy = FxDraw.block("minecraft:block/mossy_cobblestone", 0xFFFFFF, 1f);
        Paint deep = FxDraw.block("minecraft:block/deepslate", 0xFFFFFF, 1f);
        // legs, hips, torso, head
        for (int s = -1; s <= 1; s += 2) {
            FxDraw.box(blocks, c.ps(), base.add(r.scale(s * 1.3)).add(0, 1.6, 0), r.scale(0.8), new Vec3(0, 1.6, 0), f.scale(0.9), cobble, light);
        }
        Vec3 chest = base.add(0, 6.0, 0);
        FxDraw.box(blocks, c.ps(), base.add(0, 3.6, 0), r.scale(2.0), new Vec3(0, 0.6, 0), f.scale(1.2), deep, light);
        FxDraw.box(blocks, c.ps(), chest, r.scale(2.6), new Vec3(0, 2.0, 0), f.scale(1.6), stone, light);
        FxDraw.box(blocks, c.ps(), chest.add(f.scale(1.0)).add(0, 0.6, 0), r.scale(1.6), new Vec3(0, 1.0, 0), f.scale(0.5), mossy, light);
        Vec3 headAt = chest.add(0, 3.0, 0).add(f.scale(0.6));
        FxDraw.box(blocks, c.ps(), headAt, r.scale(0.9), new Vec3(0, 0.9, 0), f.scale(0.9), cobble, light);
        for (int s = -1; s <= 1; s += 2) {
            FxDraw.billboard(FxDraw.glow(c.buffers()), c.ps(), c.camera(), headAt.add(f.scale(0.92)).add(r.scale(s * 0.38)).add(0, 0.15, 0), 0.3f, 0.18f, 0,
                    FxDraw.color(0xFFA040, 0.95f), FxDraw.FULL);
        }
        // the striking arm (right): raised from 20 to 34, comes down by 38, rests on the ground, then crumbles
        Vec3 shoulder = chest.add(r.scale(3.0)).add(0, 1.4, 0);
        float raise = FxDraw.smooth(Mth.clamp((age - 18) / 14f, 0f, 1f));
        float smash = FxDraw.smooth(Mth.clamp((age - 34) / 4f, 0f, 1f));
        Vec3 up = shoulder.add(0, 6.5, 0).subtract(f.scale(1.5));
        Vec3 rest = shoulder.add(f.scale(2.5)).subtract(0, 3.5, 0);
        Vec3 fist = smash > 0 ? up.lerp(hit.add(0, 1.2, 0), smash) : rest.lerp(up, raise);
        fist = fist.subtract(0, crumble * 11, 0);
        Vec3 elbow = shoulder.lerp(fist, 0.5).add(r.scale(1.0)).add(0, 0.6, 0);
        FxDraw.tube(blocks, c.ps(), List.of(shoulder, elbow, fist), new float[]{1.0f, 0.85f, 0.8f}, 6, stone, 0.4f, light, true);
        FxDraw.box(blocks, c.ps(), fist, r.scale(1.3), new Vec3(0, 1.3, 0), f.scale(1.3), cobble, light);
        // the other arm hangs
        Vec3 ls = chest.subtract(r.scale(3.0)).add(0, 1.4, 0);
        Vec3 lh = ls.subtract(r.scale(0.6)).subtract(0, 5, 0).add(f.scale(0.8));
        FxDraw.tube(blocks, c.ps(), List.of(ls, lh), new float[]{0.95f, 0.8f}, 6, stone, 0.4f, light, true);
        FxDraw.box(blocks, c.ps(), lh, r.scale(1.1), new Vec3(0, 1.1, 0), f.scale(1.1), cobble, light);
    }

    // ================================================================ water

    /** Hiding in Mist: a thick, slow white fog that fills the area and thins out at the end. */
    static void mist(FxClient.Ctx c) {
        float age = c.age();
        Vec3 centre = c.fx().a;
        float radius = c.fx().size;
        float fade = Mth.clamp(age / 30f, 0f, 1f) * fadeOut(c, 40);
        if (fade <= 0) return;
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), FxYin.PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 56);
        float spread = Mth.clamp(0.3f + age / 40f, 0.3f, 1f);
        int light = FxDraw.lightAt(centre.add(0, 1, 0));
        for (int k = 0; k < 90; k++) {
            double a = r.nextFloat() * Math.PI * 2, d = Math.sqrt(r.nextFloat()) * radius * spread;
            double drift = age * 0.006 * (r.nextFloat() - 0.5);
            Vec3 p = centre.add(Math.cos(a + drift) * d, 0.4 + r.nextFloat() * 3.2, Math.sin(a + drift) * d);
            float s = 4f + r.nextFloat() * 3.5f;
            int w = 225 + r.nextInt(30);
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.004f,
                    new Paint(0, 0, 1, 1, w, w, Math.min(255, w + 6), Math.round(150 * fade)), light);
        }
    }
}
