package com.shinobiarts.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;

/**
 * Shikkotsu Forest's sky: a normal sky with sun and clouds, but thick mist everywhere (the same close fog the game uses
 * in the Nether), in the biome's pale grey-green fog colour, dimming at night.
 */
public class MistSky extends DimensionSpecialEffects {
    public MistSky() {
        super(192f, true, SkyType.NORMAL, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        return fogColor.multiply(brightness * 0.94F + 0.06F, brightness * 0.94F + 0.06F, brightness * 0.91F + 0.09F);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return true;
    }
}
