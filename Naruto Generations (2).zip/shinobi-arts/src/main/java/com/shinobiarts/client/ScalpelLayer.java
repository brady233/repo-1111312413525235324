package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Chakra Scalpel: a thin, glowing green blade of chakra on each hand, from the fingertips out past them, flickering,
 * with a soft green glow round the hand.
 */
public class ScalpelLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final int CORE = 0xD8FFE4, GLOW = 0x4BFF8A;

    public ScalpelLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbAmount,
                       float partial, float age, float headYaw, float headPitch) {
        if (player.isInvisible() || (ClientEyes.look(player) & SharinganManager.LOOK_SCALPEL) == 0) return;
        VertexConsumer glow = FxDraw.glow(buffers), add = FxDraw.additive(buffers);
        float flick = 0.8f + 0.2f * Mth.sin(age * 1.7f) * Mth.cos(age * 0.9f);
        for (int side = 0; side < 2; side++) {
            ps.pushPose();
            (side == 0 ? getParentModel().rightArm : getParentModel().leftArm).translateAndRotate(ps);
            float sx = side == 0 ? -1f / 16f : 1f / 16f;             // the middle of the arm (arm space: y down along it, -z forward)
            Vec3 root = new Vec3(sx, 0.66, -0.02), tip = new Vec3(sx, 1.12, -0.16);
            // the blade: two crossed, tapering planes of light, white-green core and a green edge
            for (int plane = 0; plane < 2; plane++) {
                Vec3 w = plane == 0 ? new Vec3(0.055, 0, 0) : new Vec3(0, 0, 0.055);
                FxDraw.quad(glow, ps, root.subtract(w), root.add(w), tip.add(w.scale(0.15)), tip.subtract(w.scale(0.15)), FxDraw.color(CORE, 0.85f * flick), FxDraw.FULL);
                Vec3 w2 = w.scale(1.9);
                FxDraw.quad(add, ps, root.subtract(w2), root.add(w2), tip.add(w2.scale(0.2)), tip.subtract(w2.scale(0.2)), FxDraw.addColor(GLOW, 0.6f * flick), FxDraw.FULL);
            }
            FxDraw.sphere(add, ps, new Vec3(sx, 0.62, 0), 0.13f, 5, 8, FxDraw.addColor(GLOW, 0.35f * flick), FxDraw.FULL);   // the hand glowing
            ps.popPose();
        }
    }
}
