package com.shinobiarts.client;

import com.shinobiarts.entity.ShadowClone;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/** Draws a shadow clone with its owner's skin, held items and armor (a Water Clone has a film of water over it). */
public class ShadowCloneRenderer extends HumanoidMobRenderer<ShadowClone, PlayerModel<ShadowClone>> {
    public ShadowCloneRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
        this.addLayer(new SharinganEyesLayer<>(this, context.getModelSet()));
        this.addLayer(new WaterSheen(this));
        this.addLayer(new HandBall(this));
    }

    /** A clone holding a copied Rasengan or Rasenshuriken holds it out in its palm like its owner does. */
    @Override
    public void render(ShadowClone clone, float yaw, float partial, com.mojang.blaze3d.vertex.PoseStack ps,
                       net.minecraft.client.renderer.MultiBufferSource buffers, int light) {
        ShadowClone.HandJutsu hand = clone.getHandJutsu();
        boolean ball = hand == ShadowClone.HandJutsu.RASENGAN || hand == ShadowClone.HandJutsu.RASENSHURIKEN;
        getModel().rightArmPose = ball ? RasenganRender.POSE : net.minecraft.client.model.HumanoidModel.ArmPose.EMPTY;
        super.render(clone, yaw, partial, ps, buffers, light);
    }

    /** The ball itself: the same model as the player's, seated in the clone's right palm. */
    private static final class HandBall extends net.minecraft.client.renderer.entity.layers.RenderLayer<ShadowClone, PlayerModel<ShadowClone>> {
        HandBall(net.minecraft.client.renderer.entity.RenderLayerParent<ShadowClone, PlayerModel<ShadowClone>> parent) {
            super(parent);
        }

        @Override
        public void render(com.mojang.blaze3d.vertex.PoseStack ps, net.minecraft.client.renderer.MultiBufferSource buffers, int light,
                           ShadowClone clone, float limbSwing, float limbAmount, float partial, float age, float headYaw, float headPitch) {
            ShadowClone.HandJutsu hand = clone.getHandJutsu();
            if (clone.isInvisible() || (hand != ShadowClone.HandJutsu.RASENGAN && hand != ShadowClone.HandJutsu.RASENSHURIKEN)) return;
            float size = RasenganRender.FULL_SIZE * RasenganRender.IN_HAND;
            ps.pushPose();
            getParentModel().translateToHand(net.minecraft.world.entity.HumanoidArm.RIGHT, ps);
            float radius = size * RasenganRender.MESH_RADIUS / 0.9375f * 16f;
            RasenganRender.palm(ps, 1f, radius);
            ps.scale(1f / 0.9375f, 1f / 0.9375f, 1f / 0.9375f);
            RasenganRender.drawBall(ps, buffers, size, com.shinobiarts.ninja.NinjaData.RASENGAN_FORM_TICKS + age,
                    hand == ShadowClone.HandJutsu.RASENSHURIKEN);
            ps.popPose();
        }
    }

    /** Water Clones: a film of moving water over the whole body. */
    private static final class WaterSheen extends net.minecraft.client.renderer.entity.layers.RenderLayer<ShadowClone, PlayerModel<ShadowClone>> {
        private static final ResourceLocation WATER = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/entity/jutsu/water_dragon.png");

        WaterSheen(net.minecraft.client.renderer.entity.RenderLayerParent<ShadowClone, PlayerModel<ShadowClone>> parent) {
            super(parent);
        }

        @Override
        public void render(com.mojang.blaze3d.vertex.PoseStack ps, net.minecraft.client.renderer.MultiBufferSource buffers, int light,
                           ShadowClone clone, float limbSwing, float limbAmount, float partial, float age, float headYaw, float headPitch) {
            if (!clone.isWater() || clone.isInvisible()) return;
            float t = age * 0.01f;
            getParentModel().renderToBuffer(ps, buffers.getBuffer(net.minecraft.client.renderer.RenderType.energySwirl(WATER, t % 1f, (t * 1.7f) % 1f)),
                    light, net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY, 0.45f, 0.7f, 0.95f, 1f);
        }
    }

    @Override
    public ResourceLocation getTextureLocation(ShadowClone clone) {
        UUID owner = clone.getOwnerUUID();
        if (owner == null) return DefaultPlayerSkin.getDefaultSkin();
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        PlayerInfo info = connection == null ? null : connection.getPlayerInfo(owner);
        return info != null ? info.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(owner);
    }
}
