package com.shinobiarts.client;

import net.minecraft.client.Minecraft;

/** Client-only entry points that common code may call through DistExecutor. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openWallet() {
        Minecraft.getInstance().setScreen(new WalletScreen());
    }

    public static void openStats() {
        Minecraft.getInstance().setScreen(new StatScreen());
    }

    /** The ninja network: team, marks and bounties (its own key). */
    public static void openNetwork() {
        Minecraft.getInstance().setScreen(new StatScreen(true));
    }

    /** Opens the writing screen for the blank scroll in {@code hand}. */
    public static void openScrollWriting(net.minecraft.world.InteractionHand hand, net.minecraft.world.item.ItemStack stack) {
        net.minecraft.client.Minecraft.getInstance().setScreen(new ScrollWriteScreen(hand, stack));
    }

    /** The bounty board arrived: the Bounties page of the ninja menu shows it. */
    public static void bountyBoard(net.minecraft.nbt.CompoundTag tag) {
        StatScreen.bountyBoard = tag;
        if (net.minecraft.client.Minecraft.getInstance().screen instanceof StatScreen screen) screen.boardArrived();
    }

    /** Opens or refreshes the quest board / Kage menu with data from the server. */
    public static void openBoard(net.minecraft.nbt.CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if ("kage".equals(tag.getString("Screen"))) {
            if (mc.screen instanceof KageScreen kage) kage.update(tag);
            else mc.setScreen(new KageScreen(tag));
        } else {
            if (mc.screen instanceof StatScreen stats && stats.showsQuests()) stats.updateQuests(tag); // the Quests page
            else if (mc.screen instanceof QuestBoardScreen board) board.update(tag);
            else mc.setScreen(new QuestBoardScreen(tag));
        }
    }

    /**
     * Applies a data sync from the server, and flashes the Sharingan across the screen when the eyes are
     * switched on or evolve (not on the first sync after joining).
     */
    public static void applySync(net.minecraft.nbt.CompoundTag tag) {
        com.shinobiarts.ninja.NinjaData before = ClientNinjaData.get();
        boolean known = before.isInitialized();
        boolean wasOn = before.isSharinganActive();
        boolean wasByakugan = before.getActiveDojutsu() == com.shinobiarts.ninja.Dojutsu.BYAKUGAN;
        int oldStage = before.activeSharinganStage();
        com.shinobiarts.ninja.MangekyouDesign oldDesign = before.getMangekyouDesign();
        ClientNinjaData.apply(tag);
        com.shinobiarts.ninja.NinjaData now = ClientNinjaData.get();
        if (!known) return;
        if (now.getActiveDojutsu() == com.shinobiarts.ninja.Dojutsu.BYAKUGAN && !wasByakugan) {
            SharinganFlash.playByakugan();
            return;
        }
        if (now.getSharinganStage() <= 0) return;
        int stage = now.activeSharinganStage();
        boolean newPattern = stage == com.shinobiarts.ninja.Dojutsu.MANGEKYOU && now.getMangekyouDesign() != oldDesign;
        if ((now.isSharinganActive() && !wasOn) || stage > oldStage || newPattern) {
            SharinganFlash.play(stage, now.getMangekyouDesign());
        }
    }
}
