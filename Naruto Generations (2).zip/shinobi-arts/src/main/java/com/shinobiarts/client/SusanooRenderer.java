package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.SusanooEntity;
import com.shinobiarts.ninja.Susanoo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Draws a Susanoo from its smooth mesh (SusanooModel), the way the preview pictures were made:
 * <ol>
 *   <li>a see-through body, each material tinted with the owner's colour for its slot (body, armor, weapon, eyes),
 *       with a rim of chakra light around every edge (worked out per vertex from how much it faces away from you);</li>
 *   <li>full-bright glow maps on the eyes, crystal and blade;</li>
 *   <li>a soft additive halo: the edges again, pushed out a little along their normals.</li>
 * </ol>
 * Bones are posed every frame (SusanooPose: breathing, walking, wing beats, the keyframed swings and blocking).
 * It stands where its owner is (their smooth, interpolated position, not the entity's), turning with their body
 * (the Perfect Susanoo turns with where they look). Back faces are skipped before anything is sent to the GPU.
 */
public class SusanooRenderer extends EntityRenderer<SusanooEntity> {
    private static final ResourceLocation WHITE = tex("white");
    private static final Map<String, ResourceLocation> TEXTURES = new HashMap<>();
    private static final String[] SLOTS = {"body", "armor", "weapon", "eyes", "chakra", "aura"};

    // per-frame scratch: every vertex of the model, transformed to view space (camera at the origin)
    private float[] px = new float[0], py = new float[0], pz = new float[0], nx = new float[0], ny = new float[0], nz = new float[0], rim = new float[0];
    /** While it forms: how far up (model units) the current material has built itself, and how soft that edge is. */
    private float revealY = Float.MAX_VALUE, revealSoft = 1f;
    /** Lowest and highest point of each model, for building it up from the ground. */
    private static final Map<SusanooModel, float[]> Y_RANGE = new java.util.IdentityHashMap<>();

    public SusanooRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0f;
    }

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/" + name + ".png");
    }

    private static ResourceLocation texture(String name) {
        return TEXTURES.computeIfAbsent(name, SusanooRenderer::tex);
    }

    @Override
    public ResourceLocation getTextureLocation(SusanooEntity entity) {
        return WHITE;
    }

    @Override
    public boolean shouldRender(SusanooEntity e, Frustum frustum, double camX, double camY, double camZ) {
        if (!e.shouldRender(camX, camY, camZ)) return false;
        double grow = e.getStage() == 5 ? 20 : 4; // arms, swords and wings reach past the hitbox
        return frustum.isVisible(e.getBoundingBox().inflate(grow, 3, grow));
    }

    @Override
    public void render(SusanooEntity e, float entityYaw, float partial, PoseStack ps, MultiBufferSource buffers, int packedLight) {
        int stage = e.getStage();
        SusanooModel model = SusanooModel.get(stage, e.designModel());
        if (model == null) return;
        Minecraft mc = Minecraft.getInstance();
        Player owner = e.getOwner();
        Vec3 at = e.getPosition(partial);
        float yaw;
        ps.pushPose();
        if (owner != null) {
            yaw = stage == 5 ? owner.getViewYRot(partial) : Mth.rotLerp(partial, owner.yBodyRotO, owner.yBodyRot);
            Vec3 feet = Susanoo.feetFor(owner, stage, owner.getPosition(partial), yaw);
            ps.translate(feet.x - at.x, feet.y - at.y, feet.z - at.z);
        } else {
            yaw = Mth.rotLerp(partial, e.yRotO, e.getYRot());
        }
        ps.mulPose(Axis.YP.rotationDegrees(-yaw));
        // it builds itself up over formSeconds: bones first, then the body, then the armor and weapons, each rising
        // from the ground, while the whole thing swells to its full size
        float formTicks = (float) Math.max(1.0, com.shinobiarts.Config.d(com.shinobiarts.Config.SUSANOO_FORM_SECONDS) * 20.0);
        float form = Mth.clamp((e.tickCount - e.summonStart + partial) / formTicks, 0f, 1f);
        float grow = 1 - (1 - form) * (1 - form);
        float s = model.scale / 16f * (0.82f + 0.18f * grow);
        ps.scale(s, s, s);
        float[] yr = yRange(model);

        Matrix4f[] bones = SusanooPose.bones(model, e, owner, yaw, partial);
        boolean firstPerson = owner != null && owner == mc.getCameraEntity() && mc.options.getCameraType().isFirstPerson();
        float[] boneAlpha = boneAlpha(model, stage, firstPerson, owner != null);
        // seen from inside (first person) it's fainter, more so when you ride in its chest
        float fade = (firstPerson && stage < 5 ? (Susanoo.holdsInChest(stage) ? 0.3f : 0.5f) : 1f) * (0.55f + 0.45f * grow);
        double dist = mc.gameRenderer.getMainCamera().getPosition().distanceTo(at);
        boolean halo = !(firstPerson && stage < 5) && dist < 96;

        float[][] colors = new float[6][];
        for (int i = 0; i < 6; i++) colors[i] = rgb(e.getColor(i));
        transformAll(model, ps.last(), bones);
        float time = e.tickCount + partial;
        org.joml.Vector3f up = new org.joml.Vector3f(0, 1, 0).mul(ps.last().normal()).normalize();
        dance(model, up, time, s);

        // 1. the bodies, one batch per material
        for (Map.Entry<String, List<SusanooModel.Piece>> en : model.byMaterial.entrySet()) {
            SusanooModel.Material mat = SusanooModel.materials().get(en.getKey());
            if (mat == null) continue;
            float[] tint = tint(mat, colors);
            float[] glow = glow(mat, colors);
            float rimK = mat.name.equals("shadow") ? 0f : mat.name.equals("eye") ? 0.3f : 0.75f;
            reveal(yr, mat.name, form);
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(texture(mat.texture)));
            for (SusanooModel.Piece p : en.getValue()) {
                float a = boneAlpha[p.bone] * fade;
                if (a > 0.01f) body(vc, p, tint, glow, mat.opacity * a, rimK, a);
            }
        }
        // 2. glowing details (eyes, crystal, blade edge)
        for (Map.Entry<String, List<SusanooModel.Piece>> en : model.byMaterial.entrySet()) {
            SusanooModel.Material mat = SusanooModel.materials().get(en.getKey());
            if (mat == null || !mat.glowPass) continue;
            float[] glow = glow(mat, colors);
            float k = mat.name.equals("eye") ? 1.0f : 0.55f;
            reveal(yr, mat.name, form);
            VertexConsumer vc = buffers.getBuffer(RenderType.eyes(texture(mat.texture + "_glow")));
            for (SusanooModel.Piece p : en.getValue()) {
                float a = boneAlpha[p.bone] * fade;
                if (a > 0.01f) flat(vc, p, glow[0] * k * a, glow[1] * k * a, glow[2] * k * a);
            }
        }
        // 3. the halo
        if (halo) {
            VertexConsumer vc = buffers.getBuffer(RenderType.eyes(WHITE));
            for (Map.Entry<String, List<SusanooModel.Piece>> en : model.byMaterial.entrySet()) {
                SusanooModel.Material mat = SusanooModel.materials().get(en.getKey());
                if (mat == null || mat.name.equals("shadow")) continue;
                float[] glow = glow(mat, colors);
                boolean eye = mat.name.equals("eye");
                float k = eye ? 1.6f : 0.55f, push = (eye ? 0.5f : 0.8f) * s;
                reveal(yr, mat.name, form);
                for (SusanooModel.Piece p : en.getValue()) {
                    float a = boneAlpha[p.bone] * fade;
                    if (a > 0.01f) halo(vc, p, glow[0] * k * a, glow[1] * k * a, glow[2] * k * a, push);
                }
            }
        }
        // 4. its chakra coming off it as glowing fog: soft wisps of its own colour drifting up and away off its edges
        if (halo) {
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(FOG));
            float[] fire = mix(colors[4], colors[5], 0.5f);
            float[] light = mix(fire, new float[]{1, 1, 1}, 0.3f);
            for (Map.Entry<String, List<SusanooModel.Piece>> en : model.byMaterial.entrySet()) {
                SusanooModel.Material mat = SusanooModel.materials().get(en.getKey());
                if (mat == null || mat.name.equals("shadow") || mat.name.equals("eye") || mat.name.equals("gem")) continue;
                reveal(yr, mat.name, form);
                for (SusanooModel.Piece p : en.getValue()) {
                    float a = boneAlpha[p.bone] * fade;
                    if (a < 0.01f) continue;
                    fog(vc, p, fire, light, a, s, up, time);
                }
            }
        }
        ps.popPose();
        revealY = Float.MAX_VALUE;
    }

    private static final net.minecraft.resources.ResourceLocation FOG =
            new net.minecraft.resources.ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/entity/susanoo/fog.png");

    /**
     * Glowing fog off a piece: from points round its outline, soft puffs of chakra rise, swell, drift outward and fade,
     * each on its own cycle, so a steady haze streams up off the whole body. Drawn in view space (screen-facing).
     */
    private void fog(VertexConsumer vc, SusanooModel.Piece p, float[] color, float[] bright, float strength, float s,
                     org.joml.Vector3f up, float t) {
        int n = p.vertices();
        int step = Math.max(1, n / 18);
        for (int v = 0; v < n; v += step) {
            int o = p.offset + v;
            if (rim[o] < 0.25f) continue;
            float y = p.pos[v * 3 + 1];
            float shown = revealed(y);
            if (shown <= 0.01f) continue;
            int h = o * 0x9E3779B1;
            float offset = ((h >>> 8) & 0xFFFF) / 65535f;
            float life = (t / 46f + offset) % 1f;                  // 0 born .. 1 gone
            float rise = (3f + 20f * life) * s;
            float drift = (1f + 5f * life) * s;
            float cx = px[o] + up.x * rise + nx[o] * drift;
            float cy = py[o] + up.y * rise + ny[o] * drift;
            float cz = pz[o] + up.z * rise + nz[o] * drift;
            float size = (3f + 9f * life) * s;
            float alpha = Mth.sin(life * Mth.PI) * 0.32f * strength * shown;
            float[] c = life < 0.35f ? bright : color;
            float spin = offset * 6.28f + t * 0.01f;
            float cs = Mth.cos(spin) * size, sn = Mth.sin(spin) * size;
            float[][] corner = {{-cs + sn, -sn - cs}, {cs + sn, sn - cs}, {cs - sn, sn + cs}, {-cs - sn, -sn + cs}};
            float[][] uv = {{0, 1}, {1, 1}, {1, 0}, {0, 0}};
            for (int k = 0; k < 4; k++) {
                vc.vertex(cx + corner[k][0], cy + corner[k][1], cz, c[0], c[1], c[2], alpha, uv[k][0], uv[k][1],
                        OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0f, 0f, 1f);
            }
        }
    }

    /** A cheap, smooth, moving flicker (0..1) at a model-space point: the flames' shape and how they dance. */
    private static float flicker(float x, float y, float z, float t, float seed) {
        float a = Mth.sin(x * 0.21f + t * 0.31f + seed) * Mth.cos(z * 0.17f - t * 0.27f + seed * 1.3f);
        float b = Mth.sin(y * 0.13f - t * 0.62f + seed * 0.7f) * Mth.cos((x + z) * 0.09f + t * 0.19f);
        return Mth.clamp(0.5f + 0.5f * a + 0.35f * b, 0f, 1f);
    }

    /**
     * The flame tongues hanging off it (the "flame" material: the skirt, the mane, round the base) sway and flicker
     * upward instead of standing still.
     */
    private void dance(SusanooModel model, org.joml.Vector3f up, float t, float s) {
        List<SusanooModel.Piece> list = model.byMaterial.get("flame");
        if (list == null) return;
        float ux = up.x, uy = up.y, uz = up.z;
        for (SusanooModel.Piece p : list) {
            float[] pos = p.pos;
            for (int v = 0; v < p.vertices(); v++) {
                int o = p.offset + v;
                float x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2];
                float f = flicker(x, y, z, t * 1.6f, 3f);
                float sway = Mth.sin(t * 0.35f + y * 0.12f + x * 0.2f) * 1.6f * s;
                float lift = (f - 0.4f) * 4f * s;
                px[o] += ux * lift + nx[o] * sway * 0.5f;
                py[o] += uy * lift + ny[o] * sway * 0.5f;
                pz[o] += uz * lift + nz[o] * sway * 0.5f;
            }
        }
    }

    /**
     * A shell of fire round a piece: like the halo, its edges pushed out along their normals, but each point also
     * pulled upward by a moving flicker, more so where the surface faces up, so tongues of flame lick up off the
     * shoulders, head and arms and dance as they burn.
     */
    private void flames(VertexConsumer vc, SusanooModel.Piece p, float[] color, float strength, float push, float height,
                        org.joml.Vector3f up, float t, float seed) {
        int[] idx = p.idx;
        float[] pos = p.pos;
        for (int k = 0; k < idx.length; k += 3) {
            int la = idx[k], lb = idx[k + 1], lc = idx[k + 2];
            int a = p.offset + la, b = p.offset + lb, c = p.offset + lc;
            float ra = rim[a], rb = rim[b], rc = rim[c];
            if (ra < 0.15f && rb < 0.15f && rc < 0.15f) continue;   // only round the outline
            if (back(a, b, c)) continue;
            int[] corners = {la, lb, lc, lc};
            for (int local : corners) {
                int o = p.offset + local;
                float x = pos[local * 3], y = pos[local * 3 + 1], z = pos[local * 3 + 2];
                float f = flicker(x, y, z, t, seed);
                float facingUp = Math.max(0f, nx[o] * up.x + ny[o] * up.y + nz[o] * up.z);
                float lift = height * f * f * (0.35f + 0.65f * facingUp);
                float out = push * (0.6f + 0.8f * f);
                float k2 = rim[o] * strength * (0.4f + 0.6f * f) * revealed(y);
                vc.vertex(px[o] + nx[o] * out + up.x * lift, py[o] + ny[o] * out + up.y * lift, pz[o] + nz[o] * out + up.z * lift,
                        color[0] * k2, color[1] * k2, color[2] * k2, 1f, 0.5f, 0.5f, OverlayTexture.NO_OVERLAY,
                        LightTexture.FULL_BRIGHT, nx[o], ny[o], nz[o]);
            }
        }
    }

    /** When each material starts forming, as a share of the forming time: bones, then the body, then armor and weapons. */
    private static float delay(String material) {
        if (material.startsWith("bone")) return 0f;
        if (material.equals("muscle") || material.equals("flame") || material.equals("shadow")) return 0.25f;
        return 0.5f;
    }

    /** Sets how far up this material has built itself so far ({@code form} 0..1 over the whole forming time). */
    private void reveal(float[] yr, String material, float form) {
        float d = delay(material);
        float t = Mth.clamp((form - d) / (1f - d), 0f, 1f);
        float h = yr[1] - yr[0];
        revealSoft = Math.max(1f, h * 0.15f);
        revealY = t >= 1f ? Float.MAX_VALUE : yr[0] + (h + revealSoft) * (1 - (1 - t) * (1 - t));
    }

    /** 0..1: how much of a point at model height {@code y} has formed. */
    private float revealed(float y) {
        return revealY == Float.MAX_VALUE ? 1f : Mth.clamp((revealY - y) / revealSoft, 0f, 1f);
    }

    private static float[] yRange(SusanooModel model) {
        if (Y_RANGE.size() > 16) Y_RANGE.clear();               // models are rebuilt on a resource reload
        return Y_RANGE.computeIfAbsent(model, m -> {
            float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (List<SusanooModel.Piece> list : m.byMaterial.values()) {
                for (SusanooModel.Piece p : list) {
                    for (int i = 1; i < p.pos.length; i += 3) {
                        lo = Math.min(lo, p.pos[i]);
                        hi = Math.max(hi, p.pos[i]);
                    }
                }
            }
            return lo > hi ? new float[]{0, 1} : new float[]{lo, hi};
        });
    }

    /** Hidden or faded bones: in the Perfect Susanoo's head, the rider looks out (first person: no head at all). */
    private static float[] boneAlpha(SusanooModel model, int stage, boolean firstPerson, boolean ridden) {
        float[] out = new float[model.bones.length];
        for (int i = 0; i < out.length; i++) {
            SusanooModel.Bone b = model.bones[i];
            float own = 1f;
            if (stage == 5 && b.name.equals("head")) own = firstPerson ? 0f : ridden ? 0.35f : 1f;
            out[i] = (b.parent >= 0 ? out[b.parent] : 1f) * own;
        }
        return out;
    }

    private static float[] rgb(int c) {
        return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }

    private static int slot(String name) {
        for (int i = 0; i < SLOTS.length; i++) if (SLOTS[i].equals(name)) return i;
        return 0;
    }

    private static float[] mix(float[] a, float[] b, float t) {
        return new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    private static float[] tint(SusanooModel.Material mat, float[][] colors) {
        float[] c = colors[slot(mat.slot)];
        if (mat.name.equals("trim")) return mix(c, new float[]{1, 1, 1}, 0.3f);
        if (mat.name.equals("shadow")) return new float[]{c[0] * 0.12f, c[1] * 0.12f, c[2] * 0.12f};
        return c;
    }

    /** The chakra light on a material: the chakra colour, a little of the part's own, a little white. */
    private static float[] glow(SusanooModel.Material mat, float[][] colors) {
        if (mat.name.equals("eye")) return colors[3];
        return mix(mix(colors[4], colors[slot(mat.slot)], 0.35f), new float[]{1, 1, 1}, 0.2f);
    }

    private void ensure(int n) {
        if (px.length >= n) return;
        px = new float[n];
        py = new float[n];
        pz = new float[n];
        nx = new float[n];
        ny = new float[n];
        nz = new float[n];
        rim = new float[n];
    }

    /** Every vertex into view space, with its rim factor (1 at a silhouette edge, 0 facing you). */
    private void transformAll(SusanooModel model, PoseStack.Pose pose, Matrix4f[] bones) {
        ensure(model.totalVertices);
        Matrix4f m = new Matrix4f();
        Matrix3f n = new Matrix3f();
        Matrix3f boneRot = new Matrix3f();
        for (List<SusanooModel.Piece> list : model.byMaterial.values()) {
            for (SusanooModel.Piece p : list) {
                m.set(pose.pose()).mul(bones[p.bone]);
                n.set(pose.normal()).mul(boneRot.set(bones[p.bone]));
                float m00 = m.m00(), m01 = m.m01(), m02 = m.m02(), m10 = m.m10(), m11 = m.m11(), m12 = m.m12();
                float m20 = m.m20(), m21 = m.m21(), m22 = m.m22(), m30 = m.m30(), m31 = m.m31(), m32 = m.m32();
                float n00 = n.m00(), n01 = n.m01(), n02 = n.m02(), n10 = n.m10(), n11 = n.m11(), n12 = n.m12();
                float n20 = n.m20(), n21 = n.m21(), n22 = n.m22();
                float[] pos = p.pos, nrm = p.nrm;
                int count = p.vertices();
                for (int v = 0; v < count; v++) {
                    int i3 = v * 3, o = p.offset + v;
                    float x = pos[i3], y = pos[i3 + 1], z = pos[i3 + 2];
                    float vx = m00 * x + m10 * y + m20 * z + m30, vy = m01 * x + m11 * y + m21 * z + m31, vz = m02 * x + m12 * y + m22 * z + m32;
                    float a = nrm[i3], b = nrm[i3 + 1], c = nrm[i3 + 2];
                    float wx = n00 * a + n10 * b + n20 * c, wy = n01 * a + n11 * b + n21 * c, wz = n02 * a + n12 * b + n22 * c;
                    px[o] = vx;
                    py[o] = vy;
                    pz[o] = vz;
                    nx[o] = wx;
                    ny[o] = wy;
                    nz[o] = wz;
                    float len = Mth.sqrt(vx * vx + vy * vy + vz * vz);
                    float facing = len < 1e-4f ? 1f : Math.abs(wx * vx + wy * vy + wz * vz) / len;
                    float r = 1f - Math.min(1f, facing);
                    rim[o] = r * r;
                }
            }
        }
    }

    /** True if the triangle faces away from the camera (at the origin). */
    private boolean back(int a, int b, int c) {
        float ux = px[b] - px[a], uy = py[b] - py[a], uz = pz[b] - pz[a];
        float vx = px[c] - px[a], vy = py[c] - py[a], vz = pz[c] - pz[a];
        float fx = uy * vz - uz * vy, fy = uz * vx - ux * vz, fz = ux * vy - uy * vx;
        return fx * px[a] + fy * py[a] + fz * pz[a] >= 0;
    }

    private void body(VertexConsumer vc, SusanooModel.Piece p, float[] tint, float[] glow, float opacity, float rimK, float fade) {
        int[] idx = p.idx;
        for (int t = 0; t < idx.length; t += 3) {
            int a = p.offset + idx[t], b = p.offset + idx[t + 1], c = p.offset + idx[t + 2];
            if (back(a, b, c)) continue;
            bodyVertex(vc, p, idx[t], a, tint, glow, opacity, rimK, fade);
            bodyVertex(vc, p, idx[t + 1], b, tint, glow, opacity, rimK, fade);
            bodyVertex(vc, p, idx[t + 2], c, tint, glow, opacity, rimK, fade);
            bodyVertex(vc, p, idx[t + 2], c, tint, glow, opacity, rimK, fade); // triangles go in as quads with a repeated corner
        }
    }

    private void bodyVertex(VertexConsumer vc, SusanooModel.Piece p, int local, int o, float[] tint, float[] glow, float opacity, float rimK, float fade) {
        float r = rim[o], k = r * 0.6f * rimK;
        float red = tint[0] + (glow[0] - tint[0]) * k, green = tint[1] + (glow[1] - tint[1]) * k, blue = tint[2] + (glow[2] - tint[2]) * k;
        float alpha = Math.min(1f, opacity + r * 0.4f * rimK * fade) * revealed(p.pos[local * 3 + 1]);
        vc.vertex(px[o], py[o], pz[o], red, green, blue, alpha, p.uv[local * 2], p.uv[local * 2 + 1], OverlayTexture.NO_OVERLAY,
                LightTexture.FULL_BRIGHT, nx[o], ny[o], nz[o]);
    }

    private void flat(VertexConsumer vc, SusanooModel.Piece p, float r, float g, float b) {
        int[] idx = p.idx;
        for (int t = 0; t < idx.length; t += 3) {
            int a = p.offset + idx[t], bb = p.offset + idx[t + 1], c = p.offset + idx[t + 2];
            if (back(a, bb, c)) continue;
            int[] corners = {idx[t], idx[t + 1], idx[t + 2], idx[t + 2]};
            for (int local : corners) {
                int o = p.offset + local;
                float rv = revealed(p.pos[local * 3 + 1]);
                vc.vertex(px[o], py[o], pz[o], r * rv, g * rv, b * rv, 1f, p.uv[local * 2], p.uv[local * 2 + 1], OverlayTexture.NO_OVERLAY,
                        LightTexture.FULL_BRIGHT, nx[o], ny[o], nz[o]);
            }
        }
    }

    private void halo(VertexConsumer vc, SusanooModel.Piece p, float r, float g, float b, float push) {
        int[] idx = p.idx;
        for (int t = 0; t < idx.length; t += 3) {
            int a = p.offset + idx[t], bb = p.offset + idx[t + 1], c = p.offset + idx[t + 2];
            float ra = rim[a] * rim[a], rb = rim[bb] * rim[bb], rc = rim[c] * rim[c];
            if (ra < 0.02f && rb < 0.02f && rc < 0.02f) continue; // only the edges glow
            if (back(a, bb, c)) continue;
            ra *= revealed(p.pos[idx[t] * 3 + 1]);
            rb *= revealed(p.pos[idx[t + 1] * 3 + 1]);
            rc *= revealed(p.pos[idx[t + 2] * 3 + 1]);
            haloVertex(vc, a, r, g, b, ra, push);
            haloVertex(vc, bb, r, g, b, rb, push);
            haloVertex(vc, c, r, g, b, rc, push);
            haloVertex(vc, c, r, g, b, rc, push);
        }
    }

    private void haloVertex(VertexConsumer vc, int o, float r, float g, float b, float k, float push) {
        vc.vertex(px[o] + nx[o] * push, py[o] + ny[o] * push, pz[o] + nz[o] * push, r * k, g * k, b * k, 1f, 0.5f, 0.5f,
                OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, nx[o], ny[o], nz[o]);
    }

    /** Whether the ground is right under its feet (walking) or not (flying). */
    static boolean grounded(SusanooEntity e, Vec3 feet) {
        BlockPos below = BlockPos.containing(feet.x, feet.y - 0.6, feet.z);
        return !e.level().getBlockState(below).getCollisionShape(e.level(), below).isEmpty();
    }
}
