package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.EightGates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * The Eight Gates' chakra (entityA = the user, size = gates open): it burns round them like fire, tongues of their gate's
 * colour licking up off the whole body, taller and wider with every gate, until at the eighth they're wreathed in a
 * blazing column. Re-sent every half second while the gates are open, so it goes when they close.
 */
final class FxGates {
    private FxGates() {}


    private static final ResourceLocation FOG = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/fog.png");

    /**
     * Charging chakra (size = the player's chakra colour as RGB): the Susanoo's glowing fog in their own colour, thick
     * enough to swallow the whole body, boiling up off them and pouring away overhead.
     */
    static void chargeAura(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null || e.isInvisible()) return;
        int rgb = Math.round(c.fx().size) & 0xFFFFFF;
        chakraFog(c, e, rgb, 1.0f);
        Vec3 base = e.getPosition(c.partial());
        float t = e.tickCount + c.partial();
        float pulse = 0.5f + 0.5f * Mth.sin(t * 0.5f);
        FxDraw.ring(FxDraw.additive(c.buffers()), c.ps(), base.add(0, 0.05, 0), new Vec3(0, 1, 0), 0.9f + 0.25f * pulse, 0.6f, 32,
                FxDraw.addColor(rgb, 0.45f), FxDraw.addColor(rgb, 0f), FxDraw.FULL);
    }

    /**
     * The open gates' chakra (entityA = the user, size = gates open): the same fog in the gate's colour, already dense at
     * the first gate and growing taller, wider and faster with every gate until at the eighth it's a towering blaze.
     */
    static void flame(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null || e.isInvisible()) return;
        int gates = Mth.clamp(Math.round(c.fx().size), 1, 8);
        chakraFog(c, e, EightGates.AURA_RGB[gates], 0.75f + gates * 0.1f);
    }

    /**
     * Susanoo-style chakra fog over a whole body: puffs born all over it (legs, body, arms, head), each swelling, rising
     * and drifting outward before it fades, on its own cycle, so the body is buried in a steady boiling haze; a second,
     * tighter layer hugs the body so none of it shows through bare. Brighter where it's born, the colour where it fades.
     * {@code power} 1 is strong; the eighth gate is about 1.55. In first person it keeps to the edges of the view.
     */
    static void chakraFog(FxClient.Ctx c, Entity e, int rgb, float power) {
        Minecraft mc = Minecraft.getInstance();
        boolean self = e == mc.player && mc.options.getCameraType().isFirstPerson();
        float[] col = {((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f};
        float[] bright = {col[0] * 0.45f + 0.55f, col[1] * 0.45f + 0.55f, col[2] * 0.45f + 0.55f};
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight(), w = e.getBbWidth();
        float t = e.tickCount + c.partial();
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(FOG));
        RandomSource r = RandomSource.create(e.getId() * 7919L);
        // the outer fog: rising, swelling, drifting away
        int puffs = self ? 16 : Math.round(70 * power);
        float rise = (1.2f + 0.9f * power), swell = 0.55f + 0.45f * power, cycle = 34f / power;
        for (int k = 0; k < puffs; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI;
            float y0 = r.nextFloat();                                         // where on the body it's born (0 feet .. 1 head)
            float offset = r.nextFloat();
            float life = (t / cycle + offset) % 1f;                           // 0 born .. 1 gone
            double body = y0 < 0.45f ? w * 0.32 : y0 < 0.78f ? w * 0.55 : w * 0.42;   // legs, chest and arms, head
            double rad = body + life * (0.3 + 0.35 * power);
            if (self) rad = 0.85 + life * 0.4;                                // around you, not in your face
            float y = (self ? Math.min(y0, 0.55f) : y0) * h;
            Vec3 at = base.add(Math.cos(ang) * rad, y + life * life * rise, Math.sin(ang) * rad);
            float size = swell * (0.55f + 1.25f * life);
            float alpha = Mth.sin(life * Mth.PI) * (self ? 0.16f : 0.42f) * Math.min(1.25f, power);
            fogPuff(vc, c, at, size, life < 0.35f ? bright : col, alpha, offset * 6.28f + t * 0.012f);
        }
        if (self) return;
        // the inner layer: short-lived puffs that stay on the body, so it's buried in chakra from head to toe
        int inner = Math.round(34 * Math.min(1.3f, power));
        for (int k = 0; k < inner; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI;
            float y0 = r.nextFloat();
            float offset = r.nextFloat();
            float life = (t / (cycle * 0.6f) + offset) % 1f;
            double body = y0 < 0.45f ? w * 0.3 : y0 < 0.78f ? w * 0.5 : w * 0.38;
            Vec3 at = base.add(Math.cos(ang) * body, y0 * h + life * 0.35f, Math.sin(ang) * body);
            float size = 0.42f + 0.3f * life + 0.1f * power;
            float alpha = Mth.sin(life * Mth.PI) * 0.38f * Math.min(1.2f, power);
            fogPuff(vc, c, at, size, bright, alpha, offset * 6.28f - t * 0.02f);
        }
    }

    private static void fogPuff(VertexConsumer vc, FxClient.Ctx c, Vec3 at, float size, float[] col, float alpha, float spin) {
        FxDraw.Paint paint = new FxDraw.Paint(0f, 0f, 1f, 1f, Math.round(col[0] * 255), Math.round(col[1] * 255), Math.round(col[2] * 255),
                Math.round(255 * Mth.clamp(alpha, 0f, 1f)));
        FxDraw.billboard(vc, c.ps(), c.camera(), at, size, size, spin, paint, FxDraw.FULL);
    }
}
