package com.shinobiarts.village;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.permission.PermissionAPI;
import net.minecraftforge.server.permission.events.PermissionGatherEvent;
import net.minecraftforge.server.permission.nodes.PermissionNode;
import net.minecraftforge.server.permission.nodes.PermissionTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * Who belongs to which village. Permission nodes (shinobiarts.village.&lt;id&gt;, .kage and .advisor) are registered
 * for every configured village, so a permissions mod like LuckPerms decides membership. Players without a village
 * permission use their admin assignment (/shinobi village, /shinobi kage). Advisors come from the .advisor node or
 * from being appointed (Kage menu, /shinobi advisor). Checked on login and every 10 seconds, so permission changes
 * apply right away. Kages and Advisors get a [Kage] / [Advisor] tag in chat (and in the player list if the config says so).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class VillageManager {
    private static final Map<String, PermissionNode<Boolean>> MEMBER = new HashMap<>();
    private static final Map<String, PermissionNode<Boolean>> KAGE = new HashMap<>();
    private static final Map<String, PermissionNode<Boolean>> ADVISOR = new HashMap<>();

    private VillageManager() {}

    @SubscribeEvent
    public static void registerPermissions(PermissionGatherEvent.Nodes event) {
        MEMBER.clear();
        KAGE.clear();
        ADVISOR.clear();
        for (Villages.Village v : Villages.all()) {
            PermissionNode<Boolean> member = new PermissionNode<>(ShinobiArts.MODID, "village." + v.id(), PermissionTypes.BOOLEAN,
                    (player, uuid, context) -> false);
            PermissionNode<Boolean> kage = new PermissionNode<>(ShinobiArts.MODID, "village." + v.id() + ".kage", PermissionTypes.BOOLEAN,
                    (player, uuid, context) -> false);
            PermissionNode<Boolean> advisor = new PermissionNode<>(ShinobiArts.MODID, "village." + v.id() + ".advisor", PermissionTypes.BOOLEAN,
                    (player, uuid, context) -> false);
            MEMBER.put(v.id(), member);
            KAGE.put(v.id(), kage);
            ADVISOR.put(v.id(), advisor);
            event.addNodes(member, kage, advisor);
        }
    }

    private static boolean has(ServerPlayer player, Map<String, PermissionNode<Boolean>> nodes, String village) {
        PermissionNode<Boolean> node = nodes.get(village);
        if (node == null) return false;
        try {
            return Boolean.TRUE.equals(PermissionAPI.getPermission(player, node));
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Recomputes the player's village and Kage status; syncs if it changed. */
    public static void refresh(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        String village = "";
        boolean kage = false;
        for (Villages.Village v : Villages.all()) {
            if (has(player, KAGE, v.id())) {
                village = v.id();
                kage = true;
                break;
            }
            if (village.isEmpty() && has(player, MEMBER, v.id())) village = v.id();
        }
        if (village.isEmpty() && Villages.byId(d.getAssignedVillage()) != null) {
            village = d.getAssignedVillage();
            kage = d.isAssignedKage();
        } else if (!kage && village.equals(d.getAssignedVillage())) {
            kage = d.isAssignedKage();
        }
        // an appointment only counts in the village it was made in; moving to another village ends it
        if (!village.isEmpty() && !d.getAdvisorOf().isEmpty() && !village.equals(d.getAdvisorOf())) d.setAdvisorOf("");
        boolean advisor = !village.isEmpty() && (has(player, ADVISOR, village) || village.equals(d.getAdvisorOf()));
        if (!village.equals(d.getVillage()) || kage != d.isKage() || advisor != d.isAdvisor()) {
            d.setVillage(village, kage);
            d.setAdvisor(advisor);
            ModNetwork.sync(player);
            refreshTitles(player);
        }
        VillageData.get(player.server).updateAdvisor(player.getUUID(), player.getGameProfile().getName(), advisor ? village : "");
    }

    /** Re-applies the [Kage] / [Advisor] name tag in chat and the player list. */
    public static void refreshTitles(ServerPlayer player) {
        player.refreshDisplayName();
        player.refreshTabListName();
    }

    /** "[Kage] " or "[Advisor] ", or null. */
    @javax.annotation.Nullable
    private static net.minecraft.network.chat.MutableComponent title(net.minecraft.world.entity.player.Player player) {
        if (!(player instanceof ServerPlayer) || !com.shinobiarts.Config.b(com.shinobiarts.Config.SHOW_TITLES)) return null;
        NinjaData d = NinjaData.get(player);
        if (d == null || (!d.isKage() && !d.isAdvisor())) return null;
        boolean kage = d.isKage();
        return net.minecraft.network.chat.Component.literal("[")
                .append(net.minecraft.network.chat.Component.translatable(kage ? "title.shinobiarts.kage" : "title.shinobiarts.advisor"))
                .append("] ")
                .withStyle(kage ? net.minecraft.ChatFormatting.GOLD : net.minecraft.ChatFormatting.AQUA);
    }

    @SubscribeEvent
    public static void onNameFormat(net.minecraftforge.event.entity.player.PlayerEvent.NameFormat event) {
        net.minecraft.network.chat.MutableComponent title = title(event.getEntity());
        if (title != null) event.setDisplayname(title.append(event.getDisplayname()));
    }

    @SubscribeEvent
    public static void onTabListName(net.minecraftforge.event.entity.player.PlayerEvent.TabListNameFormat event) {
        if (!com.shinobiarts.Config.b(com.shinobiarts.Config.SHOW_TITLES_TAB)) return;
        net.minecraft.network.chat.MutableComponent title = title(event.getEntity());
        if (title == null) return;
        net.minecraft.network.chat.Component name = event.getDisplayName() != null ? event.getDisplayName() : event.getEntity().getName();
        event.setDisplayName(title.append(name));
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.side == LogicalSide.SERVER && event.player instanceof ServerPlayer player
                && player.tickCount % 200 == 37) {
            refresh(player);
        }
    }
}
