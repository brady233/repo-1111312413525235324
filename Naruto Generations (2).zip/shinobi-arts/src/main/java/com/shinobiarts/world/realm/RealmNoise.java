package com.shinobiarts.world.realm;

/** Deterministic noise for the Sage realms (no Minecraft classes, so the preview tool can use it too). */
public final class RealmNoise {
    private RealmNoise() {}

    /** A hash of (x, z, salt) in [0, 1). */
    public static double hash(int x, int z, int salt) {
        long h = x * 0x9E3779B97F4A7C15L ^ z * 0xC2B2AE3D27D4EB4FL ^ salt * 0x165667B19E3779F9L;
        h ^= h >>> 31;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 29;
        h *= 0x94D049BB133111EBL;
        h ^= h >>> 32;
        return (h >>> 11) * 0x1.0p-53;
    }

    /** Smooth value noise in [-1, 1] at a scale of one cell per unit. */
    public static double value(double x, double z, int salt) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        double fx = x - ix, fz = z - iz;
        double u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
        double a = hash(ix, iz, salt), b = hash(ix + 1, iz, salt), c = hash(ix, iz + 1, salt), d = hash(ix + 1, iz + 1, salt);
        double top = a + (b - a) * u, bot = c + (d - c) * u;
        return (top + (bot - top) * v) * 2 - 1;
    }

    /** Four octaves of value noise in about [-1, 1]; {@code scale} is the size of the biggest features in blocks. */
    public static double fbm(double x, double z, double scale, int salt) {
        double sum = 0, amp = 1, norm = 0, f = 1 / scale;
        for (int o = 0; o < 4; o++) {
            sum += value(x * f, z * f, salt + o * 101) * amp;
            norm += amp;
            amp *= 0.5;
            f *= 2.03;
        }
        return sum / norm;
    }
}
