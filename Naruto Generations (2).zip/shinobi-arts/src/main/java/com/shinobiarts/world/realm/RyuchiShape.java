package com.shinobiarts.world.realm;

import static com.shinobiarts.world.realm.RealmNoise.fbm;
import static com.shinobiarts.world.realm.RealmNoise.hash;

/**
 * Ryuchi Cave: an endless dark cavern of deepslate and tuff — huge halls joined by narrower passages, a black lake on
 * the floor, stalactites hanging from the roof, waterfalls pouring out of cracks in the ceiling, and dim glowing
 * fungus. At the arrival point a temple stands on a stone platform over the lake, with shrines, a torii and long
 * bridges, and behind it a giant white serpent (the mod's own design) carved coiling up a rock column, its open-jawed
 * head looming over the temple.
 */
public final class RyuchiShape extends RealmShape {
    public RyuchiShape() {
        super(128);
    }

    static final int LAKE = 21;
    /** The temple platform's top surface (players walk at PLATFORM + 1). */
    static final int PLATFORM = 26;
    /** The great hall around the temple is always open out to here. */
    static final int HALL = 96;
    /** The serpent's rock column. */
    static final int COL_X = 0, COL_Z = 50, COL_R = 7;

    @Override
    public int[] arrival() {
        return new int[]{0, PLATFORM + 1, -14};
    }

    /** {floor, ceiling} of the open space in this column, or null if it's solid rock. */
    static int[] space(int x, int z) {
        double d = Math.hypot(x, z);
        double floor = 20 + 5 * fbm(x, z, 60, 51) + 3 * fbm(x, z, 17, 52);
        double ceil = 96 + 10 * fbm(x, z, 80, 53) + 5 * fbm(x, z, 21, 54);
        double open = fbm(x, z, 110, 55) + 0.22;
        double hall = 1 - smooth((d - HALL) / 40.0);
        open += hall * 1.6;
        if (d < HALL) {
            ceil = Math.max(ceil, 108 + 6 * fbm(x, z, 30, 56) - d * 0.05);
            floor = Math.min(floor, 14 + d * 0.08 + 3 * fbm(x, z, 22, 57));
        }
        if (open < 0) return null;
        if (open < 0.18) {                                        // the walls slope in at the edges of each hall
            double k = 1 - open / 0.18;
            double mid = (floor + ceil) / 2;
            floor += (mid - floor) * k * k;
            ceil -= (ceil - mid) * k * k;
            if (ceil - floor < 3) return null;
        }
        return new int[]{(int) Math.round(floor), (int) Math.round(ceil)};
    }

    @Override
    protected void column(int x, int z, Chunk c) {
        c.set(x, 0, z, BARRIER);
        int[] s = space(x, z);
        if (s == null) {
            for (int y = 1; y < height; y++) c.set(x, y, z, rock(x, y, z));
            return;
        }
        for (int y = 1; y < s[0]; y++) c.set(x, y, z, rock(x, y, z));
        int top = s[0] - 1;
        if (top >= 1) c.set(x, top, z, top <= LAKE ? (hash(x, z, 60) < 0.5 ? GRAVEL : COBBLED_DEEPSLATE) : (hash(x, z, 61) < 0.25 ? MOSS : COBBLED_DEEPSLATE));
        for (int y = s[0]; y <= LAKE && y < s[1]; y++) c.set(x, y, z, WATER);
        for (int y = s[1]; y < height; y++) c.set(x, y, z, rock(x, y, z));
        // dim glowing fungus on the roof and the odd glowing stone on the shore
        if (hash(x, z, 62) < 0.012) c.set(x, s[1], z, SHROOMLIGHT);
        if (top > LAKE && hash(x, z, 63) < 0.004) c.set(x, top, z, SEA_LANTERN);
    }

    static int rock(int x, int y, int z) {
        double band = Math.sin(y * 0.35 + fbm(x, z, 40, 64) * 4);
        return band > 0.6 ? TUFF : band < -0.7 ? COBBLED_DEEPSLATE : DEEPSLATE;
    }

    @Override
    protected void structures(Chunk c) {
        // stalactites and stalagmites
        int g = 8;
        for (int i = Math.floorDiv(c.x0, g) - 1; i <= Math.floorDiv(c.x0 + 15, g) + 1; i++) {
            for (int j = Math.floorDiv(c.z0, g) - 1; j <= Math.floorDiv(c.z0 + 15, g) + 1; j++) {
                int x = i * g + (int) (hash(i, j, 70) * g), z = j * g + (int) (hash(i, j, 71) * g);
                if (!c.touches(x - 3, z - 3, x + 3, z + 3)) continue;
                int[] s = space(x, z);
                if (s == null || s[1] - s[0] < 14) continue;
                if (Math.abs(x - COL_X) < COL_R + 18 && Math.abs(z - COL_Z) < COL_R + 18) continue;
                if (Math.abs(x) < 26 && Math.abs(z) < 26) continue;
                if (hash(i, j, 72) < 0.65) {
                    int len = 4 + (int) (hash(i, j, 73) * Math.min(18, (s[1] - s[0]) / 3));
                    c.stalactite(x + 0.5, s[1] - 1, z + 0.5, len, 1.2 + hash(i, j, 74) * 1.6, hash(i, j, 75) < 0.5 ? DRIPSTONE : TUFF);
                }
                if (s[0] > LAKE && hash(i, j, 76) < 0.3) c.spire(x + 0.5, s[0], z + 0.5, 3 + (int) (hash(i, j, 77) * 7), 1.0 + hash(i, j, 78), DRIPSTONE);
            }
        }
        // waterfalls out of the roof
        int wf = 56;
        for (int i = Math.floorDiv(c.x0, wf) - 1; i <= Math.floorDiv(c.x0 + 15, wf) + 1; i++) {
            for (int j = Math.floorDiv(c.z0, wf) - 1; j <= Math.floorDiv(c.z0 + 15, wf) + 1; j++) {
                if (hash(i, j, 80) > 0.55) continue;
                int x = i * wf + (int) (hash(i, j, 81) * wf), z = j * wf + (int) (hash(i, j, 82) * wf);
                if (Math.abs(x) < 30 && Math.abs(z) < 30) continue;
                if (Math.abs(x - COL_X) < 22 && Math.abs(z - COL_Z) < 22) continue;
                if (!c.touches(x - 2, z - 2, x + 2, z + 2)) continue;
                int[] s = space(x, z);
                if (s == null) continue;
                c.box(x, Math.max(s[0], 1), z, x + 1, s[1] + 2, z + 1, WATER);
                c.box(x - 1, s[1] + 3, z - 1, x + 2, s[1] + 3, z + 2, WATER);
            }
        }
        // hidden lights, so it's dark but never pitch black
        int lg = 13;
        for (int i = Math.floorDiv(c.x0, lg); i <= Math.floorDiv(c.x0 + 15, lg); i++) {
            for (int j = Math.floorDiv(c.z0, lg); j <= Math.floorDiv(c.z0 + 15, lg); j++) {
                int x = i * lg + 6, z = j * lg + 6;
                int[] s = space(x, z);
                if (s == null) continue;
                c.setIfAir(x, Math.min(s[1] - 1, Math.max(s[0], LAKE + 1) + 5), z, LIGHT);
            }
        }
        if (c.touches(-HALL, -HALL, HALL, HALL)) {
            temple(c);
            serpent(c);
        }
    }

    /** The temple on its platform over the lake. */
    private static void temple(Chunk c) {
        int p = PLATFORM;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) c.cylinder(sx * 19 + 0.5, sz * 19 + 0.5, 1, p - 4, 2.6, BRICKS);
        }
        c.box(-24, p - 3, -24, 24, p, 24, BLACKSTONE);
        c.box(-23, p, -23, 23, p, 23, POLISHED);
        c.box(-1, p, -24, 1, p, 14, BRICKS);
        pagoda(c, 0, p + 1, 6, 8, 3, RED_CLAY);
        pagoda(c, -16, p + 1, -10, 3, 2, RED_CLAY);
        pagoda(c, 16, p + 1, -10, 3, 2, RED_CLAY);
        torii(c, 0, p + 1, -20, 4, 9);
        for (int k = -22; k <= 22; k += 11) {
            lanternPost(c, -23, p + 1, k);
            lanternPost(c, 23, p + 1, k);
        }
        lanternPost(c, -4, p + 1, -16);
        lanternPost(c, 4, p + 1, -16);
        // bridges out across the lake, each to a landing on a rock pillar
        int[][] ends = {{0, -80}, {-80, 0}, {80, 0}};
        int[][] starts = {{0, -25}, {-25, 0}, {25, 0}};
        for (int k = 0; k < ends.length; k++) {
            bridge(c, starts[k][0], p, starts[k][1], ends[k][0], p, ends[k][1], 4);
            c.cylinder(ends[k][0] + 0.5, ends[k][1] + 0.5, 1, p, 4.5, BRICKS);
            c.cylinder(ends[k][0] + 0.5, ends[k][1] + 0.5, p, p, 4.5, POLISHED);
            lanternPost(c, ends[k][0], p + 1, ends[k][1]);
        }
    }

    /**
     * The white serpent: a body thick as a house coiling two and a half times up the rock column, the tail trailing into
     * the lake, the neck reaching out over the temple, and a wedge-shaped head with the jaws open, fangs, red eyes and a
     * forked tongue. Calcite with bone-coloured scale bands.
     */
    private static void serpent(Chunk c) {
        if (!c.touches(COL_X - 60, COL_Z - 60, COL_X + 60, COL_Z + 60)) return;
        c.cylinder(COL_X + 0.5, COL_Z + 0.5, 1, 120, COL_R, DEEPSLATE);
        c.cylinder(COL_X + 0.5, COL_Z + 0.5, 1, 30, COL_R + 3, TUFF);
        double R = COL_R + 7;
        int segs = 140;
        double turns = 2.5, y0 = 16, y1 = 84;
        double endAng = -Math.PI / 2;                              // finishes on the temple side of the column
        double startAng = endAng - turns * Math.PI * 2;
        double px = 0, py = 0, pz = 0;
        for (int k = 0; k <= segs; k++) {
            double t = k / (double) segs;
            double a = startAng + (endAng - startAng) * t;
            double x = COL_X + Math.cos(a) * R, z = COL_Z + Math.sin(a) * R, y = y0 + (y1 - y0) * t;
            double r = 1.6 + 3.3 * smooth(t * 3);
            if (k > 0) c.tube(px, py, pz, x, y, z, r, (k / 4) % 3 == 0 ? BONE : CALCITE);
            if (k % 5 == 0) {                                      // hidden lights around it, so it glows pale in the dark
                double ox = Math.cos(a) * (r + 2.5), oz = Math.sin(a) * (r + 2.5);
                c.setIfAir((int) Math.floor(x + ox), (int) y, (int) Math.floor(z + oz), LIGHT);
                c.setIfAir((int) Math.floor(x), (int) (y - r - 2), (int) Math.floor(z), LIGHT);
            }
            px = x;
            py = y;
            pz = z;
        }
        // the tail, trailing off into the lake
        c.tube(COL_X + Math.cos(startAng) * R, y0, COL_Z + Math.sin(startAng) * R, COL_X + 24, 12, COL_Z + 18, 1.2, CALCITE);
        // the neck, arching up and out over the temple
        double nx = COL_X, nz = COL_Z - R, ny = y1;
        double hx = 0, hy = 96, hz = 22;
        int ns = 16;
        double lx = nx, ly = ny, lz = nz;
        for (int k = 1; k <= ns; k++) {
            double t = k / (double) ns;
            double x = nx + (hx - nx) * t, z = nz + (hz - nz) * t, y = ny + (hy - ny) * t + 6 * Math.sin(Math.PI * t);
            c.tube(lx, ly, lz, x, y, z, 4.6 - 0.8 * t, k % 3 == 0 ? BONE : CALCITE);
            lx = x;
            ly = y;
            lz = z;
        }
        // the head (pointing -z, at the temple)
        c.ellipsoid(hx + 0.5, hy, hz, 5.5, 4, 6.5, QUARTZ);              // skull
        c.ellipsoid(hx + 0.5, hy + 1, hz - 6, 4.2, 2.3, 6, QUARTZ);       // upper jaw
        c.ellipsoid(hx + 0.5, hy - 4.5, hz - 5, 3.6, 1.6, 6.2, CALCITE);  // lower jaw, dropped open
        c.ellipsoid(hx + 0.5, hy - 2, hz - 7, 3.2, 1.8, 6.5, AIR);        // the open mouth
        c.ellipsoid(hx + 0.5, hy - 2.6, hz - 4, 2.8, 0.6, 5, RED);       // the inside of the mouth
        for (int side = -1; side <= 1; side += 2) {
            c.spire(hx + 0.5 + side * 2.6, (int) (hy - 3), hz - 9.5, 1, 0.6, BONE);
            c.stalactite(hx + 0.5 + side * 2.6, (int) (hy - 0.5), hz - 9.5, 3, 0.9, BONE);   // fangs
            c.ellipsoid(hx + 0.5 + side * 4.6, hy + 2, hz - 2, 1.1, 1.1, 1.6, RED);          // eyes
            c.ellipsoid(hx + 0.5 + side * 4.3, hy + 3.6, hz - 1.5, 1.6, 0.8, 2.6, CALCITE);  // brows
        }
        for (int k = 0; k < 6; k++) c.setIfAir((int) (hx - 6 + k * 2.4), (int) hy - 8, (int) hz - 6 + (k % 2) * 6, LIGHT);
        // the forked tongue
        c.tube(hx + 0.5, hy - 2.4, hz - 6, hx + 0.5, hy - 3.2, hz - 14, 0.6, RED);
        c.tube(hx + 0.5, hy - 3.2, hz - 14, hx - 1, hy - 3.6, hz - 17, 0.5, RED);
        c.tube(hx + 0.5, hy - 3.2, hz - 14, hx + 2, hy - 3.6, hz - 17, 0.5, RED);
    }
}
