package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.shinobiarts.Config;
import com.shinobiarts.shop.AuctionHouse;
import com.shinobiarts.shop.Shop;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * /shop: opens the ninja shop (see shop/Shop).
 * /shop auction [page] | sell &lt;start&gt; &lt;hours&gt; [buyout] | bid &lt;id&gt; &lt;amount&gt; | buyout &lt;id&gt; | cancel &lt;id&gt; | claim
 * (see shop/AuctionHouse); operators also have /shop auction remove &lt;id&gt;.
 */
public final class ShopCommand {
    private ShopCommand() {}

    private static final int PAGE = 8;

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shop").executes(ctx -> {
                    if (!Config.b(Config.SHOP_ENABLED)) {
                        ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.shop_closed"));
                        return 0;
                    }
                    Shop.open(ctx.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.literal("auction")
                        .executes(ctx -> list(ctx.getSource().getPlayerOrException(), 1))
                        .then(Commands.argument("page", IntegerArgumentType.integer(1))
                                .executes(ctx -> list(ctx.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(ctx, "page"))))
                        .then(Commands.literal("sell")
                                .then(Commands.argument("start", LongArgumentType.longArg(1))
                                        .then(Commands.argument("hours", IntegerArgumentType.integer(1))
                                                .executes(ctx -> sell(ctx.getSource().getPlayerOrException(), LongArgumentType.getLong(ctx, "start"),
                                                        IntegerArgumentType.getInteger(ctx, "hours"), 0))
                                                .then(Commands.argument("buyout", LongArgumentType.longArg(1))
                                                        .executes(ctx -> sell(ctx.getSource().getPlayerOrException(), LongArgumentType.getLong(ctx, "start"),
                                                                IntegerArgumentType.getInteger(ctx, "hours"), LongArgumentType.getLong(ctx, "buyout")))))))
                        .then(Commands.literal("bid")
                                .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                        .then(Commands.argument("amount", LongArgumentType.longArg(1))
                                                .executes(ctx -> {
                                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                                    return AuctionHouse.get(p.server).bid(p, IntegerArgumentType.getInteger(ctx, "id"), LongArgumentType.getLong(ctx, "amount")) ? 1 : 0;
                                                }))))
                        .then(Commands.literal("buyout")
                                .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            return AuctionHouse.get(p.server).buyout(p, IntegerArgumentType.getInteger(ctx, "id")) ? 1 : 0;
                                        })))
                        .then(Commands.literal("cancel")
                                .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            return AuctionHouse.get(p.server).cancel(p, IntegerArgumentType.getInteger(ctx, "id"), false) ? 1 : 0;
                                        })))
                        .then(Commands.literal("remove").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            return AuctionHouse.get(p.server).cancel(p, IntegerArgumentType.getInteger(ctx, "id"), true) ? 1 : 0;
                                        })))
                        .then(Commands.literal("claim")
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    return AuctionHouse.get(p.server).claim(p);
                                }))));
    }

    private static int sell(ServerPlayer p, long start, int hours, long buyout) {
        if (!Config.b(Config.SHOP_ENABLED)) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.shop_closed").withStyle(ChatFormatting.RED));
            return 0;
        }
        return AuctionHouse.get(p.server).sell(p, start, hours, buyout) ? 1 : 0;
    }

    private static int list(ServerPlayer p, int page) {
        AuctionHouse ah = AuctionHouse.get(p.server);
        List<AuctionHouse.Listing> all = ah.listings();
        int pages = Math.max(1, (all.size() + PAGE - 1) / PAGE);
        page = Math.min(page, pages);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_title", page, pages).withStyle(ChatFormatting.GOLD));
        if (all.isEmpty()) p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_none").withStyle(ChatFormatting.GRAY));
        for (int i = (page - 1) * PAGE; i < Math.min(all.size(), page * PAGE); i++) p.sendSystemMessage(ah.line(all.get(i)));
        int waiting = ah.waiting(p.getUUID());
        if (waiting > 0) p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_waiting", waiting).withStyle(ChatFormatting.AQUA));
        p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_help").withStyle(ChatFormatting.DARK_GRAY));
        return all.size();
    }
}
