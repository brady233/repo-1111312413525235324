package com.shinobiarts.shop;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ActiveEyeItem;
import com.shinobiarts.item.EightGatesItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.ninja.PlayerDataManager;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The auction house (/shop auction): players list an item for Ryo, others bid, the highest bid when the timer runs out
 * wins (or anyone can pay the buyout price at once).
 * <p>
 * Safe by construction, all on the server: the moment an item is listed it leaves the seller's inventory and lives only
 * in the auction data (saved with the world); a bid's Ryo leaves the bidder at once and is held until they're outbid
 * (then refunded) or win. Everything owed — items won, unsold items, Ryo from sales and refunds — goes into the
 * player's auction mailbox, so nothing is lost if they're offline: Ryo is paid in as soon as they're online, items are
 * collected with /shop auction claim (only as many as fit; the rest stays). An item is always removed from the data
 * before it is handed over, so it can't be handed over twice. Owner-bound items (releases, eyes, the Eight Gates)
 * can't be listed.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AuctionHouse extends SavedData {
    public static final class Listing {
        public final int id;
        public final UUID seller;
        public final String sellerName;
        public final ItemStack item;
        public final long start, buyout;
        public long bid;
        @Nullable
        public UUID bidder;
        public String bidderName = "";
        public long endsAt;

        Listing(int id, UUID seller, String sellerName, ItemStack item, long start, long buyout, long endsAt) {
            this.id = id;
            this.seller = seller;
            this.sellerName = sellerName;
            this.item = item;
            this.start = start;
            this.buyout = buyout;
            this.endsAt = endsAt;
        }

        /** The lowest bid that's accepted now. */
        public long minimumBid() {
            if (bidder == null) return start;
            return bid + Math.max(1, Math.round(bid * 0.05));
        }

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("Id", id);
            t.putUUID("Seller", seller);
            t.putString("SellerName", sellerName);
            t.put("Item", item.save(new CompoundTag()));
            t.putLong("Start", start);
            t.putLong("Buyout", buyout);
            t.putLong("Bid", bid);
            if (bidder != null) {
                t.putUUID("Bidder", bidder);
                t.putString("BidderName", bidderName);
            }
            t.putLong("Ends", endsAt);
            return t;
        }

        static Listing load(CompoundTag t) {
            Listing l = new Listing(t.getInt("Id"), t.getUUID("Seller"), t.getString("SellerName"), ItemStack.of(t.getCompound("Item")),
                    t.getLong("Start"), t.getLong("Buyout"), t.getLong("Ends"));
            l.bid = t.getLong("Bid");
            if (t.hasUUID("Bidder")) {
                l.bidder = t.getUUID("Bidder");
                l.bidderName = t.getString("BidderName");
            }
            return l;
        }
    }

    /** What a player is owed. */
    static final class Mail {
        long ryo;
        final List<ItemStack> items = new ArrayList<>();
    }

    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Mail> mail = new HashMap<>();
    private int nextId = 1;

    public static AuctionHouse get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(AuctionHouse::load, AuctionHouse::new, "shinobiarts_auctions");
    }

    public List<Listing> listings() {
        return listings;
    }

    @Nullable
    public Listing byId(int id) {
        for (Listing l : listings) if (l.id == id) return l;
        return null;
    }

    // ---------------------------------------------------------------- actions (all on the server thread)

    /** Lists the item in the player's main hand. */
    public boolean sell(ServerPlayer p, long start, int hours, long buyout) {
        ItemStack held = p.getMainHandItem();
        if (held.isEmpty()) return fail(p, "auction_empty_hand");
        if (!sellable(held)) return fail(p, "auction_bound");
        if (start < 1 || (buyout > 0 && buyout < start)) return fail(p, "auction_bad_price");
        int maxHours = Config.i(Config.AUCTION_MAX_HOURS);
        if (hours < 1 || hours > maxHours) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_bad_time", maxHours).withStyle(ChatFormatting.RED));
            return false;
        }
        long mine = listings.stream().filter(l -> l.seller.equals(p.getUUID())).count();
        if (mine >= Config.i(Config.AUCTION_MAX_LISTINGS)) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_too_many", Config.i(Config.AUCTION_MAX_LISTINGS)).withStyle(ChatFormatting.RED));
            return false;
        }
        ItemStack item = held.copy();
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);   // out of the inventory first, then into the auction
        Listing l = new Listing(nextId++, p.getUUID(), p.getGameProfile().getName(), item, start, Math.max(0, buyout),
                System.currentTimeMillis() + hours * 3_600_000L);
        listings.add(l);
        setDirty();
        p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_listed", l.id, item.getDisplayName(),
                PlayerDataManager.formatRyo(start), hours).withStyle(ChatFormatting.GREEN));
        return true;
    }

    /** Bids {@code amount} (a bid at or over the buyout price buys it outright). */
    public boolean bid(ServerPlayer p, int id, long amount) {
        Listing l = byId(id);
        if (l == null) return fail(p, "auction_gone");
        if (l.seller.equals(p.getUUID())) return fail(p, "auction_own");
        if (p.getUUID().equals(l.bidder)) return fail(p, "auction_already_top");
        if (l.buyout > 0 && amount >= l.buyout) return buyout(p, id);
        if (amount < l.minimumBid()) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_too_low", PlayerDataManager.formatRyo(l.minimumBid())).withStyle(ChatFormatting.RED));
            return false;
        }
        if (!PlayerDataManager.trySpendRyo(p, amount)) return fail(p, "auction_no_ryo");
        UUID outbid = l.bidder;
        long refund = l.bid;
        l.bid = amount;
        l.bidder = p.getUUID();
        l.bidderName = p.getGameProfile().getName();
        long now = System.currentTimeMillis();
        if (l.endsAt - now < 60_000L) l.endsAt = now + 60_000L;   // no last-second sniping: a late bid gives a minute more
        if (outbid != null) {
            payRyo(p.server, outbid, refund);
            tell(p.server, outbid, Component.translatable("message.shinobiarts.auction_outbid", l.item.getDisplayName(),
                    PlayerDataManager.formatRyo(amount), l.id).withStyle(ChatFormatting.YELLOW));
        }
        setDirty();
        p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_bid_ok", PlayerDataManager.formatRyo(amount), l.item.getDisplayName()).withStyle(ChatFormatting.GREEN));
        tell(p.server, l.seller, Component.translatable("message.shinobiarts.auction_new_bid", l.item.getDisplayName(), PlayerDataManager.formatRyo(amount)).withStyle(ChatFormatting.GOLD));
        return true;
    }

    public boolean buyout(ServerPlayer p, int id) {
        Listing l = byId(id);
        if (l == null) return fail(p, "auction_gone");
        if (l.buyout <= 0) return fail(p, "auction_no_buyout");
        if (l.seller.equals(p.getUUID())) return fail(p, "auction_own");
        if (!PlayerDataManager.trySpendRyo(p, l.buyout)) return fail(p, "auction_no_ryo");
        if (l.bidder != null) {
            payRyo(p.server, l.bidder, l.bid);
            tell(p.server, l.bidder, Component.translatable("message.shinobiarts.auction_bought_out", l.item.getDisplayName()).withStyle(ChatFormatting.YELLOW));
        }
        l.bid = l.buyout;
        l.bidder = p.getUUID();
        l.bidderName = p.getGameProfile().getName();
        finish(p.server, l);
        return true;
    }

    /** The seller takes an item back (only while nobody has bid). Operators ({@code force}) can remove any listing. */
    public boolean cancel(ServerPlayer p, int id, boolean force) {
        Listing l = byId(id);
        if (l == null) return fail(p, "auction_gone");
        if (!force && !l.seller.equals(p.getUUID())) return fail(p, "auction_not_yours");
        if (!force && l.bidder != null) return fail(p, "auction_has_bids");
        listings.remove(l);
        if (l.bidder != null) payRyo(p.server, l.bidder, l.bid);
        mailItem(p.server, l.seller, l.item);
        setDirty();
        p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_cancelled", l.id).withStyle(ChatFormatting.GRAY));
        return true;
    }

    /** Hands over items in the player's mailbox (as many as fit). */
    public int claim(ServerPlayer p) {
        Mail m = mail.get(p.getUUID());
        if (m == null || m.items.isEmpty()) {
            fail(p, "auction_nothing");
            return 0;
        }
        int given = 0;
        List<ItemStack> pending = new ArrayList<>(m.items);
        m.items.clear();                                          // out of the mailbox first...
        setDirty();
        for (ItemStack s : pending) {
            ItemStack give = s.copy();
            p.getInventory().add(give);                           // ...then into the inventory; whatever didn't fit goes back
            if (!give.isEmpty()) m.items.add(give);
            if (give.getCount() < s.getCount()) given++;
        }
        if (m.items.isEmpty() && m.ryo == 0) mail.remove(p.getUUID());
        setDirty();
        p.sendSystemMessage(Component.translatable(m.items.isEmpty() ? "message.shinobiarts.auction_claimed" : "message.shinobiarts.auction_claimed_some",
                given, m.items.size()).withStyle(ChatFormatting.GREEN));
        return given;
    }

    /** How many items are waiting for the player. */
    public int waiting(UUID player) {
        Mail m = mail.get(player);
        return m == null ? 0 : m.items.size();
    }

    // ---------------------------------------------------------------- ending

    private void tick(MinecraftServer server) {
        long now = System.currentTimeMillis();
        List<Listing> ended = new ArrayList<>();
        for (Listing l : listings) if (l.endsAt <= now) ended.add(l);
        for (Listing l : ended) finish(server, l);
    }

    private void finish(MinecraftServer server, Listing l) {
        if (!listings.remove(l)) return;
        if (l.bidder != null) {
            long fee = Math.round(l.bid * Config.d(Config.AUCTION_FEE));
            mailItem(server, l.bidder, l.item);
            payRyo(server, l.seller, l.bid - fee);
            tell(server, l.bidder, Component.translatable("message.shinobiarts.auction_won", l.item.getDisplayName(),
                    PlayerDataManager.formatRyo(l.bid)).withStyle(ChatFormatting.GOLD));
            tell(server, l.seller, Component.translatable("message.shinobiarts.auction_sold", l.item.getDisplayName(), l.bidderName,
                    PlayerDataManager.formatRyo(l.bid - fee)).withStyle(ChatFormatting.GOLD));
            ServerPlayer w = server.getPlayerList().getPlayer(l.bidder);
            if (w != null) w.level().playSound(null, w.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.4f);
        } else {
            mailItem(server, l.seller, l.item);
            tell(server, l.seller, Component.translatable("message.shinobiarts.auction_unsold", l.item.getDisplayName()).withStyle(ChatFormatting.GRAY));
        }
        setDirty();
    }

    // ---------------------------------------------------------------- the mailbox

    private void mailItem(MinecraftServer server, UUID to, ItemStack item) {
        mail.computeIfAbsent(to, k -> new Mail()).items.add(item.copy());
        setDirty();
        tell(server, to, Component.translatable("message.shinobiarts.auction_mail").withStyle(Style.EMPTY.withColor(ChatFormatting.AQUA)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/shop auction claim"))));
    }

    /** Pays Ryo straight in if they're online, otherwise keeps it for when they are. */
    private void payRyo(MinecraftServer server, UUID to, long amount) {
        if (amount <= 0) return;
        ServerPlayer p = server.getPlayerList().getPlayer(to);
        if (p != null) PlayerDataManager.addRyo(p, amount);
        else mail.computeIfAbsent(to, k -> new Mail()).ryo += amount;
        setDirty();
    }

    /** When someone logs in: Ryo they're owed is paid in, and they're told about waiting items. */
    private void login(ServerPlayer p) {
        Mail m = mail.get(p.getUUID());
        if (m == null) return;
        if (m.ryo > 0) {
            long r = m.ryo;
            m.ryo = 0;
            PlayerDataManager.addRyo(p, r);
            p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_ryo_paid", PlayerDataManager.formatRyo(r)).withStyle(ChatFormatting.GOLD));
        }
        if (!m.items.isEmpty()) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.auction_waiting", m.items.size()).withStyle(Style.EMPTY.withColor(ChatFormatting.AQUA)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/shop auction claim"))));
        } else {
            mail.remove(p.getUUID());
        }
        setDirty();
    }

    private static void tell(MinecraftServer server, @Nullable UUID to, Component msg) {
        if (to == null) return;
        ServerPlayer p = server.getPlayerList().getPlayer(to);
        if (p != null) p.sendSystemMessage(msg);
    }

    private static boolean fail(ServerPlayer p, String key) {
        p.sendSystemMessage(Component.translatable("message.shinobiarts." + key).withStyle(ChatFormatting.RED));
        return false;
    }

    /** Owner-bound and anti-dupe-tracked items can't be sold. */
    public static boolean sellable(ItemStack s) {
        if (s.getItem() instanceof ReleaseItem || s.getItem() instanceof EightGatesItem || s.getItem() instanceof SharinganEyeItem
                || s.getItem() instanceof ActiveEyeItem) return false;
        CompoundTag t = s.getTag();
        return t == null || !(t.contains("ShinobiSerial") || t.contains("Owner"));
    }

    // ---------------------------------------------------------------- the listing in chat

    public MutableComponent line(Listing l) {
        long left = Math.max(0, l.endsAt - System.currentTimeMillis()) / 60_000L;
        String time = left >= 60 ? (left / 60) + "h " + (left % 60) + "m" : left + "m";
        MutableComponent c = Component.literal("#" + l.id + " ").withStyle(ChatFormatting.DARK_GRAY)
                .append(l.item.getDisplayName().copy().withStyle(s -> s.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_ITEM, new HoverEvent.ItemStackInfo(l.item)))))
                .append(Component.literal(" x" + l.item.getCount()).withStyle(ChatFormatting.GRAY))
                .append(Component.translatable("message.shinobiarts.auction_line", l.sellerName,
                        PlayerDataManager.formatRyo(l.bidder == null ? l.start : l.bid), time).withStyle(ChatFormatting.GRAY));
        c.append(Component.literal(" [" + Component.translatable("message.shinobiarts.auction_bid_button").getString() + "]")
                .withStyle(Style.EMPTY.withColor(ChatFormatting.GREEN)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/shop auction bid " + l.id + " " + l.minimumBid()))));
        if (l.buyout > 0) {
            c.append(Component.literal(" [" + Component.translatable("message.shinobiarts.auction_buyout_button", PlayerDataManager.formatRyo(l.buyout)).getString() + "]")
                    .withStyle(Style.EMPTY.withColor(ChatFormatting.GOLD)
                            .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/shop auction buyout " + l.id))));
        }
        return c;
    }

    // ---------------------------------------------------------------- saving

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("Next", nextId);
        ListTag ls = new ListTag();
        for (Listing l : listings) ls.add(l.save());
        tag.put("Listings", ls);
        ListTag ms = new ListTag();
        for (Map.Entry<UUID, Mail> e : mail.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Player", e.getKey());
            t.putLong("Ryo", e.getValue().ryo);
            ListTag items = new ListTag();
            for (ItemStack s : e.getValue().items) items.add(s.save(new CompoundTag()));
            t.put("Items", items);
            ms.add(t);
        }
        tag.put("Mail", ms);
        return tag;
    }

    static AuctionHouse load(CompoundTag tag) {
        AuctionHouse a = new AuctionHouse();
        a.nextId = Math.max(1, tag.getInt("Next"));
        for (Tag t : tag.getList("Listings", Tag.TAG_COMPOUND)) {
            Listing l = Listing.load((CompoundTag) t);
            if (!l.item.isEmpty()) a.listings.add(l);
            a.nextId = Math.max(a.nextId, l.id + 1);
        }
        for (Tag t : tag.getList("Mail", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            Mail m = new Mail();
            m.ryo = Math.max(0, c.getLong("Ryo"));
            for (Tag it : c.getList("Items", Tag.TAG_COMPOUND)) {
                ItemStack s = ItemStack.of((CompoundTag) it);
                if (!s.isEmpty()) m.items.add(s);
            }
            a.mail.put(c.getUUID("Player"), m);
        }
        return a;
    }

    // ---------------------------------------------------------------- events

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) return;
        get(server).tick(server);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) get(p.server).login(p);
    }
}
