package com.shinobiarts.item;

import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.MangekyouDesign;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * The eyes you have switched on (V), shown in the dojutsu slot: your Sharingan at its stage and pattern, or the
 * Byakugan. It appears when you switch your eyes on and disappears when you switch them off. It can't be taken
 * out, dropped or moved; it isn't a real item and never shows up anywhere else.
 */
public class ActiveEyeItem extends Item {
    /** Variants (the item model picks its picture from these): 0-2 = 1-3 tomoe, 3-6 = Mangekyou patterns, 7 = Byakugan. */
    public static final int BYAKUGAN = 7;

    public ActiveEyeItem(Properties properties) {
        super(properties);
    }

    /** The variant for a player's switched-on eyes, or -1 if their eyes are off. */
    public static int variantFor(NinjaData d) {
        if (d.getActiveDojutsu() == Dojutsu.BYAKUGAN) return BYAKUGAN;
        if (!d.isSharinganActive()) return -1;
        int stage = d.activeSharinganStage();
        return stage >= Dojutsu.MANGEKYOU ? 3 + d.getMangekyouDesign().ordinal() : Math.max(1, stage) - 1;
    }

    public static ItemStack create(int variant) {
        ItemStack stack = new ItemStack(ModItems.ACTIVE_EYE.get());
        stack.getOrCreateTag().putInt("Eye", variant);
        return stack;
    }

    public static int variant(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? 2 : Math.max(0, Math.min(BYAKUGAN, tag.getInt("Eye")));
    }

    public static boolean is(ItemStack stack) {
        return stack.getItem() instanceof ActiveEyeItem;
    }

    @Override
    public Component getName(ItemStack stack) {
        int v = variant(stack);
        if (v == BYAKUGAN) return Dojutsu.byakuganName();
        if (v >= 3) return Dojutsu.sharinganName(Dojutsu.MANGEKYOU, MangekyouDesign.byOrdinal(v - 3));
        return Dojutsu.sharinganName(v + 1);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        int v = variant(stack);
        return v >= 3 && v < BYAKUGAN;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.active_eye").withStyle(ChatFormatting.GRAY));
        int v = variant(stack);
        if (v == BYAKUGAN) {
            com.shinobiarts.ninja.EyeTechniques.describe(0, MangekyouDesign.ITACHI, true, tooltip);
        } else if (v >= 3) {
            com.shinobiarts.ninja.EyeTechniques.describe(Dojutsu.MANGEKYOU, MangekyouDesign.byOrdinal(v - 3), false, tooltip);
        } else {
            com.shinobiarts.ninja.EyeTechniques.describe(v + 1, MangekyouDesign.ITACHI, false, tooltip);
        }
    }
}
