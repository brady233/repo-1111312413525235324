package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.network.ShadowLinkPacket;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Shadow Possession (Nara): the caster's shadow races along the ground to the target and holds it. While it holds, the
 * target copies every step, jump and turn the caster makes (and every swing); it can't act on its own. Every client
 * near either of them draws the shadow stretched along the ground between them (client/ShadowLinkRender).
 */
public final class ShadowPossession {
    private static final DustParticleOptions SHADOW = new DustParticleOptions(new Vector3f(0.04f, 0.04f, 0.06f), 1.2f);

    private static final class Link {
        final int targetId;
        final long until;
        Vec3 lastCasterPos;

        Link(int targetId, long until, Vec3 casterPos) {
            this.targetId = targetId;
            this.until = until;
            this.lastCasterPos = casterPos;
        }
    }

    private static final Map<UUID, Link> LINKS = new HashMap<>();

    private ShadowPossession() {}

    /** Catches the target: freezes it in place (it moves only with the caster from now on) and shows the shadow. */
    public static void start(ServerPlayer caster, LivingEntity target, int ticks) {
        end(caster);
        long now = caster.level().getGameTime();
        LINKS.put(caster.getUUID(), new Link(target.getId(), now + ticks, caster.position()));
        Afflictions.stun(target, ticks, Afflictions.STUN_NONE);
        if (target instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
        }
        send(caster, target, ticks);
    }

    /** Lets go (the caster cast again, logged out, or the time ran out). */
    public static void end(ServerPlayer caster) {
        Link l = LINKS.remove(caster.getUUID());
        if (l == null) return;
        Entity t = caster.level().getEntity(l.targetId);
        send(caster, t, 0);
    }

    public static boolean isHolding(ServerPlayer caster) {
        return LINKS.containsKey(caster.getUUID());
    }

    private static void send(ServerPlayer caster, Entity target, int ticks) {
        ShadowLinkPacket packet = new ShadowLinkPacket(caster.getId(), target == null ? -1 : target.getId(), ticks);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> caster), packet);
        if (target instanceof ServerPlayer tp) ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> tp), packet);
    }

    /** Every tick for the caster (from the ninja ticker): the target moves exactly as the caster does. */
    public static void tick(ServerPlayer caster, NinjaData d) {
        Link l = LINKS.get(caster.getUUID());
        if (l == null) return;
        ServerLevel level = caster.serverLevel();
        long now = level.getGameTime();
        Entity e = level.getEntity(l.targetId);
        double range = Config.i(Config.SHADOW_POSSESSION_RANGE) + 6;
        if (!(e instanceof LivingEntity target) || !target.isAlive() || now >= l.until || !caster.isAlive()
                || caster.distanceToSqr(target) > range * range) {
            end(caster);
            return;
        }
        Vec3 pos = caster.position();
        Vec3 delta = pos.subtract(l.lastCasterPos);
        l.lastCasterPos = pos;
        if (delta.lengthSqr() > 16) delta = Vec3.ZERO;          // a teleport, not a step: don't drag the target with it
        float yaw = caster.getYRot(), pitch = caster.getXRot();
        if (target instanceof ServerPlayer tp) {
            if (delta.lengthSqr() > 1e-6) tp.move(MoverType.SELF, delta);
            tp.connection.teleport(tp.getX(), tp.getY(), tp.getZ(), yaw, pitch);
            tp.setYHeadRot(yaw);
        } else {
            if (delta.lengthSqr() > 1e-6) target.move(MoverType.SELF, delta);
            target.setYRot(yaw);
            target.setXRot(pitch);
            target.setYHeadRot(yaw);
            target.yBodyRot = yaw;
            if (target instanceof Mob mob) mob.getNavigation().stop();
        }
        target.resetFallDistance();
        if (caster.swinging && caster.swingTime == 0) target.swing(InteractionHand.MAIN_HAND, true);   // copies the swing too
        if (caster.tickCount % 4 == 0) {
            Vec3 a = caster.position().add(0, 0.05, 0), b = target.position().add(0, 0.05, 0);
            JutsuUtil.line(level, SHADOW, a, b, 0.6, 1, 0.02);
            level.sendParticles(ParticleTypes.SQUID_INK, b.x, b.y + 0.1, b.z, 2, 0.3, 0.02, 0.3, 0.0);
        }
    }

    /** Forgets everything (server stopping). */
    public static void clearAll() {
        LINKS.clear();
    }
}
