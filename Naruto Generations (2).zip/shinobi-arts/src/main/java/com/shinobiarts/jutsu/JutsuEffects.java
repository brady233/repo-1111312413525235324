package com.shinobiarts.jutsu;

import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.registry.ModBlocks;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEffects;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;

import static com.shinobiarts.jutsu.JutsuUtil.dmg;

/** Server-side implementation of every jutsu. Each returns false if it fizzled (nothing is spent). */
public final class JutsuEffects {
    private static final DustParticleOptions WATER_DUST = new DustParticleOptions(new Vector3f(0.25f, 0.55f, 1.0f), 1.6f);
    private static final DustParticleOptions CHAKRA_DUST = new DustParticleOptions(new Vector3f(0.45f, 0.8f, 1.0f), 1.2f);
    private static final DustParticleOptions SHADOW_DUST = new DustParticleOptions(new Vector3f(0.05f, 0.05f, 0.08f), 1.5f);
    private static final DustParticleOptions BLACK_FLAME = new DustParticleOptions(new Vector3f(0.08f, 0.0f, 0.1f), 2.0f);
    private static final DustParticleOptions YIN_DUST = new DustParticleOptions(new Vector3f(0.35f, 0.1f, 0.55f), 1.6f);
    private static final DustParticleOptions YANG_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.92f, 0.6f), 1.2f);

    private JutsuEffects() {}

    private static void noTarget(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    // ================================================================ FIRE

    /** The Great Fireball: a quick tap throws a small one, a full charge a huge one (bigger blast too). */
    public static boolean fireball(ServerPlayer p, NinjaData d) {
        float size = JutsuUtil.chargeSize(0.45f, 2.6f);
        JutsuProjectile ball = JutsuProjectile.shoot(p, JutsuProjectile.Kind.FIRE_BALL, 1.3f - 0.12f * size, 0f, dmg(10f));
        ball.setScale(size);
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.BLAZE_SHOOT, 0.7f + 0.3f * size, 1.1f - 0.2f * size);
        return true;
    }

    public static boolean phoenixFlower(ServerPlayer p, NinjaData d) {
        for (float yaw : new float[]{-16f, -8f, 0f, 8f, 16f}) {
            JutsuProjectile.shoot(p, JutsuProjectile.Kind.FIRE_SMALL, 1.6f, yaw, dmg(6f));
        }
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.FIRECHARGE_USE, 1.0f, 1.2f);
        return true;
    }

    /**
     * Hiding in Ash (Katon: Haijingakure, Asuma): you breathe out a thick cloud of burning ash where you look. Everyone
     * inside is blinded, slowed and choking; after 4 seconds you strike a spark and the whole cloud goes up in flames.
     */
    public static boolean hidingInAsh(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 c = p.getEyePosition().add(look.scale(3)).add(0, -0.8, 0);
        float choke = dmg(1f), blast = dmg(9f);
        int ticks = 300;                                              // the ash hangs (and hides you) for 15 seconds
        final double radius = 13;
        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, ticks, 0, false, false, true));
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.ASH_CLOUD, c, (float) radius, ticks + 10);
        com.shinobiarts.util.Scheduler.repeat(0, 5, ticks / 5, i -> {   // thick, rolling ash everywhere in the cloud
            RandomSource rnd = level.getRandom();
            for (int k = 0; k < 14; k++) {
                double a = rnd.nextDouble() * Math.PI * 2, dist = Math.sqrt(rnd.nextDouble()) * radius;
                double x = c.x + Math.cos(a) * dist, z = c.z + Math.sin(a) * dist, y = c.y - 1 + rnd.nextDouble() * 4;
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, 1, 0.6, 0.4, 0.6, 0.005);
                level.sendParticles(ParticleTypes.ASH, x, y, z, 8, 1.5, 1.0, 1.5, 0.01);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 2, 1.0, 0.6, 1.0, 0.01);
            }
        });
        com.shinobiarts.util.Scheduler.repeat(4, 10, ticks / 10, i -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, radius)) {
                e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
                e.invulnerableTime = 0;
                e.hurt(ModDamage.jutsu(level, p, p), choke);
            }
        });
        com.shinobiarts.util.Scheduler.later(ticks, () -> {       // the spark: the ash goes up in flames
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, radius)) {
                e.invulnerableTime = 0;
                e.hurt(ModDamage.jutsu(level, p, p), blast);
                e.setSecondsOnFire(6);
            }
            level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 30, radius * 0.6, 2.0, radius * 0.6, 0);
            level.sendParticles(ParticleTypes.FLAME, c.x, c.y, c.z, 600, radius * 0.6, 2.0, radius * 0.6, 0.08);
            JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.7f);
            JutsuUtil.sound(level, c, SoundEvents.FIRECHARGE_USE, 2.0f, 0.5f);
        });
        JutsuUtil.sound(level, p.getEyePosition(), SoundEvents.FIRE_EXTINGUISH, 1.0f, 0.5f);
        return true;
    }

    /** Water Clone (Suiton: Mizu Bunshin): two clones made of water step out beside you; they burst into a splash. */
    public static boolean waterClone(ServerPlayer p, NinjaData d) {
        boolean ok = spawnClones(p, d, 2, true);
        if (ok) JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_SPLASH, 1.0f, 0.8f);
        return ok;
    }

    /**
     * Great Fire Annihilation (Madara): a vast sea of fire pours from the mouth and rolls forward, burning everything
     * it covers (the same flames as Majestic Destroyer Flame, on a smaller scale).
     */
    /**
     * Great Fire Annihilation (Madara): a flood of fire poured out over the ground that spreads into a sea of flame, a
     * huge fan (140 degrees, 22 blocks) with a tall crest of fire rolling along its front; everything it reaches burns.
     * The field keeps burning for a few seconds after. (Majestic Destroyer Flame is the towering wall of fire instead.)
     */
    public static boolean fireAnnihilation(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        final float reach = 22f, speed = 1.1f, halfAngle = 70f;
        final int spreadTicks = (int) Math.ceil(reach / speed), burnTicks = 70;
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z);
        dir = dir.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : dir.normalize();
        final Vec3 forward = dir;
        final Vec3 origin = p.position().add(forward.scale(1.0));
        final float damage = dmg(11f);
        final double cosHalf = Math.cos(Math.toRadians(halfAngle));
        final java.util.Set<Integer> burned = new java.util.HashSet<>();
        final boolean grief = JutsuUtil.griefing(level, p);
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.FIRE_SEA, origin, origin.add(forward), reach, spreadTicks + burnTicks);
        com.shinobiarts.util.Scheduler.repeat(0, 1, spreadTicks + burnTicks, t -> {
            float front = Math.min(reach, (t + 1) * speed);
            for (LivingEntity e : JutsuUtil.inRadius(level, p, origin, front + 1)) {
                Vec3 to = e.position().subtract(origin);
                Vec3 flat = new Vec3(to.x, 0, to.z);
                double dist = flat.length();
                if (dist > 0.5 && flat.scale(1 / dist).dot(forward) < cosHalf) continue;
                if (burned.add(e.getId())) {                          // the crest hits once, hard
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, p, p), damage);
                    JutsuUtil.push(e, flat.lengthSqr() < 1e-4 ? forward.scale(0.8) : flat.normalize().scale(0.8).add(0, 0.25, 0));
                }
                e.setSecondsOnFire(8);                                // the field keeps them burning
            }
            if (t < spreadTicks) {
                RandomSource rnd = level.getRandom();
                for (int i = 0; i < 10; i++) {
                    double a = Math.atan2(forward.z, forward.x) + Math.toRadians((rnd.nextDouble() * 2 - 1) * halfAngle);
                    Vec3 at = origin.add(Math.cos(a) * front, 0.4, Math.sin(a) * front);
                    level.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 3, 0.4, 0.6, 0.4, 0.04);
                    level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y + 2.5, at.z, 1, 0.5, 0.5, 0.5, 0.02);
                    if (grief && rnd.nextInt(3) == 0) {
                        BlockPos bp = BlockPos.containing(at);
                        for (int dy = 2; dy >= -3; dy--) {
                            BlockPos q = bp.above(dy);
                            if (level.getBlockState(q).isAir() && level.getBlockState(q.below()).isFaceSturdy(level, q.below(), Direction.UP)) {
                                level.setBlockAndUpdate(q, net.minecraft.world.level.block.BaseFireBlock.getState(level, q));
                                break;
                            }
                        }
                    }
                }
                if (t % 4 == 0) JutsuUtil.sound(level, origin.add(forward.scale(front)), SoundEvents.FIRECHARGE_USE, 2.0f, 0.4f);
            }
        });
        JutsuUtil.sound(level, p.getEyePosition(), SoundEvents.BLAZE_SHOOT, 2.0f, 0.4f);
        JutsuUtil.sound(level, p.getEyePosition(), SoundEvents.FIRE_AMBIENT, 2.0f, 0.5f);
        return true;
    }

    /**
     * Majestic Destroyer Flame (Madara): the hand sign while it charges, then a thin jet of fire from the mouth bursts
     * into a towering wall of flame that rolls 32 blocks forward and spreads 30 wide, burning everything it passes and
     * leaving a sea of fire behind it (see MajesticFlame). A tap makes a smaller wave.
     */
    public static boolean majesticDestroyerFlame(ServerPlayer p, NinjaData d) {
        float scale = JutsuUtil.chargeSize(0.55f, 1.0f);
        com.shinobiarts.entity.MajesticFlame.cast(p, dmg(24f), scale);
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.BLAZE_SHOOT, 1.5f, 0.4f);
        return true;
    }

    // ================================================================ WATER

    public static boolean waterBullet(ServerPlayer p, NinjaData d) {
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.WATER_BULLET, 2.2f, 0f, dmg(7f));
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.PLAYER_SPLASH, 0.8f, 1.6f);
        return true;
    }

    /**
     * Water Prison (Zabuza): a swirling sphere of water closes around the creature you're looking at and drags it to
     * your outstretched hand. It can't move or act inside, runs out of air and takes damage every second. You can
     * turn but not walk away, or it bursts (see WaterPrison).
     */
    public static boolean waterPrison(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int ticks = Math.round((float) (com.shinobiarts.Config.d(com.shinobiarts.Config.WATER_PRISON_SECONDS) * 20));
        WaterPrison.start(p, target, ticks, dmg(1.5f));
        Vec3 c = target.getBoundingBox().getCenter();
        // the water gathers out of the air around it
        JutsuUtil.particles(level, WATER_DUST, c, 70, WaterPrison.radiusFor(target) * 0.7, 0.0);
        JutsuUtil.particles(level, ParticleTypes.SPLASH, c, 50, target.getBbWidth(), 0.1);
        JutsuUtil.line(level, ParticleTypes.SPLASH, p.getEyePosition().add(0, -0.3, 0), c, 0.5, 2, 0.05);
        JutsuUtil.sound(level, c, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.0f, 0.7f);
        JutsuUtil.sound(level, c, SoundEvents.BUBBLE_COLUMN_UPWARDS_INSIDE, 1.2f, 0.8f);
        return true;
    }

    /**
     * Water Shark Bullet (Kisame): a shark of water bursts from your hands and swims at what you look at, biting the
     * first thing it reaches (and eating some of a ninja's chakra, which goes to you).
     */
    public static boolean waterShark(ServerPlayer p, NinjaData d) {
        JutsuProjectile shark = JutsuProjectile.shoot(p, JutsuProjectile.Kind.WATER_SHARK, 1.05f, 0f, dmg(15f));
        shark.setScale(1.5f);
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.SPLASH, p.getEyePosition().add(p.getLookAngle().scale(1.2)), 50, 0.6, 0.2);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.2f, 0.9f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.DOLPHIN_ATTACK, 1.2f, 0.6f);
        return true;
    }

    /**
     * Water Dragon (Tobirama's Water Dragon Missile): water surges up out of the ground in front of you, rises into a
     * dragon, then curves over and charges at what you're looking at, crashing down on everything near where it hits.
     */
    public static boolean waterDragon(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 48);
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(48)) : hit.getLocation();
        LivingEntity target = JutsuUtil.rayTarget(p, 48);
        if (target != null && target.distanceToSqr(p) < aim.distanceToSqr(eye)) aim = target.getBoundingBox().getCenter();
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 from = p.position().add(forward.scale(2.2)).add(0, 0.2, 0);
        for (int i = 0; i < 3 && !level.noCollision(new net.minecraft.world.phys.AABB(from, from).inflate(0.5)); i++) {
            from = from.add(0, 1, 0);                               // a slope or a step in front: rise from on top of it
        }
        JutsuProjectile.waterDragon(p, from, aim, dmg(14f), 1.6f);
        // the water bursts up out of the ground
        JutsuUtil.particles(level, ParticleTypes.SPLASH, from.add(0, 0.3, 0), 90, 1.6, 0.4);
        JutsuUtil.particles(level, WATER_DUST, from.add(0, 1.0, 0), 60, 1.2, 0.05);
        for (int i = 0; i < 16; i++) {
            double a = i / 16.0 * Math.PI * 2;
            level.sendParticles(ParticleTypes.SPLASH, from.x + Math.cos(a) * 2.2, from.y + 0.1, from.z + Math.sin(a) * 2.2, 6, 0.2, 0.1, 0.2, 0.2);
        }
        JutsuUtil.sound(level, from, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.6f, 0.5f);
        JutsuUtil.sound(level, from, SoundEvents.BUBBLE_COLUMN_UPWARDS_INSIDE, 1.5f, 0.6f);
        return true;
    }

    // ================================================================ WIND

    public static boolean galePalm(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : JutsuUtil.inCone(p, 8, 45)) {
            e.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
            JutsuUtil.push(e, look.scale(2.0).add(0, 0.4, 0));
        }
        deflectProjectiles(p, 8, 45);
        Vec3 palms = eye.add(0, -0.3, 0).add(look.scale(0.6));
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.GALE_PALM, palms, palms.add(look.scale(8)), 1f, 12);
        JutsuUtil.stream(level, ParticleTypes.CLOUD, eye.add(look), look, 25, 20, 0.6, 1.3);
        JutsuUtil.sound(level, eye, SoundEvents.ENDER_DRAGON_FLAP, 1.0f, 1.4f);
        return true;
    }

    /** Vacuum Blades: a volley of wind blades fanning out one after another (a few degrees apart, two ticks apart). */
    public static boolean vacuumBlade(ServerPlayer p, NinjaData d) {
        final int blades = 7;
        float yaw0 = p.getYRot(), pitch0 = p.getXRot();
        for (int i = 0; i < blades; i++) {
            float spread = (i - (blades - 1) / 2f) * 7f;
            float lift = (i % 2 == 0 ? -1 : 1) * 2.5f;
            com.shinobiarts.util.Scheduler.later(i * 2, () -> {
                if (p.isAlive() && !p.hasDisconnected()) vacuumBladeOne(p, yaw0 + spread, pitch0 + lift);
            });
        }
        return true;
    }

    private static void vacuumBladeOne(ServerPlayer p, float yaw, float pitch) {
        ServerLevel level = p.serverLevel();
        Vec3 start = p.getEyePosition();
        Vec3 dir = Vec3.directionFromRotation(pitch, yaw);
        BlockHitResult hit = level.clip(new net.minecraft.world.level.ClipContext(start, start.add(dir.scale(24)),
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, p));
        Vec3 end = hit.getType() == HitResult.Type.MISS ? start.add(dir.scale(24)) : hit.getLocation();
        AABB box = new AABB(start, end).inflate(1.0);
        for (Entity e : level.getEntities(p, box, cand -> JutsuUtil.isValidTarget(p, cand))) {
            if (e.getBoundingBox().inflate(0.8).clip(start, end).isPresent()) {
                e.invulnerableTime = 0;                               // every blade can land
                e.hurt(ModDamage.jutsu(level, p, p), dmg(5f));
            }
        }
        Vec3 from = start.add(0, -0.25, 0).add(dir);
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.VACUUM_BLADE, from, end, 1f, (int) (from.distanceTo(end) / 3) + 12);
        JutsuUtil.line(level, ParticleTypes.CLOUD, start.add(dir), end, 3.0, 1, 0.05);
        JutsuUtil.sound(level, start, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.6f + level.getRandom().nextFloat() * 0.3f);
    }

    public static boolean greatBreakthrough(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : JutsuUtil.inCone(p, 14, 40)) {
            e.hurt(ModDamage.jutsu(level, p, p), dmg(6f));
            JutsuUtil.push(e, look.scale(3.2).add(0, 0.6, 0));
        }
        deflectProjectiles(p, 14, 40);
        if (JutsuUtil.griefing(level, p)) {
            double minDot = Math.cos(Math.toRadians(40));
            BlockPos center = p.blockPosition();
            int broken = 0;
            for (BlockPos mpos : BlockPos.betweenClosed(center.offset(-10, -3, -10), center.offset(10, 6, 10))) {
                if (broken >= 120) break;
                BlockState state = level.getBlockState(mpos);
                if (state.isAir()) continue;
                boolean plant = state.is(BlockTags.LEAVES) || (state.canBeReplaced() && state.getFluidState().isEmpty());
                if (!plant) continue;
                Vec3 to = Vec3.atCenterOf(mpos).subtract(eye);
                double dist = to.length();
                if (dist > 10 || dist < 1e-3 || to.scale(1.0 / dist).dot(look) < minDot) continue;
                level.destroyBlock(mpos.immutable(), true, p);
                broken++;
            }
        }
        JutsuUtil.stream(level, ParticleTypes.CLOUD, eye.add(look), look, 35, 60, 0.9, 2.0);
        JutsuUtil.sound(level, eye, SoundEvents.ENDER_DRAGON_FLAP, 2.0f, 0.6f);
        return true;
    }

    private static void deflectProjectiles(ServerPlayer p, double range, double halfAngle) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double minDot = Math.cos(Math.toRadians(halfAngle));
        for (Projectile proj : p.level().getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(range), pr -> pr.getOwner() != p)) {
            Vec3 to = proj.position().subtract(eye);
            double dist = to.length();
            if (dist > range || (dist > 1e-3 && to.scale(1.0 / dist).dot(look) < minDot)) continue;
            proj.setDeltaMovement(look.scale(1.6));
            proj.setOwner(p);
            proj.hurtMarked = true;
        }
    }

    // ================================================================ LIGHTNING

    public static boolean lightningArmor(ServerPlayer p, NinjaData d) {
        d.setLightningArmorUntil(p.level().getGameTime() + 400); // the crackling glow everyone sees
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 19));      // speed 20
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));    // resistance 2
        p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 0));
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.ELECTRIC_SPARK, p.position().add(0, 1, 0), 80, 0.6, 0.3);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.TRIDENT_THUNDER, 0.6f, 1.8f);
        return true;
    }

    /**
     * Chidori: lightning takes over the hand, a crackling mass of bolts round the fist and up the arm, screeching. It
     * stays for 10 seconds; the next punch drives it in (see CommonEvents) for a big hit. No dash.
     */
    public static boolean chidori(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        d.setChidoriUntil(now + NinjaData.CHIDORI_HOLD_TICKS);
        com.shinobiarts.network.ModNetwork.sync(p);
        // the hand's lightning is re-sent every half second while it lasts, so it vanishes as soon as it's used
        com.shinobiarts.util.Scheduler.repeat(0, 10, NinjaData.CHIDORI_HOLD_TICKS / 10, i -> {
            if (!p.isAlive() || p.hasDisconnected() || !NinjaData.get(p).hasChidori(p.level().getGameTime())) return;
            com.shinobiarts.fx.Fx.on(p.serverLevel(), com.shinobiarts.fx.Fx.Visual.CHIDORI_HAND, p, null, 1f, 12);
            if (i % 2 == 0) JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEEHIVE_WORK, 1.2f, 2.0f);
            if (i % 3 == 0) JutsuUtil.sound(p.level(), p.position(), SoundEvents.TRIDENT_THUNDER, 0.25f, 2.0f);
        });
        JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, p.position().add(0, 1, 0), 40, 0.4, 0.3);
        JutsuUtil.sound(level, p.position(), SoundEvents.LIGHTNING_BOLT_IMPACT, 0.6f, 1.8f);
        return true;
    }

    /** The Chidori in hand lands: a burst of lightning through the target. */
    public static float chidoriHit(ServerPlayer p, LivingEntity target, NinjaData d) {
        ServerLevel level = p.serverLevel();
        d.setChidoriUntil(0);
        Vec3 at = target.getBoundingBox().getCenter();
        Vec3 dir = at.subtract(p.getEyePosition()).normalize();
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.BOLT, p.getEyePosition().add(0, -0.4, 0), at.add(dir.scale(2.5)), 1.6f, 9);
        JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, at, 120, 0.6, 0.5);
        JutsuUtil.particles(level, ParticleTypes.CRIT, at, 30, 0.4, 0.3);
        JutsuUtil.push(target, dir.scale(1.5).add(0, 0.35, 0));
        com.shinobiarts.ninja.Afflictions.stun(target, 20, com.shinobiarts.ninja.Afflictions.STUN_NONE);
        JutsuUtil.sound(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.2f, 1.4f);
        JutsuUtil.sound(level, at, SoundEvents.TRIDENT_THUNDER, 0.8f, 1.6f);
        return dmg(18f) * d.jutsuBonus(Jutsus.CHIDORI);
    }

    public static boolean thunderStrike(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 40);
        if (hit.getType() == HitResult.Type.MISS) {
            noTarget(p);
            return false;
        }
        BlockPos pos = hit.getBlockPos().relative(hit.getDirection());
        Vec3 c = Vec3.atBottomCenterOf(pos);
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.THUNDER, c, 1f, 14);   // a huge forked bolt from the sky
        JutsuUtil.sound(level, c, SoundEvents.LIGHTNING_BOLT_THUNDER, 3.0f, 0.9f);
        JutsuUtil.sound(level, c, SoundEvents.LIGHTNING_BOLT_IMPACT, 2.0f, 0.8f);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 4)) {
            e.hurt(ModDamage.jutsu(level, null, p), dmg(12f));
            e.setSecondsOnFire(3);
        }
        if (JutsuUtil.griefing(level, p) && BaseFireBlock.canBePlacedAt(level, pos, Direction.UP)) {
            level.setBlockAndUpdate(pos, BaseFireBlock.getState(level, pos));
        }
        JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, c.add(0, 1, 0), 120, 1.5, 0.5);
        return true;
    }

    // ================================================================ EARTH

    /**
     * Earth Wall: a wall of earth 5 wide and 3 tall heaves up out of the ground 3 blocks in front of you (it rises over
     * a third of a second, then stands as solid blocks).
     */
    /**
     * Earth Wall: a great wall of stone and cobblestone bursts up out of the ground in front of you, 5 wide, 18 high
     * and 5 thick, rising row by row. It crumbles away after about 15 seconds.
     */
    public static boolean earthWall(ServerPlayer p, NinjaData d) {
        final int width = 10, height = 18, depth = 3;
        ServerLevel level = p.serverLevel();
        Direction facing = p.getDirection();
        Direction side = facing.getClockWise();
        BlockPos origin = p.blockPosition().relative(facing, 3);
        BlockState stone = ModBlocks.EARTH_WALL.get().defaultBlockState();
        BlockState cobble = stone.setValue(com.shinobiarts.block.EarthWallBlock.COBBLE, true);
        boolean replacePlants = JutsuUtil.griefing(level, p);
        BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        java.util.List<java.util.List<BlockPos>> rows = new java.util.ArrayList<>();
        for (int h = 0; h < height; h++) rows.add(new java.util.ArrayList<>());
        BlockPos middle = null;
        for (int w = -(width / 2); w < width - width / 2; w++) {
            for (int k = 0; k < depth; k++) {
                BlockPos col = origin.relative(side, w).relative(facing, k);
                for (int i = 0; i < 3 && level.getBlockState(col.below()).canBeReplaced(); i++) col = col.below();
                for (int i = 0; i < 3 && !level.getBlockState(col).canBeReplaced(); i++) col = col.above();
                if (w == 0 && k == 0) middle = col;
                for (int h = 0; h < height; h++) rows.get(h).add(col.above(h));
            }
        }
        if (middle == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 base = Vec3.atBottomCenterOf(middle);
        RandomSource rnd = level.getRandom();
        for (BlockPos pos : rows.get(0)) level.sendParticles(dust, pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5, 6, 0.4, 0.2, 0.4, 0.15);
        for (int h = 0; h < height; h++) {                         // it rises a row a tick
            final java.util.List<BlockPos> row = rows.get(h);
            final int hh = h;
            com.shinobiarts.util.Scheduler.later(4 + h, () -> {
                for (BlockPos pos : row) {
                    BlockState existing = level.getBlockState(pos);
                    boolean free = existing.isAir() || (replacePlants && existing.canBeReplaced() && existing.getFluidState().isEmpty());
                    if (!free || !level.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) continue;
                    level.setBlock(pos, rnd.nextFloat() < 0.4f ? cobble : stone, 3);
                }
                BlockPos c = row.get(row.size() / 2);
                level.sendParticles(dust, c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5, 12, 2.5, 0.3, 2.5, 0.12);
                if (hh % 4 == 0) JutsuUtil.sound(level, Vec3.atCenterOf(c), SoundEvents.STONE_PLACE, 1.5f, 0.5f + hh * 0.02f);
            });
        }
        JutsuUtil.sound(level, base, SoundEvents.ROOTED_DIRT_PLACE, 1.5f, 0.6f);
        JutsuUtil.sound(level, base, SoundEvents.GRAVEL_BREAK, 1.5f, 0.5f);
        JutsuUtil.sound(level, base, SoundEvents.WARDEN_DIG, 1.2f, 0.8f);
        return true;
    }

    public static boolean rockArmor(ServerPlayer p, NinjaData d) {
        d.setRockArmorUntil(p.level().getGameTime() + 400);              // the stone skin everyone sees
        SharinganManager.updateLook(p);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 0));
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        JutsuUtil.particles(p.serverLevel(), stone, p.position().add(0, 1, 0), 60, 0.5, 0.1);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.STONE_PLACE, 1.2f, 0.5f);
        return true;
    }

    public static boolean earthSpikes(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 c = JutsuUtil.aimAnywhere(p, 20);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 5)) {
            e.hurt(ModDamage.jutsu(level, null, p), dmg(10f));
            JutsuUtil.push(e, new Vec3(0, 1.1, 0));
        }
        // the spike clusters (your Earth Flow Spike Cluster model): a big one in the middle and four smaller around it
        RandomSource r = level.getRandom();
        Vec3 middle = groundAt(level, c);
        if (middle != null) com.shinobiarts.entity.EarthSpikes.spawn(level, middle, r.nextFloat() * 360f, 1.5f, 0);
        float turn = r.nextFloat() * 90f;
        for (int i = 0; i < 4; i++) {
            double a = Math.toRadians(turn + i * 90 + r.nextFloat() * 40 - 20);
            double dist = 2.0 + r.nextDouble() * 0.7;
            Vec3 at = groundAt(level, c.add(Math.cos(a) * dist, 0, Math.sin(a) * dist));
            if (at != null) com.shinobiarts.entity.EarthSpikes.spawn(level, at, r.nextFloat() * 360f, 0.75f + r.nextFloat() * 0.15f, 1 + i % 2);
        }
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.COBBLESTONE.defaultBlockState());
        for (int i = 0; i < 10; i++) {                                // earth thrown up where they break through
            double a = r.nextDouble() * Math.PI * 2;
            double dist = r.nextDouble() * 3.5;
            Vec3 base = c.add(Math.cos(a) * dist, 0.1, Math.sin(a) * dist);
            level.sendParticles(i % 2 == 0 ? stone : dirt, base.x, base.y, base.z, 8, 0.3, 0.2, 0.3, 0.15);
        }
        JutsuUtil.sound(level, c, SoundEvents.STONE_BREAK, 2.0f, 0.5f);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.6f, 1.6f);
        return true;
    }

    /** The ground under (or just over) a point: the top of the first solid block within 4 blocks up or down, or null. */
    @Nullable
    private static Vec3 groundAt(ServerLevel level, Vec3 near) {
        BlockPos pos = BlockPos.containing(near.x, near.y + 0.5, near.z);
        for (int up = 0; up < 4 && !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty(); up++) pos = pos.above();
        for (int down = 0; down < 8; down++) {
            BlockPos below = pos.below();
            if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty()) return new Vec3(near.x, pos.getY(), near.z);
            pos = below;
        }
        return null;
    }

    // ================================================================ NON-ELEMENTAL

    /** Substitution isn't cast from a release any more (see {@link #toggleSubstitution}); this only primes it once. */
    public static boolean substitution(ServerPlayer p, NinjaData d) {
        d.setSubstitutionUntil(p.level().getGameTime() + 120);
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.POOF, p.position().add(0, 1, 0), 10, 0.3, 0.02);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, 0.8f, 1.2f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.substitution_ready").withStyle(ChatFormatting.LIGHT_PURPLE), true);
        return true;
    }

    /** The Substitution key (K by default): switches the automatic dodge on or off. Needs Substitution learned. */
    public static void toggleSubstitution(ServerPlayer p, NinjaData d) {
        if (!d.knows(Jutsus.SUBSTITUTION.id())) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.substitution_unknown").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        boolean on = !d.isSubstitutionOn();
        d.setSubstitutionOn(on);
        if (on) {
            JutsuUtil.particles(p.serverLevel(), ParticleTypes.POOF, p.position().add(0, 1, 0), 10, 0.3, 0.02);
            JutsuUtil.sound(p.level(), p.position(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, 0.8f, 1.2f);
        }
        p.displayClientMessage(Component.translatable(on ? "message.shinobiarts.substitution_on" : "message.shinobiarts.substitution_off")
                .withStyle(on ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.GRAY), true);
        com.shinobiarts.network.ModNetwork.sync(p);
    }

    /**
     * Something is about to hit the player: if their Substitution is switched on (or primed the old way), off
     * cooldown and they have the chakra, it pays for the swap and returns true; the caller cancels the hit and calls
     * {@link #triggerSubstitution}. Each swap costs Substitution's chakra and starts its cooldown.
     */
    public static boolean autoSubstitute(ServerPlayer p, NinjaData d, long now) {
        if (d.isStunned(now) || d.isSealed(now)) return false; // frozen in place, or no chakra to move
        if (d.getSubstitutionUntil() > now) {
            d.setSubstitutionUntil(0);
            return true;
        }
        Jutsu sub = Jutsus.SUBSTITUTION;
        if (!d.isSubstitutionOn() || !d.knows(sub.id()) || d.cooldownRemaining(sub.id(), now) > 0) return false;
        boolean creative = p.getAbilities().instabuild;
        float cost = sub.cost(d);
        if (!creative && d.getChakra() < cost) return false;
        if (!creative) d.consumeChakra(cost);
        d.setCooldown(sub.id(), now + sub.cooldownFor(d));
        return true;
    }

    /**
     * Called when a primed substitution absorbs a hit: you swap with two logs (left where you stood, they vanish
     * after {@code substitutionLogSeconds}) and reappear {@code substitutionBlocksBack} blocks back, away from the
     * attacker, and {@code substitutionBlocksUp} blocks up. Falling from there doesn't hurt.
     */
    public static void triggerSubstitution(ServerPlayer p, @Nullable Entity attacker) {
        ServerLevel level = p.serverLevel();
        Vec3 origin = p.position();
        Vec3 away = attacker != null ? origin.subtract(attacker.position()) : p.getLookAngle().scale(-1);
        away = new Vec3(away.x, 0, away.z);
        if (away.lengthSqr() < 1e-4) away = new Vec3(-p.getLookAngle().x, 0, -p.getLookAngle().z);
        if (away.lengthSqr() < 1e-4) away = new Vec3(1, 0, 0);
        away = away.normalize();

        // the two logs left behind: one standing where you were, one knocked over next to it
        int life = com.shinobiarts.Config.i(com.shinobiarts.Config.SUBSTITUTION_LOG_SECONDS) * 20;
        Vec3 side = new Vec3(-away.z, 0, away.x);
        float yaw = p.getYRot();
        com.shinobiarts.entity.SubstitutionLog.spawn(level, origin, yaw, true, life, new Vec3(0, 0.15, 0));
        com.shinobiarts.entity.SubstitutionLog.spawn(level, origin.add(side.scale(0.8)), yaw + 90f, false, life,
                side.scale(0.12).add(0, 0.25, 0));
        level.sendParticles(ParticleTypes.POOF, origin.x, origin.y + 1, origin.z, 30, 0.4, 0.8, 0.4, 0.02);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LOG.defaultBlockState()),
                origin.x, origin.y + 1, origin.z, 40, 0.3, 0.6, 0.3, 0.1);

        // back and up; closer if something is in the way
        int back = com.shinobiarts.Config.i(com.shinobiarts.Config.SUBSTITUTION_BACK);
        int up = com.shinobiarts.Config.i(com.shinobiarts.Config.SUBSTITUTION_UP);
        Vec3 dest = null;
        for (int dist = back; dist >= 0 && dest == null; dist--) {
            for (int dy = up; dy >= 0 && dest == null; dy--) {
                Vec3 candidate = origin.add(away.scale(dist)).add(0, dy, 0);
                if (fits(p, candidate)) dest = candidate;
            }
        }
        if (dest == null) dest = origin;
        JutsuUtil.teleport(p, dest);
        p.setDeltaMovement(Vec3.ZERO);
        p.hurtMarked = true;
        NinjaData d = NinjaData.get(p);
        if (d != null) d.setFallProtectUntil(level.getGameTime() + 80);

        level.sendParticles(ParticleTypes.POOF, dest.x, dest.y + 1, dest.z, 15, 0.3, 0.6, 0.3, 0.02);
        JutsuUtil.sound(level, origin, SoundEvents.WOOD_BREAK, 1.0f, 0.8f);
        JutsuUtil.sound(level, dest, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0f, 1.2f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.substitution_used").withStyle(ChatFormatting.LIGHT_PURPLE), true);
    }

    /** True if the entity fits at these feet coordinates (no blocks in the way, no lava). */
    private static boolean fits(Entity entity, Vec3 feet) {
        AABB box = entity.getBoundingBox().move(feet.x - entity.getX(), feet.y - entity.getY(), feet.z - entity.getZ());
        return entity.level().noCollision(entity, box)
                && !entity.level().getFluidState(BlockPos.containing(feet)).is(net.minecraft.tags.FluidTags.LAVA);
    }

    public static boolean bodyFlicker(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 16);
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(16)) : hit.getLocation().subtract(look.scale(0.7));
        Vec3 feet = aim.subtract(0, p.getEyeHeight(), 0);
        Vec3 step = look.scale(-0.5);
        Vec3 safe = null;
        for (int i = 0; i < 32 && safe == null; i++, feet = feet.add(step)) safe = JutsuUtil.findSafe(p, feet);
        if (safe == null || safe.distanceToSqr(p.position()) < 4) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 from = p.position();
        level.sendParticles(ParticleTypes.POOF, from.x, from.y + 1, from.z, 20, 0.3, 0.6, 0.3, 0.02);
        JutsuUtil.teleport(p, safe);
        level.sendParticles(ParticleTypes.POOF, safe.x, safe.y + 1, safe.z, 20, 0.3, 0.6, 0.3, 0.02);
        level.sendParticles(ParticleTypes.CHERRY_LEAVES, safe.x, safe.y + 1, safe.z, 12, 0.6, 0.6, 0.6, 0.0);
        JutsuUtil.sound(level, from, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.6f);
        JutsuUtil.sound(level, safe, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.8f);
        return true;
    }

    public static boolean shadowClone(ServerPlayer p, NinjaData d) {
        return spawnClones(p, d, com.shinobiarts.Config.i(com.shinobiarts.Config.SHADOW_CLONE_COUNT), false);
    }

    /** Multi Shadow Clone Jutsu: ten clones at once (twenty for an Uzumaki), in a ring around you. */
    public static boolean multiShadowClone(ServerPlayer p, NinjaData d) {
        boolean ok = spawnClones(p, d, com.shinobiarts.Config.i(com.shinobiarts.Config.MULTI_SHADOW_CLONE_COUNT), false);
        if (ok) {
            p.serverLevel().sendParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1, p.getZ(), 80, 2.5, 0.8, 2.5, 0.05);
            JutsuUtil.sound(p.level(), p.position(), SoundEvents.FIRE_EXTINGUISH, 1.2f, 1.2f);
        }
        return ok;
    }

    /** Pops {@code base} clones out beside you (Uzumaki get twice as many); a few in a line, many in a ring. */
    private static boolean spawnClones(ServerPlayer p, NinjaData d, int base, boolean water) {
        ServerLevel level = p.serverLevel();
        // Only one batch of clones at a time.
        for (ShadowClone old : level.getEntitiesOfClass(ShadowClone.class, p.getBoundingBox().inflate(96),
                c -> p.getUUID().equals(c.getOwnerUUID()))) {
            old.poof();
        }
        int count = d.getClan() == Clan.UZUMAKI && !water ? base * 2 : base;
        Vec3 right = JutsuUtil.right(p);
        Vec3 forward = new Vec3(right.z, 0, -right.x);
        boolean ring = count > 4;
        double radius = 2.0 + count * 0.12;
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            Vec3 pos;
            if (ring) {
                double a = Math.PI * 2 * i / count;
                pos = p.position().add(right.scale(Math.cos(a) * radius)).add(forward.scale(Math.sin(a) * radius));
            } else {
                double offset = (i % 2 == 0 ? 1 : -1) * (1.5 + (i / 2) * 1.5);
                pos = p.position().add(right.scale(offset));
            }
            ShadowClone clone = ModEntities.SHADOW_CLONE.get().create(level);
            if (clone == null) continue;
            clone.moveTo(pos.x, p.getY(), pos.z, p.getYRot(), p.getXRot());
            if (!level.noCollision(clone)) clone.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot());
            clone.setYHeadRot(p.getYHeadRot());
            clone.setOwner(p);
            clone.setWater(water);
            clone.copyEquipment(p);
            long rasengan = d.getRasenganUntil() - p.level().getGameTime();
            if (rasengan > 0) clone.giveHandJutsu(ShadowClone.HandJutsu.RASENGAN,                 // a Rasengan already in hand
                    (int) Math.min(rasengan, NinjaData.RASENGAN_HOLD_TICKS));
            level.addFreshEntity(clone);
            level.sendParticles(water ? ParticleTypes.SPLASH : ParticleTypes.POOF, clone.getX(), clone.getY() + 1, clone.getZ(), 25, 0.3, 0.7, 0.3, 0.03);
            spawned++;
        }
        if (spawned == 0) return false;
        JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 0.8f, 1.6f);
        return true;
    }

    /**
     * Rasengan: two shadow clones pop out beside you and shape it in your palm (drawn by the client, see
     * client/RasenganRender), then it stays in hand until you punch something. It can't hit while it's forming.
     */
    /**
     * Chakra Control decides whether a Rasengan can be shaped alone (ChakraMastery): Low needs a shadow clone of yours
     * beside you; Medium without one costs 50% more and lasts half as long; Mastered lasts 50% longer.
     * Returns the hold time, or -1 if it can't be made.
     */
    private static int rasenganHold(ServerPlayer p, NinjaData d) {
        boolean clone = com.shinobiarts.ninja.ChakraMastery.cloneNearby(p);
        int hold = NinjaData.RASENGAN_HOLD_TICKS;
        switch (com.shinobiarts.ninja.ChakraMastery.tier(d)) {
            case LOW -> {
                if (!clone) {
                    p.displayClientMessage(Component.translatable("message.shinobiarts.cc_need_clone").withStyle(ChatFormatting.RED), true);
                    JutsuUtil.particles(p.serverLevel(), ParticleTypes.CLOUD, p.position().add(0, 1.2, 0), 12, 0.3, 0.05);
                    return -1;
                }
            }
            case MEDIUM -> {
                if (!clone) {
                    float extra = 0.5f * Jutsus.RASENGAN.cost(d);
                    if (!p.isCreative() && d.getChakra() < extra) {
                        p.displayClientMessage(Component.translatable("message.shinobiarts.cc_unsteady").withStyle(ChatFormatting.RED), true);
                        return -1;
                    }
                    if (!p.isCreative()) d.consumeChakra(extra);
                    hold /= 2;
                    p.displayClientMessage(Component.translatable("message.shinobiarts.cc_unsteady_ok").withStyle(ChatFormatting.YELLOW), true);
                }
            }
            case HIGH -> {
            }
            case MASTERED -> hold = hold * 3 / 2;
        }
        return hold;
    }

    public static boolean rasengan(ServerPlayer p, NinjaData d) {
        int hold = rasenganHold(p, d);
        if (hold < 0) return false;
        d.setRasenganUntil(p.level().getGameTime() + NinjaData.RASENGAN_FORM_TICKS + hold);
        d.setRasenshuriken(false);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.FIRE_EXTINGUISH, 0.7f, 1.6f);   // the clones' poof
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.8f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.rasengan_forming").withStyle(ChatFormatting.AQUA), true);
        SharinganManager.updateLook(p);
        return true;
    }

    /** Called from the melee-hit event when a charged Rasengan connects (also used by shadow clones). */
    public static void rasenganHit(LivingEntity p, LivingEntity target) {
        ServerLevel level = (ServerLevel) p.level();
        Vec3 dir = target.position().subtract(p.position()).multiply(1, 0, 1);
        dir = dir.lengthSqr() < 1e-4 ? p.getLookAngle() : dir.normalize();
        JutsuUtil.push(target, dir.scale(2.2).add(0, 0.6, 0));
        Vec3 c = target.getBoundingBox().getCenter();
        level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        JutsuUtil.particles(level, CHAKRA_DUST, c, 60, 0.6, 0.0);
        JutsuUtil.stream(level, ParticleTypes.CLOUD, c, dir, 50, 30, 0.2, 0.6);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.8f, 1.4f);
    }

    /**
     * Wind Release: Rasenshuriken. Formed like the Rasengan (two shadow clones pop up and shape it on your palm), with
     * a disc of white wind blades screaming round it. Once it's ready: punch with it to slam it into what you hit, or
     * swing at the air (or a block) to throw it. Either way it bursts into a sphere of wind blades.
     */
    public static boolean rasenshuriken(ServerPlayer p, NinjaData d) {
        if (d.getRasenganUntil() > p.level().getGameTime()) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.rasengan_in_hand").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        int hold = rasenganHold(p, d);
        if (hold < 0) return false;
        d.setRasenganUntil(p.level().getGameTime() + NinjaData.RASENGAN_FORM_TICKS + hold);
        d.setRasenshuriken(true);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.FIRE_EXTINGUISH, 0.7f, 1.6f);   // the clones' poof
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.4f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ELYTRA_FLYING, 0.8f, 1.9f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.rasenshuriken_forming").withStyle(ChatFormatting.AQUA), true);
        SharinganManager.updateLook(p);
        return true;
    }

    /** Damage of the Rasenshuriken in hand (slammed or thrown). */
    public static float rasenshurikenDamage(NinjaData d) {
        return 20f * com.shinobiarts.Config.f(com.shinobiarts.Config.DAMAGE_MULTIPLIER) * d.jutsuBonus(Jutsus.RASENSHURIKEN)
                * Jutsus.RASENSHURIKEN.damageMultiplier();
    }

    /** Swinging at the air or a block with a formed Rasenshuriken: it's thrown. Returns whether it was. */
    public static boolean throwRasenshuriken(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        if (!d.hasRasengan(now) || !d.isRasenshuriken()) return false;
        JutsuUtil.noteCast(p, Jutsus.RASENSHURIKEN);
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.RASENSHURIKEN, 1.15f, 0f, rasenshurikenDamage(d));
        d.setRasenganUntil(0);
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.SWEEP_ATTACK, p.getEyePosition().add(p.getLookAngle().scale(1.0)), 6, 0.4, 0.0);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ELYTRA_FLYING, 1.0f, 1.8f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.7f);
        SharinganManager.updateLook(p);
        com.shinobiarts.network.ModNetwork.sync(p);
        return true;
    }

    // ================================================================ CLAN

    /**
     * Shadow Possession: your shadow races along the ground to the creature you look at and holds it. Until it lets go
     * (longer with Genjutsu) the target copies every step, jump, turn and swing you make (see ShadowPossession).
     */
    public static boolean shadowPossession(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, com.shinobiarts.Config.i(com.shinobiarts.Config.SHADOW_POSSESSION_RANGE));
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int duration = Math.round((float) (com.shinobiarts.Config.d(com.shinobiarts.Config.SHADOW_POSSESSION_SECONDS) * 20));   // a flat 10 s by default
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 2));
        ShadowPossession.start(p, target, duration);
        JutsuUtil.line(level, SHADOW_DUST, p.position().add(0, 0.1, 0), target.position().add(0, 0.1, 0), 0.3, 2, 0.08);
        JutsuUtil.particles(level, ParticleTypes.SQUID_INK, target.position().add(0, 0.3, 0), 30, 0.4, 0.02);
        JutsuUtil.sound(level, target.position(), SoundEvents.SOUL_ESCAPE, 1.5f, 0.6f);
        return true;
    }

    /**
     * Mind Body Transfer (Yamanaka): your mind leaves your body and enters the creature you look at (up to 30 blocks).
     * You see through its eyes and move, look and attack with its body, while yours stands empty. Sneak to come back.
     */
    public static boolean mindBodyTransfer(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        if (target == null) {
            noTarget(p);
            return false;
        }
        int ticks = Math.round((float) (com.shinobiarts.Config.d(com.shinobiarts.Config.MIND_TRANSFER_SECONDS) * 20 * d.genjutsuMultiplier()));
        MindTransfer.start(p, target, ticks);
        return true;
    }

    public static boolean palmRotation(ServerPlayer p, NinjaData d) {
        d.setRotationUntil(p.level().getGameTime() + 30);
        com.shinobiarts.fx.Fx.on(p.serverLevel(), com.shinobiarts.fx.Fx.Visual.PALM_ROTATION, p, null, 2.8f, 32);
        for (LivingEntity e : JutsuUtil.inRadius(p.level(), p, p.position().add(0, 1, 0), 5)) {
            e.hurt(ModDamage.jutsu(p.level(), p, p), dmg(5f));
        }
        rotationTick(p);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.5f, 1.2f);
        return true;
    }

    /** Runs every tick while Palm Rotation is spinning. */
    public static void rotationTick(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        if (p.tickCount % 2 == 0) {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c.add(0, 1, 0), 4.5)) {
                Vec3 dir = e.position().subtract(c).multiply(1, 0, 1);
                dir = dir.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : dir.normalize();
                JutsuUtil.push(e, dir.scale(1.2).add(0, 0.35, 0));
            }
            List<Projectile> incoming = level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(5), pr -> pr.getOwner() != p);
            for (Projectile proj : incoming) {
                level.sendParticles(ParticleTypes.CRIT, proj.getX(), proj.getY(), proj.getZ(), 5, 0.1, 0.1, 0.1, 0.1);
                proj.discard();
            }
        }
        double angle = (p.tickCount % 10) / 10.0 * Math.PI * 2;      // dust kicked up round the dome's foot
        for (int i = 0; i < 4; i++) {
            double a = angle + i * Math.PI / 2;
            level.sendParticles(ParticleTypes.POOF, c.x + Math.cos(a) * 2.9, c.y + 0.1, c.z + Math.sin(a) * 2.9, 0,
                    -Math.sin(a) * 0.3, 0.05, Math.cos(a) * 0.3, 0.1);
        }
    }

    // ================================================================ YIN (illusions, scale with Genjutsu)

    public static boolean hellViewing(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int duration = Math.round(120 * d.genjutsuMultiplier());
        applyIllusion(target, duration);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.HELL_VIEWING, target, null, 1f, duration);
        target.hurt(ModDamage.jutsu(level, p, p), dmg(2f));
        JutsuUtil.particles(level, YIN_DUST, target.getEyePosition(), 50, 0.5, 0.0);
        JutsuUtil.particles(level, ParticleTypes.SQUID_INK, target.getEyePosition(), 15, 0.3, 0.02);
        JutsuUtil.sound(level, target.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.6f, 1.4f);
        return true;
    }

    public static boolean mindFog(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        List<LivingEntity> targets = JutsuUtil.inRadius(level, p, p.position().add(0, 1, 0), 7);
        int duration = Math.round(100 * d.genjutsuMultiplier());
        for (LivingEntity e : targets) applyIllusion(e, duration);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.MIND_FOG, p, null, 7f, duration);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3;
            JutsuUtil.particles(level, YIN_DUST, p.position().add(Math.cos(a) * 3.5, 1.0, Math.sin(a) * 3.5), 25, 1.2, 0.0);
        }
        JutsuUtil.particles(level, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 60, 3.0, 0.02);
        JutsuUtil.sound(level, p.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.8f, 0.8f);
        return true;
    }

    /** Players see darkness and swaying vision; mobs lose track of their target and stumble. */
    public static void applyIllusion(LivingEntity target, int duration) {
        if (target instanceof net.minecraft.world.entity.player.Player) {
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, duration + 40, 0));
            target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, duration, 0));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 1));
        } else {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 3));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 2));
            if (target instanceof Mob mob) {
                mob.setTarget(null);
                mob.getNavigation().stop();
            }
        }
    }

    // ================================================================ YANG (vitality, scales with Medical)

    public static boolean mysticalPalm(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        float amount = 6f + d.stat(Stat.MEDICAL) * 0.25f;
        LivingEntity patient = p;
        // Heal the player you're looking at (within 5 blocks) instead of yourself, if any.
        Vec3 eye = p.getEyePosition();
        for (net.minecraft.world.entity.player.Player other : level.getEntitiesOfClass(net.minecraft.world.entity.player.Player.class,
                p.getBoundingBox().inflate(5), o -> o != p && o.isAlive())) {
            Vec3 to = other.getBoundingBox().getCenter().subtract(eye);
            if (to.length() <= 5 && to.normalize().dot(p.getLookAngle()) > 0.95 && p.hasLineOfSight(other)) {
                patient = other;
                break;
            }
        }
        if (patient.getHealth() >= patient.getMaxHealth()) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.full_health").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        patient.heal(amount);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.MYSTICAL_PALM, p, patient, 1f, 30);
        JutsuUtil.particles(level, YANG_DUST, patient.getBoundingBox().getCenter(), 40, 0.5, 0.0);
        JutsuUtil.particles(level, ParticleTypes.HEART, patient.getEyePosition(), 4, 0.4, 0.0);
        JutsuUtil.sound(level, patient.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.2f, 1.2f);
        return true;
    }

    public static boolean vitalitySurge(ServerPlayer p, NinjaData d) {
        int bonus = d.stat(Stat.MEDICAL) * 4;
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200 + bonus, 1));
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400 + bonus, 1));
        p.removeEffect(MobEffects.POISON);
        p.removeEffect(MobEffects.WITHER);
        p.removeEffect(MobEffects.HUNGER);
        ServerLevel level = p.serverLevel();
        d.setSealMarksUntil(level.getGameTime() + 200 + bonus);         // the Strength of a Hundred seal spreads over the body
        SharinganManager.updateLook(p);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.VITALITY_BURST, p, null, 1f, 24);
        JutsuUtil.particles(level, YANG_DUST, p.position().add(0, 1, 0), 80, 0.7, 0.0);
        JutsuUtil.particles(level, ParticleTypes.HAPPY_VILLAGER, p.position().add(0, 1, 0), 20, 0.6, 0.0);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.4f);
        return true;
    }
}
