package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * A kunai with an explosive tag tied to it: it sticks where it lands, the tag burns down for a second and a half
 * (hissing, sparks running along it), and it blows. Stuck in someone, it goes off almost at once.
 */
public class ExplosiveKunaiEntity extends AbstractArrow {
    private static final EntityDataAccessor<Integer> FUSE = SynchedEntityData.defineId(ExplosiveKunaiEntity.class, EntityDataSerializers.INT);
    public static final int FUSE_TICKS = 30;
    private static final float POWER = 2.2f;

    public ExplosiveKunaiEntity(EntityType<? extends ExplosiveKunaiEntity> type, Level level) {
        super(type, level);
    }

    public ExplosiveKunaiEntity(Level level, LivingEntity owner) {
        super(ModEntities.EXPLOSIVE_KUNAI.get(), owner, level);
        setBaseDamage(3.0);
        pickup = Pickup.DISALLOWED;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(FUSE, -1);
    }

    /** Ticks left before it blows, or -1 while it's still flying. */
    public int getFuse() {
        return entityData.get(FUSE);
    }

    @Override
    protected ItemStack getPickupItem() {
        return new ItemStack(ModItems.EXPLOSIVE_KUNAI.get());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!level().isClientSide && getFuse() < 0) {
            entityData.set(FUSE, FUSE_TICKS);
            playSound(SoundEvents.TNT_PRIMED, 0.8f, 1.6f);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        Entity owner = getOwner();
        target.hurt(damageSources().arrow(this, owner == null ? this : owner), 5.0f);
        setDeltaMovement(getDeltaMovement().multiply(-0.01, -0.1, -0.01));
        if (!level().isClientSide && getFuse() < 0) {
            entityData.set(FUSE, 5);
            playSound(SoundEvents.TNT_PRIMED, 0.8f, 1.8f);
        }
    }

    @Override
    public void tick() {
        super.tick();
        int fuse = getFuse();
        if (fuse < 0) return;
        if (level().isClientSide) {
            level().addParticle(ParticleTypes.SMALL_FLAME, getX(), getY() + 0.1, getZ(), 0, 0.02, 0);
            level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.15, getZ(), 0, 0.03, 0);
            return;
        }
        if (fuse == 0) {
            Level.ExplosionInteraction mode = JutsuUtil.griefing(level(), getOwner())
                    ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
            level().explode(this, getX(), getY(), getZ(), POWER, mode);
            ((ServerLevel) level()).sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
            discard();
            return;
        }
        entityData.set(FUSE, fuse - 1);
    }

    @Override
    protected boolean tryPickup(Player player) {
        return false;                                       // it's about to explode: no picking it up
    }

    @Override
    protected SoundEvent getDefaultHitGroundSoundEvent() {
        return SoundEvents.TRIDENT_HIT_GROUND;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuse", getFuse());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Fuse")) entityData.set(FUSE, tag.getInt("Fuse"));
    }
}
