package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Majestic Destroyer Flame (Madara): a thin jet of fire from the caster's mouth that bursts into a towering wall of
 * flame, rolling forward and spreading wider as it goes. It burns everything it passes over (once each, then they keep
 * burning) and leaves a sea of fire behind it that dies down. The wave stays where it was cast (it doesn't follow the
 * caster); drawn by client/MajesticFlameRenderer from the shape worked out here.
 */
public class MajesticFlame extends Entity {
    /** Ticks of the jet from the mouth before the wall of fire bursts out. */
    public static final int JET = 8;
    /** Blocks the front rolls forward each tick. */
    public static final float SPEED = 0.85f;
    /** Ticks the sea of fire lingers once the front has stopped. */
    public static final int LINGER = 30;

    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(MajesticFlame.class, EntityDataSerializers.FLOAT);

    @Nullable
    private UUID ownerId;
    private float damage = 20f;
    /** The jutsu it came from (Majestic Destroyer Flame, or the smaller Great Fire Annihilation), for death messages. */
    private String jutsuId = "majestic_destroyer_flame";

    public String jutsuId() {
        return jutsuId;
    }
    private final Set<Integer> hit = new HashSet<>();

    public MajesticFlame(EntityType<? extends MajesticFlame> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    /** Breathes the flame from {@code caster}, facing where they face; {@code scale} 1 is the full-size wave. */
    public static void cast(ServerPlayer caster, float damage, float scale) {
        cast(caster, damage, scale, "majestic_destroyer_flame");
    }

    /** The same wave for another fire jutsu ({@code jutsuId} names it in death messages). */
    public static void cast(ServerPlayer caster, float damage, float scale, String jutsuId) {
        MajesticFlame f = new MajesticFlame(ModEntities.MAJESTIC_FLAME.get(), caster.level());
        float yaw = caster.getYRot();
        f.setPos(caster.getX(), caster.getY(), caster.getZ());
        f.setYRot(yaw);
        f.yRotO = yaw;
        f.ownerId = caster.getUUID();
        f.damage = damage;
        f.jutsuId = jutsuId;
        f.entityData.set(SCALE, Mth.clamp(scale * com.shinobiarts.jutsu.JutsuUtil.size(), 0.3f, 20f));
        caster.level().addFreshEntity(f);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(SCALE, 1f);
    }

    public float getScale() {
        return this.entityData.get(SCALE);
    }

    // ---------------------------------------------------------------- the wave's shape (both sides)

    /** How far the front reaches, {@code age} ticks after the cast. */
    public static float frontDistance(float age, float scale) {
        if (age < JET) return 6f * age / JET;
        return Math.min(maxDistance(scale), 6f + (age - JET) * SPEED);
    }

    public static float maxDistance(float scale) {
        return 32f * scale;
    }

    /** Ticks for the front to reach {@code dist}. */
    public static float ticksToReach(float dist) {
        return dist <= 6f ? JET * dist / 6f : JET + (dist - 6f) / SPEED;
    }

    /** Half the wave's width, {@code dist} blocks out. */
    public static float halfWidth(float dist, float scale) {
        return Math.min(15f * scale, 1.0f + dist * 0.62f);
    }

    /** The wave's height, {@code dist} blocks out. */
    public static float height(float dist, float scale) {
        return Math.min(8f * scale, 1.6f + dist * 0.3f);
    }

    public int lifetime() {
        return Math.round(ticksToReach(maxDistance(getScale()))) + LINGER;
    }

    public Vec3 forward() {
        float yaw = getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
    }

    /** To the caster's right. */
    public Vec3 side() {
        Vec3 f = forward();
        return new Vec3(-f.z, 0, f.x);
    }

    // ---------------------------------------------------------------- ticking

    @Override
    public void tick() {
        super.tick();
        float scale = getScale();
        float age = tickCount;
        Vec3 fwd = forward(), side = side();
        if (level().isClientSide) {
            clientParticles(age, scale, fwd, side);
            return;
        }
        if (tickCount > lifetime()) {
            discard();
            return;
        }
        ServerLevel level = (ServerLevel) level();
        Entity owner = ownerId == null ? null : level.getEntity(ownerId);
        float front = frontDistance(age, scale);
        float maxD = maxDistance(scale);
        boolean moving = front < maxD - 0.01f;

        // everything it has rolled over: hit once, and kept burning while it stands in the fire
        double reach = front + 2;
        AABB box = new AABB(getX() - reach, getY() - 3, getZ() - reach, getX() + reach, getY() + height(front, scale) + 2, getZ() + reach);
        boolean dying = tickCount > lifetime() - LINGER / 2;
        for (Entity e : level.getEntities(this, box, c -> JutsuUtil.isValidTarget(owner, c))) {
            if (owner != null && e == owner) continue;
            Vec3 rel = e.position().subtract(position());
            double f = rel.dot(fwd), l = rel.dot(side);
            if (f < 0.6 || f > front + 0.8) continue;
            double hw = age < JET ? 0.8 : halfWidth((float) f, scale) + 0.6;
            if (Math.abs(l) > hw || rel.y < -2.5 || rel.y > height((float) f, scale) + 1) continue;
            if (hit.add(e.getId()) && e instanceof LivingEntity living) {
                living.hurt(ModDamage.jutsu(level, this, owner), damage);
                JutsuUtil.push(living, fwd.scale(0.6).add(0, 0.35, 0));
            }
            if (!dying) e.setSecondsOnFire(10);
        }

        // set the ground alight along the front
        if (moving && age >= JET && owner != null && JutsuUtil.griefing(level, owner)) {
            RandomSource r = level.getRandom();
            float hw = halfWidth(front, scale);
            for (int i = 0; i < 4; i++) {
                Vec3 p = position().add(fwd.scale(front - r.nextFloat() * 2)).add(side.scale((r.nextFloat() * 2 - 1) * hw)).add(0, 2, 0);
                BlockPos pos = BlockPos.containing(p);
                for (int k = 0; k < 6; k++, pos = pos.below()) {
                    if (BaseFireBlock.canBePlacedAt(level, pos, Direction.UP)) {
                        level.setBlockAndUpdate(pos, BaseFireBlock.getState(level, pos));
                        break;
                    }
                }
            }
        }
        // the roar
        Vec3 at = position().add(fwd.scale(front)).add(0, 1.5, 0);
        if (tickCount == 1) {
            level.playSound(null, getX(), getY() + 1.5, getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 2.0f, 0.5f);
        } else if (tickCount == JET) {
            level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.0f, 0.6f);
            level.playSound(null, at.x, at.y, at.z, SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 3.0f, 0.4f);
        } else if (moving && tickCount % 5 == 0) {
            level.playSound(null, at.x, at.y, at.z, SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 2.5f, 0.35f + level.getRandom().nextFloat() * 0.15f);
        }
    }

    /** Embers, flames and smoke along the front (client only). */
    private void clientParticles(float age, float scale, Vec3 fwd, Vec3 side) {
        RandomSource r = level().getRandom();
        float front = frontDistance(age, scale);
        if (age < JET) {
            Vec3 mouth = position().add(0, 1.5, 0);
            for (int i = 0; i < 4; i++) {
                double t = r.nextDouble() * front;
                Vec3 p = mouth.add(fwd.scale(t));
                level().addParticle(ParticleTypes.FLAME, p.x, p.y, p.z, fwd.x * 0.2, 0.01, fwd.z * 0.2);
            }
            return;
        }
        if (tickCount > lifetime() - LINGER) return;
        float hw = halfWidth(front, scale), h = height(front, scale);
        for (int i = 0; i < 10; i++) {
            Vec3 p = position().add(fwd.scale(front - r.nextFloat() * 3)).add(side.scale((r.nextFloat() * 2 - 1) * hw))
                    .add(0, r.nextFloat() * h, 0);
            level().addParticle(i % 3 == 0 ? ParticleTypes.LAVA : ParticleTypes.FLAME, p.x, p.y, p.z,
                    fwd.x * 0.15, 0.05 + r.nextFloat() * 0.1, fwd.z * 0.15);
        }
        for (int i = 0; i < 3; i++) {
            Vec3 p = position().add(fwd.scale(front - 2 - r.nextFloat() * 4)).add(side.scale((r.nextFloat() * 2 - 1) * hw))
                    .add(0, h * (0.8 + r.nextFloat() * 0.4), 0);
            level().addParticle(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 0, 0.08, 0);
        }
    }

    // ---------------------------------------------------------------- an effect, not a creature

    /** Drawn whenever any of the wave could be on screen. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double r = maxDistance(getScale()) + 4;
        return new AABB(getX() - r, getY() - 2, getZ() - r, getX() + r, getY() + height(maxDistance(getScale()), getScale()) + 4, getZ() + r);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 160 * 160;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
