package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.world.KamuiPillarsFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** World generation features (used by the mod's own dimensions, see data/shinobiarts/worldgen). */
public final class ModFeatures {
    private ModFeatures() {}

    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, ShinobiArts.MODID);

    /** World generators: the Sage realms' (see world/RealmChunkGenerator). */
    public static final DeferredRegister<com.mojang.serialization.Codec<? extends net.minecraft.world.level.chunk.ChunkGenerator>> GENERATORS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.CHUNK_GENERATOR, ShinobiArts.MODID);
    public static final RegistryObject<com.mojang.serialization.Codec<? extends net.minecraft.world.level.chunk.ChunkGenerator>> REALM_GENERATOR =
            GENERATORS.register("realm", () -> com.shinobiarts.world.RealmChunkGenerator.CODEC);

    public static final RegistryObject<KamuiPillarsFeature> KAMUI_PILLARS = FEATURES.register("kamui_pillars",
            () -> new KamuiPillarsFeature(NoneFeatureConfiguration.CODEC));

}
