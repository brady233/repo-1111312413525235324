package com.shinobiarts.registry;

import com.mojang.serialization.Codec;
import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import net.minecraft.core.Holder;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.ModifiableBiomeInfo;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * The Ninja Bandits' spawns (data/shinobiarts/forge/biome_modifier/ninja_bandits.json). The weight and group size come
 * from "Spawn weights and chances.toml", which Forge loads before it applies biome modifiers when a world starts.
 */
public final class ModBiomeModifiers {
    public static final DeferredRegister<Codec<? extends BiomeModifier>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.Keys.BIOME_MODIFIER_SERIALIZERS, ShinobiArts.MODID);

    public static final RegistryObject<Codec<BanditSpawns>> BANDIT_SPAWNS = SERIALIZERS.register("bandit_spawns",
            () -> Codec.unit(new BanditSpawns()));

    /** Adds Ninja Bandits to every Overworld biome with the configured weight (0 = none). */
    public record BanditSpawns() implements BiomeModifier {
        @Override
        public void modify(Holder<Biome> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase != Phase.ADD || !biome.is(BiomeTags.IS_OVERWORLD)) return;
            int weight = Config.i(Config.BANDIT_SPAWN_WEIGHT);
            if (weight <= 0) return;
            int min = Math.max(1, Config.i(Config.BANDIT_GROUP_MIN));
            int max = Math.max(min, Config.i(Config.BANDIT_GROUP_MAX));
            builder.getMobSpawnSettings().addSpawn(ModEntities.NINJA_BANDIT.get().getCategory(),
                    new MobSpawnSettings.SpawnerData(ModEntities.NINJA_BANDIT.get(), weight, min, max));
        }

        @Override
        public Codec<? extends BiomeModifier> codec() {
            return BANDIT_SPAWNS.get();
        }
    }

    private ModBiomeModifiers() {}
}
