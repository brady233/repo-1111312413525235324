package com.shinobiarts.pvp;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * XP and Ryo for fighting other players, with protections:
 * <ul>
 *   <li>Level-gap rule: no rewards when the two players' levels are too far apart, either way. Strong players
 *       get nothing for beating new players, and new players get nothing for beating strong ones
 *       (stops boosting alt accounts). Players can still fight and kill each other.</li>
 *   <li>No rewards for defeating the same player again within a cooldown.</li>
 *   <li>No kill rewards if the victim was AFK (not moving or fighting), which stops alt-account farming.</li>
 *   <li>XP from hits is capped per minute.</li>
 * </ul>
 * Kills by your shadow clones and jutsu count as yours. All numbers are in the "pvp" config section.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PvpRewards {
    private static final Map<UUID, Long> lastActive = new HashMap<>();
    private static final Map<UUID, Vec3> lastPosition = new HashMap<>();
    private static final Map<String, Long> lastRewardedKill = new HashMap<>();
    private static final Map<UUID, long[]> hitXpWindow = new HashMap<>(); // {window start ms, xp given}

    private PvpRewards() {}

    /**
     * True if the two levels are too far apart for the fight to be rewarded (in either direction).
     * Allowed gap = max(minLevelGap, lower level * levelGapPercent).
     */
    public static boolean levelGapTooBig(int attackerLevel, int victimLevel) {
        int low = Math.min(attackerLevel, victimLevel);
        int high = Math.max(attackerLevel, victimLevel);
        int allowed = Math.max(Config.i(Config.PVP_MIN_LEVEL_GAP), (int) Math.round(low * Config.d(Config.PVP_LEVEL_GAP_PERCENT)));
        return high - low > allowed;
    }

    /** The player responsible for a hit: the attacker, or the owner of an attacking shadow clone. */
    @Nullable
    public static ServerPlayer responsiblePlayer(DamageSource source) {
        Entity e = source.getEntity();
        if (e instanceof ServerPlayer sp) return sp;
        if (e instanceof ShadowClone clone && clone.getOwner() instanceof ServerPlayer owner) return owner;
        return null;
    }

    private static void markActive(ServerPlayer player) {
        lastActive.put(player.getUUID(), System.currentTimeMillis());
    }

    private static boolean wasActive(ServerPlayer player) {
        Long t = lastActive.get(player.getUUID());
        return t != null && System.currentTimeMillis() - t <= Config.i(Config.PVP_ACTIVITY_WINDOW) * 1000L;
    }

    // ---------------------------------------------------------------- activity tracking

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER || !(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;
        Vec3 now = player.position();
        Vec3 before = lastPosition.put(player.getUUID(), now);
        if (before != null && before.distanceToSqr(now) > 1.0) markActive(player);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        lastActive.remove(id);
        lastPosition.remove(id);
        hitXpWindow.remove(id);
    }

    // ---------------------------------------------------------------- hits

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        ServerPlayer attacker = responsiblePlayer(event.getSource());
        if (attacker == null) return;
        markActive(attacker);
        if (!(event.getEntity() instanceof ServerPlayer victim) || victim == attacker || event.getAmount() <= 0) return;
        if (!Config.b(Config.PVP_REWARDS) || !attacker.canHarmPlayer(victim)) return;

        NinjaData ad = NinjaData.get(attacker);
        NinjaData vd = NinjaData.get(victim);
        if (ad == null || vd == null || levelGapTooBig(ad.getLevel(), vd.getLevel())) return;

        int perHit = Config.i(Config.PVP_HIT_XP);
        int cap = Config.i(Config.PVP_HIT_XP_PER_MINUTE);
        if (perHit <= 0 || cap <= 0) return;
        long now = System.currentTimeMillis();
        long[] window = hitXpWindow.computeIfAbsent(attacker.getUUID(), k -> new long[]{now, 0});
        if (now - window[0] > 60_000L) {
            window[0] = now;
            window[1] = 0;
        }
        int give = (int) Math.min(perHit, cap - window[1]);
        if (give <= 0) return;
        window[1] += give;
        PlayerDataManager.addEarnedXp(attacker, give);
    }

    // ---------------------------------------------------------------- kills

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer victim)) return;
        ServerPlayer killer = responsiblePlayer(event.getSource());
        if (killer == null || killer == victim || !Config.b(Config.PVP_REWARDS)) return;
        NinjaData kd = NinjaData.get(killer);
        NinjaData vd = NinjaData.get(victim);
        if (kd == null || vd == null) return;
        String victimName = victim.getGameProfile().getName();

        if (levelGapTooBig(kd.getLevel(), vd.getLevel())) {
            String key = kd.getLevel() > vd.getLevel() ? "message.shinobiarts.pvp_too_weak" : "message.shinobiarts.pvp_too_strong";
            killer.displayClientMessage(Component.translatable(key, victimName).withStyle(ChatFormatting.GRAY), false);
            return;
        }
        String pair = killer.getUUID() + ">" + victim.getUUID();
        long now = System.currentTimeMillis();
        Long last = lastRewardedKill.get(pair);
        if (last != null && now - last < Config.i(Config.PVP_SAME_VICTIM_COOLDOWN) * 60_000L) {
            killer.displayClientMessage(Component.translatable("message.shinobiarts.pvp_recent", victimName).withStyle(ChatFormatting.GRAY), false);
            return;
        }
        if (Config.b(Config.PVP_REQUIRE_ACTIVITY) && !wasActive(victim)) {
            killer.displayClientMessage(Component.translatable("message.shinobiarts.pvp_inactive", victimName).withStyle(ChatFormatting.GRAY), false);
            return;
        }

        // Beating a stronger ninja is worth more; beating a weaker one (within the allowed gap) less.
        double ratio = Math.max(0.5, Math.min(2.0, vd.getLevel() / (double) Math.max(1, kd.getLevel())));
        long xp = Math.round((Config.i(Config.PVP_KILL_XP_BASE) + (long) Config.i(Config.PVP_KILL_XP_PER_LEVEL) * vd.getLevel()) * ratio);
        long ryo = Config.i(Config.PVP_KILL_RYO_BASE) + (long) Config.i(Config.PVP_KILL_RYO_PER_LEVEL) * vd.getLevel();
        // the villages are at war: a kill counts for more
        if (com.shinobiarts.village.Diplomacy.get(killer.server).atWar(kd.getVillage(), vd.getVillage())) {
            double war = Config.d(Config.WAR_KILL_MULTIPLIER);
            xp = Math.round(xp * war);
            ryo = Math.round(ryo * war);
            killer.sendSystemMessage(Component.translatable("message.shinobiarts.war_kill").withStyle(ChatFormatting.DARK_RED));
        }
        lastRewardedKill.put(pair, now);
        killer.sendSystemMessage(Component.translatable("message.shinobiarts.pvp_reward", victimName, xp,
                PlayerDataManager.formatRyo(ryo)).withStyle(ChatFormatting.GOLD));
        if (ryo > 0) PlayerDataManager.addRyo(killer, ryo);
        if (xp > 0) PlayerDataManager.addEarnedXp(killer, xp);
        // (taking eyes from a kill is gone: eyes are now taken with the Medical Ninjutsu "Eye Extraction")
        ShinobiRecords.rewardedKill(killer, victim);
        com.shinobiarts.quest.QuestEvents.onPlayerKill(killer);
    }
}
