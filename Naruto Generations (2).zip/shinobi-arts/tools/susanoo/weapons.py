"""
Each Mangekyou's own Susanoo, from the show: the hands (holding things) and the legendary weapons, built for stages
3-5 onto the shared body (stages.py). They go in their own small file per stage and design (weapons<n>_<design>.bin)
and are joined to the body in the game, so only what differs is stored.

  itachi   the Totsuka Sword (an ethereal blade pouring from a sake gourd) and the Yata Mirror
  sasuke   a katana and a great bow of chakra
  obito    a Kamui shuriken in each hand
  madara   twin katanas (Eternal Mangekyou); the Perfect Susanoo has a second face on the back of its head
"""
import math
import os

import numpy as np

from mesh import BLADE, Mesh, V, circle, lens, lerp, rot, superellipse, unit
from parts import ROUND, flame_rise, frame_matrix, grip_hand, katana

DESIGNS = ("itachi", "sasuke", "obito", "madara")

# (blade length, weapon scale) per stage, in the frame the hands are built in (the Perfect Susanoo's is scaled 0.75)
SIZES = {3: (86, 1.0), 4: (104, 1.0), 5: (175, 1.4)}

# where each hand's thumb (and so a held blade) points, per design: (right, left)
THUMBS = {
    "itachi": ((0.15, 0.85, 0.5), None),          # the gourd upright; the left hand is a fist behind the mirror
    "sasuke": ((0.15, 0.6, 0.8), (0.0, 1.0, 0.12)),  # the sword forward, the bow upright
    "obito": ((0.25, 0.7, 0.6), (-0.25, 0.7, 0.6)),
    "madara": ((0.25, 0.6, 0.75), (-0.25, 0.6, 0.75)),
}


def _fist_thumb(joint, side):
    """For a hand holding nothing (behind a mirror): knuckles forward, palm turned back toward the body."""
    sh, el, wr = joint
    f = unit(V(wr) - V(el))
    return np.cross(f, (0, 0, 1)) * (-side)


def totsuka(m, h, length, s):
    """The Totsuka Sword: a gourd held by its neck, and from its mouth a long, wavering blade of spirit."""
    G, ax, f = h["grip"], h["axis"], h["fwd"]
    bone = "hand_r"
    R = frame_matrix(f, ax, h["palm"])
    m.blob(bone, "armor", G - ax * 14 * s, (24 * s, 22 * s, 24 * s), R=R, e=(1, 1), seg=(18, 12))         # lower bulb
    m.sweep(bone, "armor", [G - ax * 5 * s, G + ax * 4 * s], (6 * s, 6 * s), n=3, profile=circle(10))       # neck (in the fist)
    m.blob(bone, "armor", G + ax * 9 * s, (14 * s, 12 * s, 14 * s), R=R, e=(1, 1), seg=(14, 8))            # upper bulb
    m.sweep(bone, "trim", [G + ax * 14 * s, G + ax * 17 * s], (6 * s, 6 * s), cap0="flat", cap1="flat", n=2,
            profile=circle(10))                                                                         # mouth
    m.sweep(bone, "trim", [G + ax * 1.5 * s, G + ax * 3 * s], (6.6 * s, 6.6 * s), cap0="flat", cap1="flat", n=2,
            profile=circle(10))                                                                         # cord at the neck
    base = G + ax * 17 * s
    side = np.cross(ax, f)
    pts = []
    for i in range(10):                                  # the blade, rippling a little as it rises
        t = i / 9
        pts.append(base + ax * length * t + side * math.sin(t * 7) * 2.2 * s * t + f * 0.08 * length * t * t)

    def size(t):
        w = 8 * s * (1 - 0.25 * t)
        if t > 0.88:
            w *= math.sqrt(max(0.0, 1 - (t - 0.88) / 0.12)) * 0.9 + 0.1
        return (w, 2.2 * s * (1 - 0.3 * t))
    m.sweep(bone, "weapon", pts, size, profile=BLADE, hint=f, cap0="flat", cap1="point", n=4, uv_len=length)
    for k in range(5):                                   # spirit flames streaming off it
        t = 0.15 + k * 0.17
        at = lerp(pts[0], pts[-1], t) + side * ((-1) ** k) * 3 * s
        flame_rise(m, bone, at, 14 * s, 6 * s, (float(side[0]) * (-1) ** k * 0.5, float(side[2]) * (-1) ** k * 0.5))


def yata_mirror(m, h, s):
    """The Yata Mirror: a great convex eight-sided mirror on the left arm, rimmed, with three magatama on its face."""
    bone = "hand_l"
    G, f = h["grip"], h["fwd"]
    out = unit(V(f[0] * 0.3 + 0.32, 0, 1))              # it faces forward, turned a little outward
    up = unit(np.cross(out, np.cross((0, 1, 0), out)))
    right = np.cross(up, out)
    c = G + out * 9 * s + up * 4 * s
    R = frame_matrix(right, up, out)
    r = 30 * s
    m.blob(bone, "armor", c, (r * 2, r * 2, 8 * s), R=R, e=(0.95, 1.0), seg=(28, 12))                       # the mirror
    ring = [c + right * r * math.cos(math.radians(22.5 + 45 * k)) + up * r * math.sin(math.radians(22.5 + 45 * k)) + out * 1.2 * s
            for k in range(9)]
    m.sweep(bone, "trim", ring, (4 * s, 4 * s), cap0=None, cap1=None, n=2, profile=superellipse(10, 4), resample=False)  # octagon rim
    inner = [c + right * r * 0.55 * math.cos(math.radians(a)) + up * r * 0.55 * math.sin(math.radians(a)) + out * 3.2 * s
             for a in range(0, 361, 30)]
    m.sweep(bone, "trim", inner, (1.6 * s, 1.6 * s), cap0=None, cap1=None, n=2, profile=circle(8))
    for k in range(3):                                   # three magatama
        a = math.radians(90 + 120 * k)
        head = c + (right * math.cos(a) + up * math.sin(a)) * r * 0.32 + out * 3.6 * s
        tail = head + (right * math.cos(a + 1.9) + up * math.sin(a + 1.9)) * r * 0.2
        m.blob(bone, "gem", head, (6 * s, 6 * s, 2.4 * s), R=R, e=(1, 1), seg=(10, 6))
        m.sweep(bone, "gem", [head, lerp(head, tail, 0.5) + out * 0.3 * s, tail], lambda t: (5 * s * (1 - t) + 0.6, 2 * s), hint=out,
                cap1="point", n=3, profile=circle(8))
    m.blob(bone, "trim", c + out * 3.4 * s, (7 * s, 7 * s, 3 * s), R=R, e=(1, 1), seg=(12, 6))              # boss


def great_bow(m, h, length, s):
    """Sasuke's bow of chakra: long limbs bending back toward him and flicking forward at the tips, and its string."""
    bone = "hand_l"
    G, ax = h["grip"], h["axis"]
    fwd = unit(V(0, 0, 1) - ax * float(np.dot((0, 0, 1), ax)))
    L = length * 0.62
    B = L * 0.32
    pts = []
    for i in range(21):
        t = -1 + i / 10
        tip = max(0.0, abs(t) - 0.82) / 0.18
        pts.append(G + ax * (t * L) - fwd * (B * t * t) + fwd * (B * 0.55 * tip * tip))
    m.sweep(bone, "weapon", pts, lambda t: (3.2 * s, (6.5 - 4.5 * abs(2 * t - 1) ** 1.4) * s), hint=fwd, cap0="point", cap1="point",
            n=3, profile=superellipse(12, 3), uv_len=L)
    m.sweep(bone, "trim", [G - ax * 6 * s, G + ax * 6 * s], (7.5 * s, 7.5 * s), cap0="flat", cap1="flat", n=2, profile=circle(10))  # grip wrap
    m.sweep(bone, "weapon", [pts[0], pts[-1]], (1.0 * s, 1.0 * s), n=2, profile=circle(6), cap0="flat", cap1="flat")             # string


SHURIKEN_ART = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "source_art", "kamui_shuriken.png")
_MASK = None


def _shuriken_mask(res=56):
    """The Kamui shuriken's silhouette from the user's picture (solid where it's dark), res x res cells."""
    global _MASK
    if _MASK is None:
        from PIL import Image
        img = Image.open(SHURIKEN_ART).convert("RGBA").resize((res, res), Image.LANCZOS)
        _MASK = np.asarray(img)[..., 3] > 110
    return _MASK


def kamui_shuriken(m, h, bone, radius, s):
    """
    A Kamui shuriken exactly like the picture: its silhouette (three broad curved blades round a hub with a hole) cut
    out as a flat black plate, held in the fist by one blade.
    """
    G = h["grip"]
    mask = _shuriken_mask()
    res = mask.shape[0]
    n = unit(V(0, 0.25, 1))                                 # held up facing forward, so its shape shows
    v = unit(np.cross(n, np.cross((0, 1, 0), n)))          # picture "up"
    u = np.cross(n, v)                                     # picture "right" (as seen from the front: -X)
    out = 1 if G[0] > 0 else -1                            # out to the side of the hand holding it
    c = G + unit(u * out * -1 + v * 0.6) * radius * 0.6    # the fist holds it partway along a blade
    cell = 2 * radius / res
    half = 1.6 * s

    def P(i, j, side):                                     # corner (i, j) of the grid, front (+1) or back (-1)
        return c + u * ((j - res / 2) * cell) + v * ((res / 2 - i) * cell) + n * (side * half)

    def plate(quads):
        verts, faces, uvs = [], [], []
        for a, b, cc, d in quads:
            k = len(verts)
            verts.extend([a, b, cc, d])
            uvs.extend([(0, 0), (1, 0), (1, 1), (0, 1)])
            faces.extend([(k, k + 1, k + 2), (k, k + 2, k + 3)])
        m.add(bone, "shadow", verts, faces, uvs)

    faces_q, sides_q = [], []
    for i in range(res):                                   # the two faces: one long quad per run of solid cells
        j = 0
        while j < res:
            if not mask[i, j]:
                j += 1
                continue
            k = j
            while k < res and mask[i, k]:
                k += 1
            faces_q.append((P(i, j, 1), P(i + 1, j, 1), P(i + 1, k, 1), P(i, k, 1)))
            faces_q.append((P(i, j, -1), P(i, k, -1), P(i + 1, k, -1), P(i + 1, j, -1)))
            j = k
    for i in range(res):                                   # the edge walls round the outline
        for j in range(res):
            if not mask[i, j]:
                continue
            if i == 0 or not mask[i - 1, j]:
                sides_q.append((P(i, j, -1), P(i, j, 1), P(i, j + 1, 1), P(i, j + 1, -1)))
            if i == res - 1 or not mask[i + 1, j]:
                sides_q.append((P(i + 1, j, -1), P(i + 1, j + 1, -1), P(i + 1, j + 1, 1), P(i + 1, j, 1)))
            if j == 0 or not mask[i, j - 1]:
                sides_q.append((P(i, j, -1), P(i + 1, j, -1), P(i + 1, j, 1), P(i, j, 1)))
            if j == res - 1 or not mask[i, j + 1]:
                sides_q.append((P(i, j + 1, -1), P(i, j + 1, 1), P(i + 1, j + 1, 1), P(i + 1, j + 1, -1)))
    plate(faces_q)
    plate(sides_q)


def back_face(m, head_mesh_pieces, centre_z):
    """Madara's Perfect Susanoo: a second face on the back of its head (the face mirrored front to back)."""
    for pc in head_mesh_pieces:
        if pc["mat"] == "flame":
            continue
        V2 = pc["V"].copy()
        V2[:, 2] = 2 * centre_z - V2[:, 2]
        m.pieces.append({"bone": pc["bone"], "mat": pc["mat"], "V": V2, "F": pc["F"][:, [0, 2, 1]].copy(), "UV": pc["UV"].copy()})


def build(stage, design, joints, head):
    """The design's pieces for one stage, in the hands' building frame (a temporary mesh with the bones named)."""
    t = Mesh("weapons")
    for b in ("hand_r", "hand_l", "head", "fore_l"):
        t.bone(b)
    length, ws = SIZES[stage]
    hs = 1.6                                             # hand size (as the body's)
    right, left = THUMBS[design]
    hr = grip_hand(t, "hand_r", joints["r"][1], joints["r"][2], hs, -1, right)
    if design == "itachi":
        hl = grip_hand(t, "hand_l", joints["l"][1], joints["l"][2], hs, 1, _fist_thumb(joints["l"], 1))
        totsuka(t, hr, length * 1.05, ws)
        yata_mirror(t, hl, ws * (1.15 if stage < 5 else 1.35))
    elif design == "sasuke":
        hl = grip_hand(t, "hand_l", joints["l"][1], joints["l"][2], hs, 1, left)
        katana(t, "hand_r", hr["grip"] + hr["axis"] * 2 * ws, hr["axis"], length, ws, curve=0.05, flat=hr["fwd"])
        great_bow(t, hl, length * 1.6, ws)
    elif design == "obito":
        hl = grip_hand(t, "hand_l", joints["l"][1], joints["l"][2], hs, 1, left)
        kamui_shuriken(t, hr, "hand_r", length * 0.22, ws)
        kamui_shuriken(t, hl, "hand_l", length * 0.22, ws)
    else:                                                # madara: twin swords
        hl = grip_hand(t, "hand_l", joints["l"][1], joints["l"][2], hs, 1, left)
        katana(t, "hand_r", hr["grip"] + hr["axis"] * 2 * ws, hr["axis"], length, ws, curve=0.06, flat=hr["fwd"])
        katana(t, "hand_l", hl["grip"] + hl["axis"] * 2 * ws, hl["axis"], length, ws, curve=0.06, flat=hl["fwd"])
        if stage == 5 and head is not None:
            from stages import humanoid_head
            hm = Mesh("face")
            hm.bone("head")
            humanoid_head(hm, "head", head, 1.0)
            back_face(t, hm.pieces, head[2] - 9.5)   # out past the helmet's neck guard
    return t
