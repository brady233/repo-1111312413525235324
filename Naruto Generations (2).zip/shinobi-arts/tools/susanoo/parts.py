"""Smooth body parts shared by the five Susanoo stages (same layout as the cube version; see mesh.py)."""
import math

import numpy as np

from mesh import BLADE, V, circle, lens, lerp, rot, superellipse, unit

ROUND = (0.75, 0.85)     # blob exponents: soft, a little fuller than an ellipsoid
SOFTBOX = (0.5, 0.6)     # rounded box


def arc(center, rx, rz, y0, y1, a0, a1, n, droop=0.0):
    """Points on an elliptical arc in a horizontal-ish plane (angles in degrees, 0 = +Z front, 90 = +X)."""
    pts = []
    for i in range(n + 1):
        t = i / n
        a = math.radians(a0 + (a1 - a0) * t)
        y = y0 + (y1 - y0) * t - droop * math.sin(math.pi * t)
        pts.append((center[0] + math.sin(a) * rx, y, center[2] + math.cos(a) * rz))
    return pts


def facing(d, up=(0, 1, 0)):
    """Rotation matrix that turns local +Z onto d (local +Y as close to up as possible)."""
    z = unit(d)
    x = np.cross(up, z)
    if np.linalg.norm(x) < 1e-6:
        x = np.cross((1, 0, 0), z)
    x = unit(x)
    y = np.cross(z, x)
    return np.column_stack([x, y, z])


# ---------------------------------------------------------------- skeleton

def spine(m, bone, x, y0, y1, z, size, step, mat="bone"):
    """Stacked rounded vertebrae with spinous processes pointing back and down, transverse processes to the sides."""
    y = y0
    i = 0
    while y < y1:
        s = size * (1.15 - 0.3 * (y - y0) / max(1, y1 - y0))
        c = V(x, y + s * 0.35, z)
        m.blob(bone, mat, c, (s * 1.05, s * 0.62, s * 0.95), e=(0.7, 0.8), seg=(12, 6))
        m.sweep(bone, mat, [c + V(0, 0, -s * 0.2), c + V(0, -s * 0.15, -s * 0.75), c + V(0, -s * 0.45, -s * 1.15)],
                lambda t, s=s: (s * 0.42 * (1 - 0.6 * t), s * 0.5 * (1 - 0.5 * t)), cap1="round", n=3, profile=circle(8))
        if i % 2 == 0:
            m.sweep(bone, mat, [c + V(-s * 0.85, 0.1 * s, -s * 0.15), c + V(0, 0, -s * 0.1), c + V(s * 0.85, 0.1 * s, -s * 0.15)],
                    lambda t, s=s: (s * 0.28 * (1 - 0.35 * abs(t - 0.5) * 2), s * 0.28), n=3, profile=circle(8))
        y += step
        i += 1


def ribcage(m, bone, center, ys, rxs, rzs, spine_z, thick=(3, 2), droop=6, open_front=20, mat="bone", floating=2, segs=9):
    """Pairs of curved, flattened ribs from the spine around to the front, thinning as they go."""
    n = len(ys)
    for sx in (-1, 1):
        for i, (y, rx, rz) in enumerate(zip(ys, rxs, rzs)):
            end = 180 + 180 - open_front if i < n - floating else 180 + 110 + i * 3
            pts = [(-3, y + 1, spine_z)] + arc((center[0], 0, center[2]), rx, rz, y, y - droop, 205, end, segs)[1:]
            if sx > 0:
                pts = [(-p[0], p[1], p[2]) for p in pts]
            m.sweep(bone, mat, pts, lambda t: (thick[0] * (1.2 - 0.5 * t), thick[1] * (1.15 - 0.4 * t)),
                    hint=(0, 1, 0), n=2, profile=circle(8))


def bone_beam(m, bone, p0, p1, w, knob, mat="bone"):
    """A long bone: a shaft that thins in the middle, with rounded knuckle ends."""
    m.sweep(bone, mat, [p0, p1], lambda t: (w * (1 - 0.28 * math.sin(math.pi * t)),) * 2, n=10, profile=circle(10))
    m.blob(bone, mat, p0, (knob, knob * 0.9, knob), e=ROUND, seg=(14, 8))
    m.blob(bone, mat, p1, (knob * 0.95, knob * 0.85, knob * 0.95), e=ROUND, seg=(14, 8))


def finger(m, bone, pts, w, mat, tip=0.7):
    m.sweep(bone, mat, pts, lambda t: (w * (1 - (1 - tip) * t),) * 2, n=4, profile=circle(8))
    for p in pts[1:-1]:
        m.blob(bone, mat, p, (w * 1.15,) * 3, e=(1, 1), seg=(10, 6))


def skeletal_hand(m, bone, wrist, s, side, curl=25, mat="bone"):
    """Wrist bones, four bony fingers with knuckles, and a thumb. side: -1 right hand, +1 left."""
    wrist = V(wrist)
    m.blob(bone, mat, wrist, (5 * s, 3 * s, 4.5 * s), e=ROUND, seg=(12, 8))
    for f in range(4):
        x = wrist[0] + side * (-3 + f * 2.2) * s
        base = V(x, wrist[1] - 1 * s, wrist[2] + 2 * s)
        knuckle = V(x + side * (f - 1.5) * 0.6 * s, wrist[1] - 3 * s, wrist[2] + 8 * s)
        m.sweep(bone, mat, [base, knuckle], (1.5 * s, 1.5 * s), n=3, profile=circle(8))
        pts = [knuckle]
        ang = 0.0
        length = (4.0 - abs(f - 1.4) * 0.6) * s
        for j in range(3):
            ang += math.radians(curl)
            last = pts[-1]
            pts.append(last + V(0, -math.sin(ang) * length, math.cos(ang) * length))
            length *= 0.8
        finger(m, bone, pts, 1.45 * s, mat, tip=0.55)
    tb = wrist + V(side * 4 * s, 0, 1 * s)
    finger(m, bone, [tb, tb + V(side * 3 * s, -2 * s, 4 * s), tb + V(side * 3 * s, -4 * s, 7 * s)], 1.6 * s, mat, tip=0.55)


def skull(m, bone, jaw_bone, c, s, eye="eye", mat="bone"):
    """A skull centred at c (s = size, 1 ~ 22 px wide): round cranium, deep dark sockets with glowing eyes,
    cheekbones, nose hole, teeth and a separate jaw (jaw_bone, so animations can open it)."""
    x, y, z = c
    C = V(c)
    m.blob(bone, mat, C + V(0, 5 * s, -3 * s), (22.5 * s, 21 * s, 27 * s), e=(0.85, 0.9), seg=(24, 14))     # cranium
    m.blob(bone, mat, C + V(0, -4 * s, 5 * s), (19 * s, 15 * s, 13 * s), e=(0.75, 0.8), seg=(20, 12))      # face
    m.sweep(bone, mat, [C + V(-10.5 * s, -0.5 * s, 5.5 * s), C + V(-5 * s, 0.2 * s, 10.2 * s), C + V(0, -0.6 * s, 10.6 * s),
                        C + V(5 * s, 0.2 * s, 10.2 * s), C + V(10.5 * s, -0.5 * s, 5.5 * s)],
            (3.4 * s, 2.6 * s), hint=(0, 1, 0), n=4, profile=circle(10))                                     # brow ridge
    for sx in (-1, 1):
        m.blob(bone, "shadow", C + V(sx * 5.2 * s, -5.6 * s, 9.6 * s), (7.4 * s, 6.6 * s, 4.2 * s), e=(0.9, 0.9), seg=(14, 8))
        m.blob(bone, eye, C + V(sx * 5.2 * s, -5.8 * s, 11.5 * s), (3.2 * s, 1.9 * s, 1.2 * s),
               R=rot(0, 0, -sx * 10), e=(1, 1), seg=(12, 6))                                                   # eye glow
        m.sweep(bone, mat, [C + V(sx * 2.5 * s, -9.6 * s, 10.6 * s), C + V(sx * 8.5 * s, -9.2 * s, 9.2 * s),
                            C + V(sx * 11 * s, -7 * s, 3 * s), C + V(sx * 10.6 * s, -4 * s, -3.5 * s)],
                (3.2 * s, 2.8 * s), n=4, profile=circle(10))                                                   # cheekbone
    m.blob(bone, "shadow", C + V(0, -10.6 * s, 10.4 * s), (3.4 * s, 4.4 * s, 2.2 * s), e=(1.2, 1), seg=(10, 6))   # nose hole
    m.blob(bone, mat, C + V(0, -13.2 * s, 6.5 * s), (14 * s, 5 * s, 10 * s), e=SOFTBOX, seg=(18, 8))              # upper jaw
    for t in range(-3, 4):
        a = math.radians(t * 15)
        m.blob(bone, mat, C + V(math.sin(a) * 7 * s, -16 * s, 4.5 * s + math.cos(a) * 5.4 * s), (1.6 * s, 2.8 * s, 1.4 * s),
               e=(0.7, 0.8), seg=(8, 6))                                                                         # upper teeth
        m.blob(jaw_bone, mat, C + V(math.sin(a) * 6.6 * s, -18.4 * s, 4 * s + math.cos(a) * 5 * s), (1.5 * s, 2.4 * s, 1.3 * s),
               e=(0.7, 0.8), seg=(8, 6))                                                                         # lower teeth
    jaw = [C + V(-9 * s, -11 * s, -3.5 * s), C + V(-8.5 * s, -18.5 * s, 1 * s), C + V(-4.5 * s, -20.3 * s, 7.5 * s),
           C + V(0, -20.8 * s, 9 * s), C + V(4.5 * s, -20.3 * s, 7.5 * s), C + V(8.5 * s, -18.5 * s, 1 * s),
           C + V(9 * s, -11 * s, -3.5 * s)]
    m.sweep(jaw_bone, mat, jaw, lambda t: (3.4 * s * (1 + 0.25 * math.sin(math.pi * t)),) * 2, n=4, profile=circle(10))  # jaw


# ---------------------------------------------------------------- chakra flames

def flame_tongue(m, bone, top, height, width, flare, lean, mat="flame", curl=0.35):
    """A tongue of chakra flame hanging down from top: wide at the top, pinching to a point that curls outward."""
    top = V(top)
    lx, lz = lean
    pts = []
    for i in range(7):
        t = i / 6
        out = flare * t * t + curl * width * math.sin(t * math.pi * 0.9)
        pts.append(top + V(lx * out, -height * t, lz * out))
    tang = (lz, 0, -lx) if (lx or lz) else (1, 0, 0)
    m.sweep(bone, mat, pts, lambda t: (width * ((1 - t) ** 0.8 * 0.95 + 0.05), width * 0.6 * ((1 - t) ** 0.8 * 0.95 + 0.05)),
            profile=lens(10, 1.3), hint=tang, cap1="point", n=4, twist=35)


def flame_rise(m, bone, base, height, width, lean, mat="flame"):
    """A flame licking upward from base: a broad, twisting tongue that sways and curls to a point, with a smaller
    tongue beside it."""
    base = V(base)
    lx, lz = lean
    tang = V(lz, 0, -lx) if (lx or lz) else V(1, 0, 0)
    for k, (h, w, off, phase) in enumerate(((height, width * 1.35, 0.0, 0.0), (height * 0.62, width * 0.8, 0.55, 1.3))):
        b = base + tang * off * width
        pts = []
        for i in range(7):
            t = i / 6
            sway = math.sin(t * math.pi * 1.6 + phase) * width * 0.45 * t
            side = math.sin(t * math.pi * 1.1 + phase) * width * 0.25 * t
            pts.append(b + V(lx * sway, h * t, lz * sway) + tang * side)
        m.sweep(bone, mat, pts, lambda t, w=w: (w * (1 - t) ** 1.1 * (1 + 0.25 * math.sin(t * 9)) + 0.3,
                                                w * 0.45 * (1 - t) ** 1.1 + 0.25),
                profile=lens(10, 1.6), hint=tang, cap0="round", cap1="point", n=4, twist=-110 + 60 * k)


def flame_skirt(m, bone, y_top, radius, count, height, width, mat="flame"):
    for i in range(count):
        a = math.radians(i * 360 / count + 7)
        top = (math.sin(a) * radius, y_top, math.cos(a) * radius - 4)
        length = height * (0.72 + 0.28 * (((i * 37) % 11) / 10))
        flame_tongue(m, bone, top, length, width * (0.85 + 0.3 * ((i * 5) % 3) / 2), radius * 0.3, (math.sin(a), math.cos(a)), mat, curl=0.2)


# ---------------------------------------------------------------- flesh

def finger_hand(m, bone, wrist, s, side, curl=35, mat="muscle", grip=False):
    """A fleshy hand: rounded palm, four jointed fingers and a thumb. grip: fingers curl round a handle."""
    wrist = V(wrist)
    m.blob(bone, mat, wrist + V(0, -4 * s, 3 * s), (9.5 * s, 8.5 * s, 5.5 * s), e=(0.6, 0.75), seg=(16, 10))
    for f in range(4):
        x = wrist[0] + side * (-3.3 + f * 2.2) * s
        base = V(x, wrist[1] - 8 * s, wrist[2] + 4 * s)
        pts = [base]
        ang = math.radians(10)
        length = (3.6 - abs(f - 1.3) * 0.5) * s
        for j in range(3):
            ang += math.radians(curl if not grip else 55)
            last = pts[-1]
            pts.append(last + V(0, -math.cos(ang) * length, math.sin(ang) * length))
        m.sweep(bone, mat, pts, lambda t: (2.2 * s * (1 - 0.2 * t),) * 2, n=4, profile=circle(8))
    tb = wrist + V(side * 4.5 * s, -3 * s, 4 * s)
    m.sweep(bone, mat, [tb, tb + V(side * 1.5 * s, -3 * s, 3 * s), tb + V(side * 0.5 * s, -5 * s, 5 * s)],
            lambda t: (2.6 * s * (1 - 0.2 * t),) * 2, n=4, profile=circle(8))


def limb(m, bone, p0, p1, w0, w1, bulge=0.0, bulge_at=0.4, mat="muscle", n=10):
    """A muscular limb segment from p0 to p1, w0 -> w1 wide with a swell (bulge, as a share) around bulge_at."""
    def size(t):
        w = w0 + (w1 - w0) * t
        w *= 1 + bulge * math.exp(-((t - bulge_at) / 0.28) ** 2)
        return (w, w * 0.95)
    m.sweep(bone, mat, [p0, p1], size, n=n, profile=circle(14))


def katana(m, bone, grip, direction, length, s, mat="weapon", curve=0.0, flat=None):
    """A sword whose handle is at grip, blade pointing along direction, with a round guard and a curved blade."""
    d = unit(direction)
    grip = V(grip)
    back = grip - d * 9 * s
    guard = grip + d * 5 * s
    m.sweep(bone, "trim", [back, guard], (3.4 * s, 3.4 * s), n=4, profile=circle(10))                     # hilt
    m.blob(bone, "trim", back - d * 0.6 * s, (4.2 * s, 4.2 * s, 2.2 * s), R=facing(d), e=(0.8, 0.9), seg=(12, 6))   # pommel
    m.blob(bone, "trim", guard, (12 * s, 12 * s, 2.2 * s), R=facing(d), e=(0.45, 1.0), seg=(20, 6))      # tsuba
    total = length + 11 * s
    pts = []
    for i in range(9):
        t = i / 8
        p = guard + d * total * t
        pts.append(p + V(0, curve * total * t * t, 0))
    hint = flat if flat is not None else (0, -1, 0)

    def size(t):
        w = 7.0 * s * (1 - 0.15 * t)
        if t > 0.9:                                   # the point
            w *= math.sqrt(max(0.0, 1 - (t - 0.9) / 0.1)) * 0.9 + 0.1
        return (w, 2.0 * s * (1 - 0.3 * t))
    m.sweep(bone, mat, pts, size, profile=BLADE, hint=hint, cap0="flat", cap1="point", n=4, uv_len=total)


def dome_plate(m, bone, mat, center, size, R, e=(0.7, 0.85)):
    """A curved armour plate: the top of a flattened ellipsoid, closed underneath."""
    m.blob(bone, mat, center, size, R=R, e=e, v_range=(5, 90), seg=(20, 7))


def band(m, bone, mat, pts, height, thick, hint=(0, 1, 0), cap="round"):
    """An armour band (a rounded-rectangle bar) along a curve."""
    m.sweep(bone, mat, pts, (height, thick), profile=superellipse(12, 5), hint=hint, cap0=cap, cap1=cap, n=2)


def plate(m, bone, mat, center, size, R=None, e=(0.35, 0.55)):
    """A thick armour plate with soft rounded edges."""
    m.blob(bone, mat, center, size, R=R, e=e, seg=(16, 10))


def wing(m, bone, root, side, s, feathers=12):
    """A great wing of chakra feathers: a tapering arm bone sweeping up and out, two layers of long blade-feathers."""
    root = V(root)
    p1 = root + V(side * 24 * s, 18 * s, -12 * s)
    p2 = root + V(side * 56 * s, 30 * s, -22 * s)
    p3 = root + V(side * 88 * s, 20 * s, -28 * s)
    m.sweep(bone, "wing", [root, p1, p2, p3], lambda t: (7 * s * (1 - 0.55 * t), 6 * s * (1 - 0.5 * t)), n=6, profile=circle(10))
    m.blob(bone, "trim", root, (11 * s, 11 * s, 11 * s), e=ROUND, seg=(14, 8))
    m.blob(bone, "wing", p2, (7 * s, 7 * s, 7 * s), e=ROUND, seg=(12, 8))

    def along(t):
        return lerp(p1, p2, t * 2) if t < 0.5 else lerp(p2, p3, (t - 0.5) * 2)

    for layer, (count, length0, width, back) in enumerate(((feathers, 1.0, 11, 0), (feathers - 3, 0.62, 10, 4))):
        for i in range(count):
            t = i / (count - 1)
            a = along(t * (0.95 if layer == 0 else 0.85))
            length = (36 + 46 * math.sin(math.pi * (0.2 + 0.8 * t))) * s * length0
            spread = math.radians(12 + 78 * t)
            tip = a + V(side * length * math.sin(spread), -length * math.cos(spread), -(6 + 10 * t + back) * s)
            mid = lerp(a, tip, 0.5) + V(0, 3 * s, -2 * s)
            m.sweep(bone, "wing", [a, mid, tip],
                    lambda u, w=width: (w * s * (0.45 + 0.75 * math.sin(math.pi * (0.12 + 0.6 * u))) * (1 - u ** 4) + 0.3, 1.5 * s * (1 - 0.5 * u)),
                    profile=lens(8, 2.0), hint=(side, 0.15, 0), cap0="round", cap1="point", n=6)
    for i in range(7):                                   # covert feathers along the top edge
        t = (i + 0.5) / 7
        a = lerp(root, p2, t / 0.7) if t < 0.7 else lerp(p2, p3, (t - 0.7) / 0.3)
        tip = a + V(side * 12 * s, -20 * s, 1 * s)
        m.sweep(bone, "wing", [a, lerp(a, tip, 0.5) + V(side * 1 * s, 1 * s, 0), tip],
                lambda u: (9 * s * (0.6 + 0.4 * math.sin(math.pi * (0.2 + 0.6 * u))) * (1 - u ** 4) + 0.3, 1.6 * s),
                profile=lens(8, 2.0), hint=(side, 0, 0), cap0="round", cap1="point", n=5)


# ---------------------------------------------------------------- hands that follow the forearm and hold things

def hand_frame(el, wr, thumb, side):
    """The hand's axes at the wrist: f along the forearm (where the fingers point), l toward the thumb (a held
    handle's axis: a blade comes out on this side), p out of the palm. side: -1 right hand, +1 left."""
    f = unit(V(wr) - V(el))
    t = V(thumb)
    l = t - f * float(np.dot(t, f))
    if np.linalg.norm(l) < 1e-6:
        l = np.cross(f, (0, 0, 1))
    l = unit(l)
    p = unit(-side * np.cross(l, f))
    return f, l, p


def frame_matrix(a, b, c):
    """Rotation whose local x, y, z axes are a, b, c."""
    return np.column_stack([unit(a), unit(b), unit(c)])


def grip_hand(m, bone, el, wr, s, side, thumb, mat="muscle", closed=True, curl=None):
    """
    A fleshy hand at the end of the forearm, its fingers wrapped round a handle (closed) or loosely curled. Returns
    the centre of the fist's grip and the handle's axis (pointing out on the thumb side), so a weapon can be put
    exactly in it.
    """
    wr = V(wr)
    f, l, p = hand_frame(el, wr, thumb, side)
    R = frame_matrix(l, f, p)
    m.blob(bone, mat, wr + f * 4.6 * s + p * 0.4 * s, (10 * s, 9.5 * s, 5.8 * s), R=R, e=(0.6, 0.75), seg=(16, 10))   # palm
    bend = math.radians(curl if curl is not None else (68 if closed else 28))
    for k in range(4):
        across = (3.4 - k * 2.25) * s                            # index finger nearest the thumb
        base = wr + f * 8.6 * s + l * across + p * 0.6 * s
        pts = [base]
        ang = 0.0
        length = (3.7 - abs(k - 1.3) * 0.5) * s
        for j in range(3):
            ang += bend
            pts.append(pts[-1] + (f * math.cos(ang) + p * math.sin(ang)) * length)
            length *= 0.88
        m.sweep(bone, mat, pts, lambda t: (2.3 * s * (1 - 0.2 * t),) * 2, n=4, profile=circle(8))
    tb = wr + f * 3.4 * s + l * 4.6 * s + p * 1.6 * s                 # the thumb, closing over the fingers
    if closed:
        tpts = [tb, tb + f * 2.8 * s + p * 2.8 * s + l * 0.6 * s, tb + f * 5.2 * s + p * 4.4 * s - l * 1.2 * s]
    else:
        tpts = [tb, tb + f * 2.6 * s + p * 1.6 * s + l * 1.6 * s, tb + f * 4.8 * s + p * 2.4 * s + l * 2.0 * s]
    m.sweep(bone, mat, tpts, lambda t: (2.7 * s * (1 - 0.2 * t),) * 2, n=4, profile=circle(8))
    grip = wr + f * 9.0 * s + p * 3.3 * s
    return {"grip": grip, "axis": l, "fwd": f, "palm": p, "wrist": wr}


def claw_hand(m, bone, el, wr, s, side, curl=26, mat="bone"):
    """A skeletal hand pointing on along the forearm: wrist bones, four bony fingers curled into a claw, a thumb."""
    wr = V(wr)
    down = V(0, -1, 0)
    f, l, p = hand_frame(el, wr, V(-side, 0, 0) + down * 0.2, side)   # palm turned in toward the body
    m.blob(bone, mat, wr, (5 * s, 4.5 * s, 3 * s), R=frame_matrix(l, f, p), e=ROUND, seg=(12, 8))
    for k in range(4):
        across = (3 - k * 2.2) * s
        base = wr + f * 1 * s + l * across
        knuckle = wr + f * 8 * s + l * (across * 1.15)
        m.sweep(bone, mat, [base, knuckle], (1.5 * s, 1.5 * s), n=3, profile=circle(8))
        pts = [knuckle]
        ang = 0.0
        length = (4.0 - abs(k - 1.4) * 0.6) * s
        for j in range(3):
            ang += math.radians(curl)
            pts.append(pts[-1] + (f * math.cos(ang) + p * math.sin(ang)) * length)
            length *= 0.8
        finger(m, bone, pts, 1.45 * s, mat, tip=0.55)
    tb = wr + l * 4 * s + f * 1 * s
    finger(m, bone, [tb, tb + l * 2.5 * s + f * 3 * s + p * 1.5 * s, tb + l * 2.5 * s + f * 6 * s + p * 3 * s], 1.6 * s, mat, tip=0.55)
