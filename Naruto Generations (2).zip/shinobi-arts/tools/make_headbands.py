"""
Draws the forehead protector art:
  textures/entity/headband/band.png              the cloth (white; dyed in game like leather armor)
  textures/entity/headband/plate_<name>.png      the metal plates from Calfan's "Naruto Headbands" model, unchanged:
                                                 leaf, sand, mist, cloud, rain, sound, shinobi (忍) and rogue (the
                                                 scratched leaf). Each is rendered from the model's own geometry
                                                 (tools/source_art/headbands/*.png: the plates' height maps) with plain
                                                 metal lighting. A resource pack can add plate_<village id>.png.
  textures/models/armor/empty.png                a transparent armor texture (the band is drawn by its own layer)
  textures/item/forehead_protector_band.png      the inventory icon's band (layer 0, dyed)
  textures/item/forehead_protector_plate_<v>.png the icon's plate (layer 1)
The height maps are 16-bit PNGs at 12 pixels per model unit: 0 = outside the plate, otherwise
height = value / 65534 * 8 - 4 model units above the plate's surface (the model's curve taken out: in game the plate
lies flat on the band). Run: python3 tools/make_headbands.py
"""
import os
import random

import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures")
HEIGHTS = os.path.join(HERE, "source_art", "headbands")
# texture name -> the model's plate
PLATES = {"leaf": "leaf", "sand": "sand", "mist": "mist", "cloud": "cloud", "rain": "rain", "sound": "sound",
          "shinobi": "shinobi", "rogue": "leaf_scratched"}
# inventory icons (item models): the five default villages, no village, never worn. Stone has no plate in the model,
# so it shows the 忍 plate, like any other village without its own plate.
ICONS = {"leaf": "leaf", "sand": "sand", "mist": "mist", "cloud": "cloud", "stone": "shinobi", "rogue": "rogue",
         "blank": "shinobi"}
PX = 12.0                 # height-map pixels per model unit
TEX_W, TEX_H = 512, 173   # each plate is 89 x 30 model units


def out(*parts):
    path = os.path.join(TEX, *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def load_height(name):
    raw = np.asarray(Image.open(os.path.join(HEIGHTS, name + ".png"))).astype(np.float64)
    inside = raw > 0
    return np.where(inside, (raw - 1) / 65534 * 8 - 4, 0.0), inside


def render_plate(name):
    """The plate as the model shows it: light grey metal lit from the upper left, so its engraving and rivets read."""
    h, inside = load_height(name)
    gy, gx = np.gradient(h * PX)
    nx, ny, nz = -gx, gy, np.ones_like(h)            # image rows run down, the model's y runs up
    n = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx / n, ny / n, nz / n
    L = np.array([-0.45, 0.6, 0.66]); L /= np.linalg.norm(L)
    Hv = L + np.array([0, 0, 1.0]); Hv /= np.linalg.norm(Hv)
    diffuse = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    spec = np.clip(nx * Hv[0] + ny * Hv[1] + nz * Hv[2], 0, 1) ** 30
    ao = 1 - 0.3 * np.clip(-h / 0.6, 0, 1)            # light falls less into the engraving
    base = np.array([176, 180, 188], dtype=np.float64)
    rgb = base * ((0.5 + 0.55 * diffuse) * ao)[..., None] + 170 * spec[..., None]
    rgba = np.concatenate([np.clip(rgb, 0, 255), inside[..., None] * 255.0], -1).astype(np.uint8)
    small = Image.fromarray(rgba, "RGBA").resize((TEX_W, TEX_H), Image.LANCZOS)
    small.putalpha(small.split()[3].point(lambda v: 255 if v > 110 else 0))
    return small


def band_texture():
    """White cloth with a faint weave (tinted in game)."""
    rnd = random.Random(3)
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            v = 236 + rnd.randint(-8, 6) - (10 if (x + y) % 4 == 0 else 0) - (14 if y in (0, 15) else 0)
            px[x, y] = (v, v, v, 255)
    return img


BAND_TOP, BAND_BOTTOM = 10.6, 20.4   # the icon's band, in 32-pixel icon units


def icon_band(size=32):
    """The icon's band (straight across, so the plate sits flat on it) and the knot's tails, light grey (dyed)."""
    S = 16
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dark, light = (150, 150, 156, 255), (236, 236, 240, 255)
    d.rectangle([0.5 * S, BAND_TOP * S, 31.5 * S, BAND_BOTTOM * S], fill=dark)
    d.rectangle([1.5 * S, (BAND_TOP + 1) * S, 30.5 * S, (BAND_BOTTOM - 1) * S], fill=light)
    for x0, sway in ((26.5, 1.5), (29, 3.0)):
        d.polygon([(x0 * S, BAND_BOTTOM * S), ((x0 + 2.4) * S, BAND_BOTTOM * S), ((x0 + 2.4 + sway * 0.6) * S, 31 * S), ((x0 + sway * 0.6) * S, 31.5 * S)], fill=dark)
        d.polygon([((x0 + 0.5) * S, (BAND_BOTTOM + 0.5) * S), ((x0 + 1.9) * S, (BAND_BOTTOM + 0.5) * S), ((x0 + 1.9 + sway * 0.6) * S, 30.5 * S), ((x0 + 0.5 + sway * 0.6) * S, 30.8 * S)], fill=light)
    o = img.resize((size, size), Image.LANCZOS)
    o.putalpha(o.split()[3].point(lambda v: 255 if v > 90 else 0))
    return o


def icon_plate(plate_img, size=32):
    """The plate centred on the icon's band, inside its top and bottom edges."""
    S = 16
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    h = (BAND_BOTTOM - BAND_TOP) - 1.6
    w = h * TEX_W / TEX_H
    p = plate_img.resize((int(w * S), int(h * S)), Image.LANCZOS)
    img.alpha_composite(p, (int((16 - w / 2) * S), int((BAND_TOP + 0.8) * S)))
    o = img.resize((size, size), Image.LANCZOS)
    o.putalpha(o.split()[3].point(lambda v: 255 if v > 90 else 0))
    return o


def main():
    folder = out("entity", "headband", "x")[:-1]
    for f in os.listdir(folder):                       # old plates (kanji, letters) no longer used
        if f.startswith("plate_") and f[6:-4] not in PLATES:
            os.remove(os.path.join(folder, f))
    band_texture().save(out("entity", "headband", "band.png"))
    plates = {name: render_plate(src) for name, src in PLATES.items()}
    for name, img in plates.items():
        img.save(out("entity", "headband", f"plate_{name}.png"))
    for icon, name in ICONS.items():
        icon_plate(plates[name]).save(out("item", f"forehead_protector_plate_{icon}.png"))
    icon_band().save(out("item", "forehead_protector_band.png"))
    Image.new("RGBA", (64, 32), (0, 0, 0, 0)).save(out("models", "armor", "empty.png"))
    print("forehead protector art written")


if __name__ == "__main__":
    main()
