import com.shinobiarts.world.realm.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

/** Ray-traced preview pictures of the Sage realms, built with the same RealmShape code the mod uses. */
public class RealmPreview {
    static int[] COL = new int[64];
    static {
        java.util.Arrays.fill(COL, 0xFF00FF);
        int[][] c = {
            {RealmShape.STONE, 0x7d7d7d}, {RealmShape.ANDESITE, 0x88898a}, {RealmShape.MOSSY_COBBLE, 0x6e7a5e}, {RealmShape.MOSSY_BRICKS, 0x737d64},
            {RealmShape.BRICKS, 0x7a797a}, {RealmShape.GRASS, 0x6a9e3c}, {RealmShape.DIRT, 0x866043}, {RealmShape.COARSE, 0x77553b}, {RealmShape.PODZOL, 0x5b3f1d},
            {RealmShape.MOSS, 0x596e2d}, {RealmShape.WATER, 0x3f76e4}, {RealmShape.SPRUCE_LOG, 0x3b2a17}, {RealmShape.SPRUCE_LEAVES, 0x3d5c3a},
            {RealmShape.DARK_LOG, 0x3c2e1a}, {RealmShape.DARK_LEAVES, 0x3f6a1f}, {RealmShape.RED_CLAY, 0x8f3d2e}, {RealmShape.RED, 0x8e2121},
            {RealmShape.WHITE, 0xcfd5d6}, {RealmShape.ROOF, 0x36363a}, {RealmShape.TRIM, 0x461a1c}, {RealmShape.PLANKS, 0x725435}, {RealmShape.BRIDGE, 0x653147},
            {RealmShape.LANTERN, 0xf3c96a}, {RealmShape.TOAD, 0x4d3324}, {RealmShape.TOAD_DARK, 0x985e43}, {RealmShape.TOAD_BELLY, 0xa25426},
            {RealmShape.BLACK, 0x080a0f}, {RealmShape.DEEPSLATE, 0x505053}, {RealmShape.COBBLED_DEEPSLATE, 0x4d4d51}, {RealmShape.TUFF, 0x6c6d66},
            {RealmShape.CALCITE, 0xdfe0dc}, {RealmShape.BONE, 0xd1cdb4}, {RealmShape.QUARTZ, 0xebe5de}, {RealmShape.SANDSTONE, 0xd8cb9a},
            {RealmShape.SEA_LANTERN, 0xb6d4cf}, {RealmShape.SHROOMLIGHT, 0xf09b4a}, {RealmShape.FERN, 0x5d8a3a}, {RealmShape.MOSS_CARPET, 0x596e2d},
            {RealmShape.GRAVEL, 0x837f7e}, {RealmShape.POLISHED, 0x848686}, {RealmShape.WINDOW, 0xf2c97a}, {RealmShape.STRIPPED, 0x735a37},
            {RealmShape.BLACKSTONE, 0x35303b}, {RealmShape.PALE, 0xd1b2a1}, {RealmShape.CYAN_CLAY, 0x565b5b}, {RealmShape.MUD_BRICKS, 0x89684f},
            {RealmShape.PACKED_MUD, 0x8e6b50}, {RealmShape.OAK_LEAVES, 0x4c7a2a}, {RealmShape.JUNGLE_LOG, 0x55441b}, {RealmShape.ROOTS, 0x4a3b27},
            {RealmShape.YELLOW_CLAY, 0xba8523}, {RealmShape.LIGHT_GRAY, 0x7d7d73}, {RealmShape.DRIPSTONE, 0x866b5c}, {RealmShape.SMOOTH_STONE, 0x9e9e9e},
        };
        for (int[] p : c) COL[p[0]] = p[1];
    }
    static boolean glow(int id) { return id == RealmShape.LANTERN || id == RealmShape.WINDOW || id == RealmShape.SEA_LANTERN || id == RealmShape.SHROOMLIGHT; }

    int W, H, X0, Z0, HY;
    byte[] vox;
    RealmShape shape;

    RealmPreview(RealmShape s, int cx0, int cz0, int n) {
        shape = s; HY = s.height; W = n * 16; H = n * 16; X0 = cx0 * 16; Z0 = cz0 * 16;
        vox = new byte[W * H * HY];
        RealmShape.Chunk ch = new RealmShape.Chunk(HY);
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
            s.fill(cx0 + i, cz0 + j, ch);
            for (int y = 0; y < HY; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                vox[idx(i * 16 + x, y, j * 16 + z)] = ch.blocks[((y << 4) | z) << 4 | x];
        }
    }
    byte[] lightMap;
    int lightAt(int wx, int y, int wz) {
        int x = wx - X0, z = wz - Z0;
        if (lightMap == null || x < 0 || z < 0 || x >= W || z >= H || y < 0 || y >= HY) return 0;
        return lightMap[idx(x, y, z)];
    }
    void computeLight() {
        lightMap = new byte[vox.length];
        int[] q = new int[vox.length]; int head = 0, tail = 0;
        for (int i = 0; i < vox.length; i++) { int id = vox[i] & 0xFF; if (glow(id) || id == RealmShape.LIGHT) { lightMap[i] = 15; q[tail++] = i; } }
        while (head < tail) {
            int i = q[head++]; int l = lightMap[i]; if (l <= 1) continue;
            int x = i % W, z = (i / W) % H, y = i / (W * H);
            int[][] nb = {{x+1,y,z},{x-1,y,z},{x,y+1,z},{x,y-1,z},{x,y,z+1},{x,y,z-1}};
            for (int[] n : nb) {
                if (n[0] < 0 || n[1] < 0 || n[2] < 0 || n[0] >= W || n[1] >= HY || n[2] >= H) continue;
                int j = idx(n[0], n[1], n[2]); int id = vox[j] & 0xFF;
                if (solid(id) && id != RealmShape.WATER && !(id == RealmShape.SPRUCE_LEAVES || id == RealmShape.DARK_LEAVES || id == RealmShape.OAK_LEAVES)) continue;
                if (lightMap[j] < l - 1) { lightMap[j] = (byte) (l - 1); if (tail < q.length) q[tail++] = j; }
            }
        }
    }
    int idx(int x, int y, int z) { return (y * H + z) * W + x; }
    int at(int wx, int y, int wz) {
        int x = wx - X0, z = wz - Z0;
        if (x < 0 || z < 0 || x >= W || z >= H || y < 0 || y >= HY) return -1;
        return vox[idx(x, y, z)] & 0xFF;
    }
    static boolean solid(int id) { return id > 0 && id != RealmShape.LIGHT && id != RealmShape.BARRIER; }

    // camera, lighting
    double[] sun = norm(new double[]{0.45, 0.8, 0.35});
    int sky0 = 0x87b6e8, sky1 = 0xd6e6f2, fogC = 0xc8d8e6; double fogDist = 260, ambient = 0.45; boolean shadows = true; double yClip = 9999;
    boolean dark = false;

    static double[] norm(double[] v) { double l = Math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]); return new double[]{v[0]/l, v[1]/l, v[2]/l}; }

    /** Casts a ray; returns {dist, id, face, hx, hy, hz} or null. face 0..5 = -x,+x,-y,+y,-z,+z. waterOut[0] = distance through water. */
    double[] cast(double ox, double oy, double oz, double dx, double dy, double dz, double max, double[] waterOut, boolean skipWater) {
        int x = (int) Math.floor(ox), y = (int) Math.floor(oy), z = (int) Math.floor(oz);
        int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        double tdx = Math.abs(1 / dx), tdy = Math.abs(1 / dy), tdz = Math.abs(1 / dz);
        double tx = (dx > 0 ? (x + 1 - ox) : (ox - x)) * tdx, ty = (dy > 0 ? (y + 1 - oy) : (oy - y)) * tdy, tz = (dz > 0 ? (z + 1 - oz) : (oz - z)) * tdz;
        double t = 0; int face = -1; double waterEnter = -1;
        while (t < max) {
            int id = y >= yClip ? 0 : at(x, y, z);
            if (id == -1 && (y < 0 || y >= HY)) { if ((dy > 0 && y >= HY) || (dy < 0 && y < 0)) break; }
            if (id > 0 && solid(id)) {
                if (id == RealmShape.WATER) {
                    if (skipWater) { if (waterEnter < 0) waterEnter = t; }
                    else return new double[]{t, id, face, x, y, z};
                } else {
                    if (waterOut != null && waterEnter >= 0) waterOut[0] = t - waterEnter;
                    return new double[]{t, id, face, x, y, z};
                }
            } else if (waterEnter >= 0 && waterOut != null) { waterOut[0] += t - waterEnter; waterEnter = -1; }
            if (tx < ty && tx < tz) { x += sx; t = tx; tx += tdx; face = sx > 0 ? 0 : 1; }
            else if (ty < tz) { y += sy; t = ty; ty += tdy; face = sy > 0 ? 2 : 3; }
            else { z += sz; t = tz; tz += tdz; face = sz > 0 ? 4 : 5; }
        }
        return null;
    }

    static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return r << 16 | g << 8 | bl;
    }
    static int scale(int c, double k) {
        int r = (int) Math.min(255, ((c >> 16) & 255) * k), g = (int) Math.min(255, ((c >> 8) & 255) * k), b = (int) Math.min(255, (c & 255) * k);
        return r << 16 | g << 8 | b;
    }
    static double hash3(int x, int y, int z) { return RealmNoise.hash(x * 31 + y * 7919, z * 17 - y * 131, 99); }

    int shade(double ox, double oy, double oz, double dx, double dy, double dz) {
        double[] wat = {0};
        double[] h = cast(ox, oy, oz, dx, dy, dz, 700, wat, true);
        int col;
        double dist;
        if (h == null) { col = mix(sky1, sky0, Math.max(0, dy) * 2.2); dist = 99999; }
        else {
            int id = (int) h[1], face = (int) h[2];
            dist = h[0];
            int bx = (int) h[3], by = (int) h[4], bz = (int) h[5];
            double hx = ox + dx * dist, hy = oy + dy * dist, hz = oz + dz * dist;
            // a little texture: per-block and per-texel variation
            int tu = (int) Math.floor((face < 2 ? hz : hx) * 8), tv = (int) Math.floor((face == 2 || face == 3 ? hz : hy) * 8);
            double var = 0.9 + 0.12 * hash3(bx, by, bz) + 0.1 * RealmNoise.hash(tu, tv, id);
            int base = scale(COL[id], var);
            if (glow(id)) col = scale(base, 1.25);
            else {
                double[] n = face == 0 ? new double[]{-1,0,0} : face == 1 ? new double[]{1,0,0} : face == 2 ? new double[]{0,-1,0} : face == 3 ? new double[]{0,1,0} : face == 4 ? new double[]{0,0,-1} : new double[]{0,0,1};
                double diff = Math.max(0, n[0]*sun[0]+n[1]*sun[1]+n[2]*sun[2]);
                if (diff > 0 && shadows) {
                    double[] s = cast(hx + n[0]*0.01, hy + n[1]*0.01, hz + n[2]*0.01, sun[0], sun[1], sun[2], 220, null, false);
                    if (s != null && s[1] != RealmShape.WATER) diff *= 0.15;
                }
                double light = ambient + (1 - ambient) * diff;
                if (face == 4 || face == 5) light *= 0.92;
                if (dark) {
                    int lv = lightAt(bx + (int) n[0], by + (int) n[1], bz + (int) n[2]);
                    light = ambient * 0.6 + Math.pow(lv / 15.0, 1.6) * 0.95;
                }
                col = scale(base, light);
            }
            if (wat[0] > 0) col = mix(col, 0x2a5aa8, Math.min(0.85, 0.35 + wat[0] * 0.08));
        }
        double f = 1 - Math.exp(-Math.max(0, dist) / fogDist);
        if (h != null) col = mix(col, fogC, f * f);
        return col;
    }

    void render(String file, int w, int h, double cx, double cy, double cz, double yaw, double pitch, double fov) throws Exception {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        double cyaw = Math.cos(yaw), syaw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        double[] fwd = {cp * cyaw, sp, cp * syaw}, right = norm(new double[]{-syaw, 0, cyaw});
        double[] up = {right[1]*fwd[2]-right[2]*fwd[1], right[2]*fwd[0]-right[0]*fwd[2], right[0]*fwd[1]-right[1]*fwd[0]};
        if (up[1] < 0) { up[0] = -up[0]; up[1] = -up[1]; up[2] = -up[2]; }
        double tan = Math.tan(fov / 2);
        java.util.stream.IntStream.range(0, h).parallel().forEach(py -> {
            for (int px = 0; px < w; px++) {
                int acc_r = 0, acc_g = 0, acc_b = 0;
                for (int s = 0; s < 4; s++) {
                    double ox = (px + (s & 1) * 0.5 + 0.25) / w * 2 - 1, oy = 1 - (py + (s >> 1) * 0.5 + 0.25) / h * 2;
                    ox *= tan * w / (double) h; oy *= tan;
                    double[] d = norm(new double[]{fwd[0] + right[0]*ox + up[0]*oy, fwd[1] + right[1]*ox + up[1]*oy, fwd[2] + right[2]*ox + up[2]*oy});
                    int c = shade(cx, cy, cz, d[0], d[1], d[2]);
                    acc_r += (c >> 16) & 255; acc_g += (c >> 8) & 255; acc_b += c & 255;
                }
                img.setRGB(px, py, (acc_r / 4) << 16 | (acc_g / 4) << 8 | (acc_b / 4));
            }
        });
        ImageIO.write(img, "png", new File(file));
        System.out.println("wrote " + file);
    }

    public static void main(String[] a) throws Exception {
        String which = a[0];
        String out = a[1];
        if (which.equals("myoboku")) {
            RealmPreview p = new RealmPreview(new MyobokuShape(), -18, -18, 36);
            p.render(out + "/myoboku_village.png", 1280, 720, -62, 112, -118, Math.toRadians(63), Math.toRadians(-16), Math.toRadians(70));
            p.render(out + "/myoboku_gate.png", 1280, 720, 0.5, 78, -76, Math.toRadians(90), Math.toRadians(-4), Math.toRadians(70));
            p.render(out + "/myoboku_toad.png", 1280, 720, 0.5, 76, -44, Math.toRadians(150), Math.toRadians(-8), Math.toRadians(70));
            p.render(out + "/myoboku_great_toad.png", 1280, 720, 30, 92, 6, Math.toRadians(135), Math.toRadians(-14), Math.toRadians(70));
            p.render(out + "/myoboku_valley.png", 1280, 720, 150, 135, 120, Math.toRadians(225), Math.toRadians(-18), Math.toRadians(75));
        } else if (which.equals("ryuchi")) {
            RealmPreview p = new RealmPreview(new RyuchiShape(), -14, -14, 28);
            p.sky0 = 0x05070a; p.sky1 = 0x05070a; p.fogC = 0x0b1014; p.fogDist = 120; p.ambient = 0.18; p.shadows = false; p.dark = true;
            p.sun = norm(new double[]{0.2, 1, 0.3}); p.computeLight();
            p.render(out + "/ryuchi_temple.png", 1280, 720, -6, 52, -70, Math.toRadians(85), Math.toRadians(-12), Math.toRadians(75));
            p.render(out + "/ryuchi_serpent.png", 1280, 720, 12, 36, -18, Math.toRadians(100), Math.toRadians(30), Math.toRadians(80));
            p.render(out + "/ryuchi_coil.png", 1280, 720, 46, 50, 30, Math.toRadians(165), Math.toRadians(14), Math.toRadians(80));
        } else {
            RealmPreview p = new RealmPreview(new ShikkotsuShape(), -16, -16, 32);
            p.sky0 = 0x9fb4b8; p.sky1 = 0xd2dcd8; p.fogC = 0xc4cfca; p.fogDist = 95; p.ambient = 0.5;
            p.render(out + "/shikkotsu_temple.png", 1280, 720, 0, 76, -64, Math.toRadians(90), Math.toRadians(-8), Math.toRadians(75));
            p.render(out + "/shikkotsu_forest.png", 1280, 720, 60, 80, 70, Math.toRadians(200), Math.toRadians(8), Math.toRadians(80));
        }
    }
}
